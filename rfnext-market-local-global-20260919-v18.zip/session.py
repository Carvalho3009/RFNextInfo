"""Máquina de estados da sessão: 12000 (login/entrada) -> 12020 (entrada no jogo) -> consultas de mercado.

Sem sleeps: esperas usam prazos em time.monotonic e o timeout de Connection.receive.
Envios restritos a ALLOWED_SENDS (inicialização, manutenção e consulta implementadas).

Serviço lógico vem da seção da configuração ("auth" -> 12000, "game" -> 12020), não do
número de porta real; conn.service_port fica só como metadado do dump.

Credenciais (config["credentials"], lidas do session_file): chaves de nível superior valem
para todas as mensagens; subdicionários "12000_0x0101" e "12020_0x0103" sobrepõem por
mensagem (ex.: device_info da 12020 difere do da 12000 na captura). Derivados em tempo de
execução, não exigidos no session_file: world_id (config) e u64@2688 do 12020 0x0103
(= 12000 S 0x0108 payload[4:12]; igualdade de bytes observada, função não confirmada).
"""
from __future__ import annotations

import secrets
import time

from . import auth, dump, market, protocol
from .transport import DIRECTION_C2S, DIRECTION_S2C, Connection

SERVICES = {"auth": 12000, "game": 12020}
DERIVED_FIELDS = ("world_id", "u64@2688")

ALLOWED_SENDS = {
    12000: {0x0101, 0x0103, 0x0105, 0x0107},
    12020: {0x0101, 0x0103, 0x0105, 0x1D01, 0x1D03},
}

UNCONFIRMED = [
    "vínculo 12000<->12020: quais campos (session_key, f6 do 0x0108, account_id) autenticam o 0x0103 da 12020",
    "fechar 12000 antes de abrir 12020: observado na captura (último dado 12000 ~1,4 s antes), sem FIN confirmado",
    "coexistência das conexões 12000 e 12020 não testada",
    "0x0102 da 12000: result_code==0 tratado como aceitação; demais códigos não catalogados",
    "0x010C (12000) e 0x0105 periódico (12000) do cliente oficial não são enviados",
    "0x0104 da 12020 é candidata a resposta de autenticação; layout sem campo de retorno confirmado",
    "necessidade de 0x0201 e das demais mensagens enviadas pelo cliente oficial antes do mercado (não enviadas)",
    "manutenção na 12020 (0x0205/0x0206 candidatas) não implementada; esperas limitadas por timeout",
    "0x1D01: significado dos 2 bytes; fim da consulta assumido no primeiro 0x1D02 com is_end=1 ou ret!=0",
    "0x1D1E não enviado; função não confirmada",
    "host/porta de 0x0108 não usados: 12020 vem da configuração",
    "u64@2688 do 12020 0x0103 = 12000 0x0108 payload[4:12]: igualdade de bytes observada, função não confirmada",
]


class _Stop(Exception):
    """Encerra a máquina de estados com (status, diagnostic)."""

    def __init__(self, status, diagnostic, timeout=False):
        super().__init__(diagnostic)
        self.status = status
        self.diagnostic = diagnostic
        self.timeout = timeout


class _Link:
    """Uma conexão com contadores de sequência por direção."""

    def __init__(self, conn, emit, service, state=None):
        self.conn = conn
        self.port = service  # serviço lógico (12000/12020), não a porta real
        self.emit = emit
        self.state = state if state is not None else {"stage": "?"}
        self.send_seq = 0
        self.recv_seq = 0
        self.beat_s = None     # intervalo de 0x0103 (12000), definido após 0x0102
        self.next_beat = None  # prazo do próximo 0x0103, a partir do último enviado

    def send(self, opcode, payload):
        if opcode not in ALLOWED_SENDS.get(self.port, ()):
            raise _Stop("failed", f"envio não permitido: serviço {self.port} 0x{opcode:04x}")
        wire = protocol.encode_frame(opcode, payload, self.send_seq, seed=secrets.randbelow(0x40))
        self.send_seq = (self.send_seq + 1) & 0xFF
        try:
            self.conn.send(wire)
        except OSError as exc:  # inclui BrokenPipeError, ConnectionError, TimeoutError
            raise _Stop("failed", f"{self.state['stage']}: envio 0x{opcode:04x} falhou: "
                                  f"{type(exc).__name__}: {exc}") from None
        frame = protocol.decode_frame(wire)
        self.emit(dump.make_frame_record(self.conn, DIRECTION_C2S, wire, frame, _parse(self.port, DIRECTION_C2S, frame)))

    def receive(self):
        """Um quadro S->C já registrado. Devolve (frame, parsed|None)."""
        try:
            wire = self.conn.receive()
            frame = protocol.decode_frame(wire)
        except (TimeoutError, ConnectionError):
            raise
        except (ValueError, OSError) as exc:
            raise _Stop("failed", f"{self.state['stage']}: recepção inválida: "
                                  f"{type(exc).__name__}: {exc}") from None
        if frame["sequence"] != self.recv_seq:
            self.emit({"record_type": "diagnostic", "connection_id": self.conn.connection_id,
                       "message": f"sequência S->C {frame['sequence']} (esperada {self.recv_seq})"})
        self.recv_seq = (frame["sequence"] + 1) & 0xFF
        try:
            parsed = _parse(self.port, DIRECTION_S2C, frame)
        except ValueError as exc:
            parsed = None
            self.emit({"record_type": "diagnostic", "connection_id": self.conn.connection_id,
                       "message": f"parse 0x{frame['opcode']:04x}: {exc}"})
        self.emit(dump.make_frame_record(self.conn, DIRECTION_S2C, wire, frame, parsed))
        return frame, parsed


def _parse(port, direction, frame):
    if port == 12020 and frame["opcode"] >> 8 == 0x1D:
        return market.parse_message(frame["opcode"], frame["payload"])
    return auth.parse_message(port, direction, frame["opcode"], frame["payload"])


def _build(port, opcode, fields, stage):
    try:
        if opcode >> 8 == 0x1D:
            return market.build_payload(opcode, fields)
        return auth.build_payload(port, opcode, fields)
    except ValueError as exc:
        raise _Stop("incomplete", f"{stage}: {exc}") from None


def _await(link, opcode, timeout, stage, heartbeat=False, on_frame=None):
    """Recebe até `opcode` (ou on_frame devolver True). Assíncronas só são registradas.

    Com heartbeat e link.beat_s, envia 0x0103 quando link.next_beat vence; o timeout do
    socket é limitado ao próximo prazo (heartbeat ou deadline) para acordar a tempo.
    ponytail: ajusta Connection._sock diretamente; receive(timeout=) no transporte evitaria isso.
    """
    deadline = time.monotonic() + timeout
    beat = heartbeat and link.beat_s
    sock = getattr(link.conn, "_sock", None)
    base_timeout = sock.gettimeout() if sock is not None else None
    try:
        while True:
            now = time.monotonic()
            if beat and now >= link.next_beat:
                link.send(0x0103, b"")
                link.next_beat = now + link.beat_s
            if now >= deadline:
                raise _Stop("failed", f"{stage}: timeout aguardando 0x{opcode:04x}", timeout=True)
            if sock is not None and base_timeout is not None:
                wake = min(deadline, link.next_beat) if beat else deadline
                sock.settimeout(max(0.001, min(base_timeout, wake - now)))
            try:
                frame, parsed = link.receive()
            except TimeoutError:
                continue
            except ConnectionError as exc:
                raise _Stop("failed", f"{stage}: desconexão: {exc}") from None
            if on_frame is not None:
                if on_frame(frame, parsed):
                    return frame, parsed
            elif frame["opcode"] == opcode:
                if parsed is None:
                    raise _Stop("incomplete", f"{stage}: 0x{opcode:04x} não interpretado")
                return frame, parsed
    finally:
        if sock is not None and base_timeout is not None:
            try:
                sock.settimeout(base_timeout)
            except OSError:
                pass


def _require_ok(parsed, stage):
    code = parsed["fields"].get("result_code")
    if code != 0:
        raise _Stop("failed", f"{stage}: rejeitado result_code={code}")
    return parsed


def run(config: dict, emit) -> dict:
    state = {"stage": "init", "authenticated": None}
    acc = market.MarketAccumulator()
    credentials = config.get("credentials", {})
    derived = {"world_id": config["world_id"]}

    def fields_for(port, opcode):
        out = {k: v for k, v in credentials.items() if not isinstance(v, dict)}
        out.update(credentials.get(f"{port}_0x{opcode:04x}", {}))
        out.update(derived)
        return out
    links = []
    status, diagnostic = "completed", ""

    def connect(section):
        cfg = config[section]
        try:
            link = _Link(Connection(cfg["host"], cfg["port"], cfg["timeout"]), emit, SERVICES[section], state)
        except (ConnectionError, TimeoutError, OSError) as exc:
            raise _Stop("failed", f"{state['stage']}: conexão falhou: {type(exc).__name__}: {exc}") from None
        links.append(link)
        return link

    try:
        # --- 12000 ---
        state["stage"] = "12000:connect"
        a = connect("auth")
        t = config["auth"]["timeout"]
        state["stage"] = "12000:0x0101"
        a.send(0x0101, _build(12000, 0x0101, fields_for(12000, 0x0101), state["stage"]))
        _, ans = _await(a, 0x0102, t, state["stage"])
        _require_ok(ans, state["stage"])
        beat = ans["fields"].get("heartbeat_interval_ms")
        if beat:
            a.beat_s = beat / 1000
            a.next_beat = time.monotonic() + a.beat_s
        state["stage"] = "12000:0x0105"
        a.send(0x0105, _build(12000, 0x0105, fields_for(12000, 0x0105), state["stage"]))
        _await(a, 0x0106, t, state["stage"], heartbeat=True)
        state["stage"] = "12000:0x0107"
        a.send(0x0107, _build(12000, 0x0107, fields_for(12000, 0x0107), state["stage"]))
        _, enter = _await(a, 0x0108, t, state["stage"], heartbeat=True)
        _require_ok(enter, state["stage"])
        ef = enter["fields"]
        link_value = (ef["f4"] | (ef["f6"] << 16)) & 0xFFFFFFFFFFFFFFFF  # payload[4:12] do 0x0108
        supplied = fields_for(12020, 0x0103).get("u64@2688")
        if supplied is not None and supplied != link_value:
            raise _Stop("failed", f"{state['stage']}: u64@2688 do session_file ({supplied!r}) difere do "
                                  f"derivado de 0x0108 payload[4:12] ({link_value:#x})")
        derived["u64@2688"] = link_value
        # Observado na captura (não confirmado): 12000 encerra antes de a 12020 abrir.
        a.conn.close()

        # --- 12020 ---
        state["stage"] = "12020:connect"
        g = connect("game")
        t = config["game"]["timeout"]
        for send_op, recv_op in ((0x0101, 0x0102), (0x0103, 0x0104), (0x0105, 0x0106)):
            state["stage"] = f"12020:0x{send_op:04x}"
            g.send(send_op, _build(12020, send_op, fields_for(12020, send_op), state["stage"]))
            _, parsed = _await(g, recv_op, t, state["stage"])
            ret = parsed["fields"].get("ret", parsed["fields"].get("result_code"))
            if recv_op == 0x0104 and parsed["status"] == "confirmed" and ret is not None:
                state["authenticated"] = ret == 0
                if ret != 0:
                    raise _Stop("failed", f"{state['stage']}: rejeitado ret={ret}")

        # --- mercado ---
        rt = config["market"]["response_timeout"]
        queries = [(f"list-{i}", 0x1D01, 0x1D02, r) for i, r in enumerate(config["market"].get("list_requests", []))]
        queries += [(f"detail-{i}", 0x1D03, 0x1D04, r) for i, r in enumerate(config["market"].get("detail_requests", []))]
        timed_out = []
        for qid, send_op, recv_op, request in queries:
            state["stage"] = f"market:{qid}"
            payload = _build(12020, send_op, request, state["stage"])
            acc.begin_query(qid, request)
            g.send(send_op, payload)

            def on_frame(frame, parsed, qid=qid, recv_op=recv_op):
                if frame["opcode"] != recv_op:
                    return False
                if parsed is None:
                    raise _Stop("incomplete", f"market:{qid}: 0x{recv_op:04x} não interpretado")
                try:
                    acc.accept(dict(parsed, query_id=qid))
                except ValueError as exc:
                    raise _Stop("incomplete", f"market:{qid}: {exc}") from None
                f = parsed["fields"]
                if f.get("ret") != 0:
                    raise _Stop("failed", f"market:{qid}: servidor rejeitou ret={f['ret']}")
                return bool(f.get("is_end"))

            try:
                _await(g, recv_op, rt, state["stage"], on_frame=on_frame)
            except _Stop as stop:
                if not stop.timeout:
                    raise
                timed_out.append(qid)
                emit({"record_type": "diagnostic", "stage": state["stage"], "message": stop.diagnostic})
                # Sem correlação confirmada, não reutilizar a conexão após timeout.
                break
        if timed_out:
            status, diagnostic = "incomplete", "timeout de resposta do mercado: " + ", ".join(timed_out)
        else:
            state["stage"] = "done"
    except _Stop as stop:
        status, diagnostic = stop.status, stop.diagnostic
        emit({"record_type": "error", "stage": state["stage"], "status": status, "message": diagnostic})
    finally:
        for link in links:
            link.conn.close()

    snapshot = acc.snapshot()
    emit(dict(snapshot, record_type="market_result"))
    result = {"status": status, "stage": state["stage"], "diagnostic": diagnostic,
              "authenticated": state["authenticated"], "market": snapshot, "unconfirmed": list(UNCONFIRMED)}
    emit({k: v for k, v in result.items() if k != "market"} | {"record_type": "completion"})
    return result
