# Resultado final — Luna cliente-servidor

Implementação corrigida somente nesta raiz:

- `rfnext_market/desktop.py`: troca de configuração valida caminhos antes de aplicar estado; registros completos retidos; credenciais, payloads, `wire_hex`, `decoded_hex` e campos parseados permanecem na visualização/exportação; detalhe nativo rolável; filas, registros e Treeviews limitados; conclusão preservada; recorte explícito; inspeção usa a árvore do evento em duplo clique/Enter e foco/última árvore selecionada no botão, sem cruzar RX/TX.
- `rfnext_market/session.py`: propagação do cancelamento ao envio sem alterar o wire format; recursos continuam fechados em `finally`; CLI permanece compatível.
- `rfnext_market/transport.py`: DNS cancelável em daemon somente-resolver, conexão não bloqueante e envio incremental com prazo total/timeout curto.
- `tests/test_desktop.py` e `tests/test_transport.py`: regressões para DNS, envio parcial, fechamento, limites e tipos inválidos, asserts sintéticos de password/token/payload integral após nova configuração e seleções simultâneas RX/TX sem mistura na inspeção.

Validação final:

- Python 3.13 global: `py -3.13 -B -m unittest tests.test_desktop -q`: **20 aprovados**; `py -3.13 -B -m unittest discover -s tests -q`: **174 descobertos; 167 aprovados, 7 ignorados** (3,345 s).
- Os 7 ignorados são comparações opcionais de captura/decoder canônico (3 em `test_auth`, 1 em `test_dump` por permissões POSIX, 1 em `test_market`, 2 em `test_protocol`), sem `RFNEXT_CANONICAL_DECODER`/PCAP configurados.
- Regressão CLI incluída: validação de configuração, execução fake, JSONL e CSV.
- Nenhum servidor real, conta, credencial real, endpoint externo, sessão real, origem `D:\RF Mercado`, instalador, deploy, commit ou push foi usado.

Condição de aprovação ajustada explicitamente: sem ocultar credenciais e payloads. Limites
pendentes: teste visual nativo da janela/diálogos/rolagem, redimensionamento, retorno do
controle de parada e teste visual real em Windows 10. Os testes não provam compatibilidade
com jogo/servidor real.
