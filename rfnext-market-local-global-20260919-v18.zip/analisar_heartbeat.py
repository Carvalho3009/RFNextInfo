"""Analisa a evolução dos heartbeats 0x0205/0x0206 de um PCAP."""
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("pcap", type=Path)
    ap.add_argument("-o", "--output", type=Path, required=True)
    ns = ap.parse_args(argv)
    root = Path(__file__).resolve().parent.parent / "agent" / "core"
    if not root.is_dir():
        root = Path(r"K:/MCP/projects/rf-companion-improvements-20260919/agent/core")
    sys.path.insert(0, str(root))
    import rfnext_frame_decode as decoder

    rows = []
    for flow, stream, spans in decoder.pcap_tcp_streams(ns.pcap, 12020):
        pending = None
        for raw, info in decoder.decode_stream(stream):
            if info["opcode"] not in (0x0205, 0x0206):
                continue
            # decode_stream's metadata varies between bundled decoder builds;
            # pairing must not depend on the optional stream offset.
            stamp = spans[-1][1] if spans else None
            payload = raw[6:]
            if info["opcode"] == 0x0205 and len(payload) == 5:
                pending = {"flow": str(flow), "timestamp_ns": stamp,
                           "payload_hex": payload.hex(), "flag": payload[0],
                           "counter": int.from_bytes(payload[1:], "little")}
            elif info["opcode"] == 0x0206 and pending is not None:
                pending["response_hex"] = payload.hex()
                if pending["timestamp_ns"] is not None and stamp is not None:
                    pending["latency_ms"] = round((stamp - pending["timestamp_ns"]) / 1e6, 3)
                rows.append(pending)
                pending = None
    rows.sort(key=lambda row: (row["flow"], row["timestamp_ns"] or 0))
    previous = {}
    for row in rows:
        old = previous.get(row["flow"])
        row["counter_delta"] = None if old is None else (row["counter"] - old["counter"]) & 0xffffffff
        row["interval_ms"] = None if old is None or old["timestamp_ns"] is None else round((row["timestamp_ns"] - old["timestamp_ns"]) / 1e6, 3)
        row["timestamp"] = (datetime.fromtimestamp(row["timestamp_ns"] / 1e9, timezone.utc).isoformat()
                            if row["timestamp_ns"] is not None else None)
        previous[row["flow"]] = row
    result = {"pcap": str(ns.pcap), "pairs": rows,
              "summary": {"pairs": len(rows), "flows": sorted({r["flow"] for r in rows}),
                          "counter_deltas": sorted({r["counter_delta"] for r in rows if r["counter_delta"] is not None}),
                          "interval_ms": [min((r["interval_ms"] for r in rows if r["interval_ms"] is not None), default=None),
                                          max((r["interval_ms"] for r in rows if r["interval_ms"] is not None), default=None)]}}
    ns.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"pares: {len(rows)}; fluxos: {len(result['summary']['flows'])}; saída: {ns.output}")


if __name__ == "__main__":
    main()
