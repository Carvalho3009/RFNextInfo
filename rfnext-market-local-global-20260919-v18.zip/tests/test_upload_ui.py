import json
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from rfnext_market import desktop, upload, __main__ as cli
from tests import test_desktop as helpers


class UploadInterfaceTest(unittest.TestCase):
    def test_http_success_redirect_and_slow_body_have_bounded_exit(self):
        mode = ["ok"]
        release = threading.Event()
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                self.rfile.read(int(self.headers.get("Content-Length", "0")))
                if mode[0] == "redirect":
                    self.send_response(302)
                    self.send_header("Location", "https://external.invalid")
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                if mode[0] == "slow":
                    self.wfile.write(b"{")
                    self.wfile.flush()
                    release.wait(2)
                else:
                    self.wfile.write(b'{"ok":true}')

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        options = {"base_url": f"http://127.0.0.1:{server.server_port}", "timeout": 0.25}
        try:
            self.assertEqual(upload._post(options, "/local", b"{}"), {"ok": True})
            mode[0] = "redirect"
            with self.assertRaisesRegex(ValueError, "HTTP 302"):
                upload._post(options, "/local", b"{}")
            mode[0] = "slow"
            started = time.monotonic()
            with self.assertRaises((OSError, ValueError)):
                upload._post(options, "/local", b"{}")
            self.assertLess(time.monotonic() - started, 1)
        finally:
            release.set()
            server.shutdown()
            server.server_close()
            thread.join(2)

    def test_worker_preserves_failed_and_cancelled_collection_on_upload_error(self):
        stop = threading.Event()
        stop.set()
        for status in ("completed", "incomplete", "cancelled", "failed"):
            value = {"status": status, "items": [1], "token": "local-raw"}
            done = Mock()
            with patch.object(upload, "submit_result", side_effect=OSError("disco")) as send:
                desktop.run_session_worker({"companion": {}}, Mock(), done, stop,
                                           runner=lambda *args, **kwargs: value)
            send.assert_called_once()
            self.assertIs(send.call_args.kwargs["stop_event"], stop)
            self.assertEqual(value["status"], status)
            self.assertEqual(value["token"], "local-raw")
            self.assertEqual(value["upload"]["status"], "pending")
            self.assertIsNone(done.call_args.args[1])

    def test_retry_uses_only_companion_and_keeps_collection(self):
        app = helpers.DesktopWorkerTest.headless_app()
        app.result = {"status": "completed", "items": ["original"]}
        app.retry_button = Mock()
        app._companion_config = Mock(return_value={"companion": {"base_url": "https://example.com"}})
        app._current_config = Mock(side_effect=AssertionError("must not require game credentials"))
        app.stop_event = threading.Event()
        app.stop_event.set()
        state = {"status": "awaiting_authorization", "pairing_code": "ABCD-1234"}
        with patch.object(upload, "retry_pending", return_value=state) as send:
            app._retry_upload()
            app.worker.join(2)
        self.assertFalse(app.stop_event.is_set())
        self.assertFalse(app.worker.is_alive())
        app._handle_event(app._control_queue.get_nowait())
        self.assertEqual(app.result["items"], ["original"])
        self.assertTrue(app._finished)
        self.assertIn("ABCD-1234", app.status.set.call_args.args[0])
        app.start_button.configure.assert_called_with(state="normal")
        app.retry_button.configure.assert_called_with(state="normal")
        send.assert_called_once()

    def test_load_companion_is_atomic_and_resolves_paths(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.vars = {key: helpers.DesktopSafetyTest.Var("old") for key in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        for name in ("session_path", "item_database", "companion_enabled", "companion_url", "companion_state_dir"):
            setattr(app, name, helpers.DesktopSafetyTest.Var("old"))
        with tempfile.TemporaryDirectory() as folder:
            value = {"companion": {"base_url": "https://example.com", "state_dir": []}}
            with self.assertRaises(ValueError):
                app._load_values(value, Path(folder))
            self.assertEqual(app.companion_url.get(), "old")
            self.assertEqual(app.vars["auth_host"].get(), "old")
            value["companion"]["state_dir"] = "queue"
            app._load_values(value, Path(folder))
            self.assertEqual(Path(app.companion_state_dir.get()), Path(folder) / "queue")

    def test_cli_retry_does_not_require_output_or_session_and_returns_failure(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "config.json"
            path.write_text(json.dumps({"companion": {"base_url": "https://example.com", "state_dir": "queue"}}))
            with patch.object(upload, "retry_pending", return_value={"status": "accepted"}) as send, \
                    patch.object(cli, "load_config", side_effect=AssertionError("must not load game config")):
                self.assertEqual(cli.main(["--config", str(path), "--retry-upload"]), 0)
            self.assertEqual(send.call_args.args[0]["companion"]["state_dir"], str(Path(folder) / "queue"))
            with patch.object(upload, "retry_pending", return_value={"status": "pending"}):
                self.assertEqual(cli.main(["--config", str(path), "--retry-upload"]), 1)


if __name__ == "__main__":
    unittest.main()
