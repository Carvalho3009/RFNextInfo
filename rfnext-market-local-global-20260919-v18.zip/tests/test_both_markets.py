"""Fluxo sintético local/global; não confirma os seletores no servidor real."""
import struct
from rfnext_market import report, selection, upload
from tests.test_market_flow import FlowBase, flow_config, game_with, agg, list_1d02, detail_1d04, offer_bytes


class BothMarketsTest(FlowBase):
    def test_upload_exceeding_64_parts_preserves_one_complete_snapshot(self):
        from rfnext_market import market
        raw = market.parse_message(0x1D04, detail_1d04(1002, [offer_bytes()]))['fields']['offers'][0]
        entries = [dict(raw, exchange_index=i) for i in range(32769)]
        result = {'status': 'completed', 'items': [], 'errors': [], 'market': {'queries': [
            {'kind': 'aggregate', 'exchange_server_type': 0, 'complete': True, 'ret': 0,
             'entries': [{'item_index': 1002}]},
            {'kind': 'offers', 'exchange_server_type': 0, 'complete': True, 'ret': 0,
             'item_index': 1002, 'entries': entries}]}}
        parts = [p for p in upload.market_payloads(result, '2026-09-19T00:00:00Z') if 'offers' in p]
        self.assertEqual(len(parts), 65)
        self.assertEqual({p['snapshot_ref'] for p in parts}, {parts[0]['snapshot_ref']})
        self.assertEqual([p['chunk_index'] for p in parts], list(range(1, 66)))
        self.assertTrue(all(p['chunk_count'] == 65 and p['coverage']['status'] == 'complete' for p in parts))
        self.assertEqual(sum(len(p['offers']) for p in parts), 32769)

    def test_aggregate_chunks_respect_receiver_256_row_limit(self):
        result = {'status': 'completed', 'items': [], 'errors': [], 'market': {'queries': [
            {'kind': 'aggregate', 'exchange_server_type': 0, 'complete': True, 'ret': 0,
             'entries': [{'item_index': i + 1} for i in range(257)]}]}}
        parts = [p for p in upload.market_payloads(result, '2026-09-19T00:00:00Z') if 'market_rows' in p]
        self.assertEqual([len(p['market_rows']) for p in parts], [256, 1])
        self.assertEqual({p['chunk_count'] for p in parts}, {2})

    def test_same_item_and_global_only_item_are_requested_per_market(self):
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(1002)]))],
                     [(0x1D02, list_1d02(1, [agg(1002), agg(9999)], server_type=1))]],
            0x1D03: [[(0x1D04, detail_1d04(1002, [offer_bytes(price=10)]))],
                     [(0x1D04, detail_1d04(1002, [offer_bytes(price=20)], server_type=1))],
                     [(0x1D04, detail_1d04(9999, server_type=1))]],
        })
        result = self.run_session(cfg=flow_config(detail_all_items=True), game_s=script)
        self.assertEqual(result['status'], 'completed', result['diagnostic'])
        sent = self.conns[12020].sent
        # Pedidos observados na captura 20260919-163618: 0000 local, 0100 global.
        self.assertEqual([f['payload'] for f in sent if f['opcode'] == 0x1D01], [b'\0\0', b'\1\0'])
        self.assertEqual([f['payload'] for f in sent if f['opcode'] == 0x1D03],
                         [struct.pack('<IB', i, s) for s, i in [(0, 1002), (1, 1002), (1, 9999)]])
        self.assertEqual([(o['exchange_server_type'], o['selling_price']) for o in result['offers']],
                         [(0, 10), (1, 20)])
        self.assertEqual([r['exchange_server_type'] for r in report.offer_rows(result['items'])], [0, 1])
        self.assertEqual([r['exchange_server_type'] for r in report.summary_rows(result['items'])], [0, 1, 1])
        progress = [r for r in self.records if r['record_type'] == 'progress']
        self.assertEqual([(r['completed'], r['total'], r['exchange_server_type']) for r in progress],
                         [(1, 3, 0), (2, 3, 1), (3, 3, 1)])
        payloads = upload.market_payloads(result, '2026-09-19T00:00:00Z')
        offers = [p for p in payloads if 'offers' in p]
        self.assertEqual([(p['server_type'], p['coverage']['status'], p['offers'][0]['price']) for p in offers],
                         [(0, 'complete', 10), (1, 'complete', 20)])

    def test_wrong_market_in_list_or_detail_is_rejected(self):
        for wrong_detail in (False, True):
            with self.subTest(wrong_detail=wrong_detail):
                script = game_with({
                    0x1D01: [[(0x1D02, list_1d02(1, []))],
                             [(0x1D02, list_1d02(1, [agg(1002)], server_type=int(wrong_detail)))]],
                    0x1D03: [[(0x1D04, detail_1d04(1002))]],
                })
                result = self.run_session(cfg=flow_config(detail_all_items=True), game_s=script)
                self.assertEqual(result['status'], 'incomplete')
                self.assertIn('difere do solicitado 1', result['diagnostic'])
                self.assertFalse(result['offers'])

    def test_empty_global_is_complete_but_partial_list_is_not_published(self):
        for end in (0, 1):
            with self.subTest(end=end):
                script = game_with({0x1D01: [[(0x1D02, list_1d02(1, []))],
                                             [(0x1D02, list_1d02(end, [], server_type=1))]]})
                result = self.run_session(cfg=flow_config(detail_all_items=True), game_s=script)
                payloads = upload.market_payloads(result, '2026-09-19T00:00:00Z')
                global_payloads = [p for p in payloads if p['server_type'] == 1]
                self.assertEqual(len(global_payloads), 2 if end else 1)
                self.assertEqual(global_payloads[0]['coverage']['status'], 'complete' if end else 'partial')

    def test_explicit_local_only_and_catalog_does_not_hide_received_item(self):
        script = game_with({0x1D01: [[(0x1D02, list_1d02(1, []))]]})
        result = self.run_session(cfg=flow_config(detail_all_items=True, both_markets=False), game_s=script)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(self.sent_ops(12020).count(0x1D01), 1)
        self.assertEqual(selection.select_all([{'item_index': 9999}], sellable={})[0]['item_index'], 9999)

    def test_manual_details_keep_same_item_in_both_markets(self):
        script = game_with({0x1D03: [[(0x1D04, detail_1d04(1002))],
                                    [(0x1D04, detail_1d04(1002, server_type=1))]]})
        requests = [{'item_index': 1002, 'trailing_u8': s} for s in (0, 0, 1)]
        result = self.run_session(cfg=flow_config(list_requests=[], detail_requests=requests), game_s=script)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(self.sent_ops(12020).count(0x1D03), 2)
        self.assertEqual([i['exchange_server_type'] for i in result['items']], [0, 1])
