import hashlib
import json
import os
import stat
import tempfile
import unittest
from types import SimpleNamespace

from rfnext_market.dump import DumpWriter, make_frame_record
from rfnext_market.protocol import decode_frame, encode_frame


def _conn(connection_id="c-1", local="127.0.0.1:5555", remote="127.0.0.1:12000", port=12000):
    return SimpleNamespace(
        connection_id=connection_id,
        local_endpoint=local,
        remote_endpoint=remote,
        service_port=port,
    )


class DumpWriterExtensionTests(unittest.TestCase):
    def test_rejects_non_jsonl_extension(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                DumpWriter(os.path.join(tmp, "dump.json"))
            with self.assertRaises(ValueError):
                DumpWriter(os.path.join(tmp, "dump.txt"))

    def test_accepts_jsonl_extension(self):
        with tempfile.TemporaryDirectory() as tmp:
            writer = DumpWriter(os.path.join(tmp, "dump.jsonl"))
            writer.close()


class DumpWriterRoundTripTests(unittest.TestCase):
    def test_frame_record_round_trip_with_synthetic_credentials(self):
        # payload sintético contendo campos "sensíveis" fictícios (não reais da captura).
        payload = "JWT=synthetic.jwt.token;session_key=synth-session-abc".encode("utf-16-le")
        wire = encode_frame(0x0101, payload, sequence=3, seed=0x11)
        frame = decode_frame(wire)
        parsed = {
            "fields": {"jwt": "synthetic.jwt.token", "session_key": "synth-session-abc"},
            "unknown_fields": [{"offset": 0, "hex": "aabb", "name": "unknown_@0"}],
        }
        conn = _conn()

        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "dump.jsonl")
            writer = DumpWriter(path)
            record = make_frame_record(conn, "client_to_server", wire, frame, parsed)
            writer.write(record)
            writer.close()

            with open(path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            self.assertEqual(len(lines), 1)
            loaded = json.loads(lines[0])

        self.assertEqual(loaded["record_type"], "frame")
        self.assertEqual(loaded["connection_id"], "c-1")
        self.assertEqual(loaded["local_endpoint"], "127.0.0.1:5555")
        self.assertEqual(loaded["remote_endpoint"], "127.0.0.1:12000")
        self.assertEqual(loaded["service_port"], 12000)
        self.assertEqual(loaded["direction"], "client_to_server")
        self.assertEqual(loaded["opcode"], 0x0101)
        self.assertEqual(loaded["sequence"], 3)
        self.assertEqual(loaded["wire_length"], len(wire))
        self.assertEqual(loaded["decoded_length"], frame["decoded_length"])
        # timestamp com fuso (ISO-8601)
        self.assertRegex(loaded["timestamp"], r"[+-]\d{2}:\d{2}$")

        self.assertEqual(loaded["wire_hex"], wire.hex())
        self.assertEqual(loaded["decoded_hex"], frame["decoded_hex"])
        self.assertNotEqual(loaded["wire_hex"], loaded["decoded_hex"])

        self.assertEqual(loaded["wire_sha256"], hashlib.sha256(wire).hexdigest())
        decoded_bytes = bytes.fromhex(frame["decoded_hex"])
        self.assertEqual(loaded["decoded_sha256"], hashlib.sha256(decoded_bytes).hexdigest())

        # JWT/session_key sintéticos gravados sem redação.
        self.assertEqual(loaded["parsed_fields"]["jwt"], "synthetic.jwt.token")
        self.assertEqual(loaded["parsed_fields"]["session_key"], "synth-session-abc")
        self.assertNotIn("REDACTED", json.dumps(loaded))
        self.assertEqual(loaded["unknown_fields"], [{"offset": 0, "hex": "aabb", "name": "unknown_@0"}])

    def test_make_frame_record_defaults_when_parsed_none(self):
        wire = encode_frame(0x0103, b"", sequence=0, seed=0x05)
        frame = decode_frame(wire)
        conn = _conn()
        record = make_frame_record(conn, "client_to_server", wire, frame, None)
        self.assertEqual(record["parsed_fields"], {})
        self.assertEqual(record["unknown_fields"], [])

    def test_unicode_fields_round_trip(self):
        wire = encode_frame(0x1D01, b"\x00\x01", sequence=1, seed=0x02)
        frame = decode_frame(wire)
        parsed = {"fields": {"nome": "vendedor_ção_é中文"}, "unknown_fields": []}
        conn = _conn()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "dump.jsonl")
            writer = DumpWriter(path)
            writer.write(make_frame_record(conn, "client_to_server", wire, frame, parsed))
            writer.close()
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.loads(f.readline())
        self.assertEqual(loaded["parsed_fields"]["nome"], "vendedor_ção_é中文")

    def test_bytes_in_parsed_fields_become_hex(self):
        wire = encode_frame(0x1D03, b"\x01\x02", sequence=2, seed=0x02)
        frame = decode_frame(wire)
        parsed = {"fields": {"raw": b"\xde\xad\xbe\xef"}, "unknown_fields": []}
        conn = _conn()
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "dump.jsonl")
            writer = DumpWriter(path)
            writer.write(make_frame_record(conn, "client_to_server", wire, frame, parsed))
            writer.close()
            with open(path, "r", encoding="utf-8") as f:
                loaded = json.loads(f.readline())
        self.assertEqual(loaded["parsed_fields"]["raw"], "deadbeef")


class DumpWriterNonFrameRecordTests(unittest.TestCase):
    def test_error_completion_market_result_records(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "dump.jsonl")
            writer = DumpWriter(path)
            writer.write({"record_type": "error", "stage": "auth", "diagnostic": "timeout esperando 0x0104"})
            writer.write({"record_type": "completion", "status": "completed", "authenticated": True})
            writer.write({
                "record_type": "market_result",
                "query_id": "q1",
                "exchange_server_type": 0,
                "complete": True,
                "entries": [],
            })
            writer.close()
            with open(path, "r", encoding="utf-8") as f:
                lines = [json.loads(l) for l in f]
        self.assertEqual([r["record_type"] for r in lines], ["error", "completion", "market_result"])
        self.assertEqual(lines[0]["diagnostic"], "timeout esperando 0x0104")
        self.assertTrue(lines[1]["authenticated"])
        self.assertEqual(lines[2]["query_id"], "q1")


class DumpWriterAppendPreservationTests(unittest.TestCase):
    def test_preserves_previous_records_across_instances(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "dump.jsonl")
            w1 = DumpWriter(path)
            w1.write({"record_type": "diagnostic", "n": 1})
            w1.close()

            w2 = DumpWriter(path)
            w2.write({"record_type": "diagnostic", "n": 2})
            w2.close()

            with open(path, "r", encoding="utf-8") as f:
                lines = [json.loads(l) for l in f]
        self.assertEqual([l["n"] for l in lines], [1, 2])


class DumpWriterErrorHandlingTests(unittest.TestCase):
    def test_write_after_close_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "dump.jsonl")
            writer = DumpWriter(path)
            writer.close()
            with self.assertRaises(ValueError):
                writer.write({"record_type": "diagnostic"})

    def test_missing_directory_raises_on_open(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad_path = os.path.join(tmp, "no_such_dir", "dump.jsonl")
            with self.assertRaises(OSError):
                DumpWriter(bad_path)

    def test_read_only_directory_raises_on_open(self):
        if os.name != "posix" or os.geteuid() == 0:
            self.skipTest("requer POSIX e usuário não-root para permissões efetivas")
        with tempfile.TemporaryDirectory() as tmp:
            ro_dir = os.path.join(tmp, "ro")
            os.mkdir(ro_dir)
            os.chmod(ro_dir, stat.S_IREAD | stat.S_IEXEC)
            try:
                with self.assertRaises(OSError):
                    DumpWriter(os.path.join(ro_dir, "dump.jsonl"))
            finally:
                os.chmod(ro_dir, stat.S_IRWXU)


if __name__ == "__main__":
    unittest.main()
