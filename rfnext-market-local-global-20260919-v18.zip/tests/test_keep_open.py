import threading
import unittest
from unittest import mock

from rfnext_market import desktop, session
from tests import test_session as ts


class KeepOpenTest(unittest.TestCase):
    def test_collect_then_wait_until_stop_or_server_closes_without_growing_snapshot(self):
        for disconnect in (False, True):
            with self.subTest(server_disconnect=disconnect):
                stop = threading.Event()
                clock, records, connections = ts.Clock(), [], {}
                ready, frame_counts = [], []

                class IdleConnection(ts.FakeConn):
                    def receive(self):
                        if ready and self.service_port == 12020 and not self.queue:
                            if disconnect:
                                raise ConnectionError("server EOF")
                            stop.set()
                            raise TimeoutError()
                        return super().receive()

                def factory(host, port, timeout, **kwargs):
                    script = ts.auth_script() if port == 12000 else ts.game_script()
                    connections[port] = IdleConnection(port, script, clock, [])
                    return connections[port]

                def collected(result):
                    self.assertEqual(result['status'], 'completed')
                    self.assertFalse(connections[12020].closed)
                    self.assertTrue(connections[12000].closed)
                    self.assertEqual(result['connection']['status'], 'open')
                    frame_counts.append(len(result['frames']))
                    ready.append(result)
                    connections[12020].queue.append((0x0206, bytes(8)))

                with mock.patch.object(session, 'Connection', factory), mock.patch.object(session, 'time', clock):
                    result = session.run(ts.config(), records.append, stop, on_collected=collected)
                self.assertEqual(len(ready), 1)
                self.assertEqual(result['status'], 'completed')
                self.assertEqual(result['connection']['status'], 'closed')
                self.assertIn('server EOF' if disconnect else 'solicitada', result['connection']['reason'])
                self.assertTrue(connections[12020].closed)
                self.assertEqual(len(result['frames']), frame_counts[0])
                self.assertEqual(sum(r.get('record_type') == 'completion' for r in records), 1)

    def test_worker_uploads_once_and_delivers_result_before_disconnection(self):
        stop, order = threading.Event(), []
        result = {'status': 'completed', 'connection': {'status': 'open'}}

        def runner(config, emit, stop_event, on_collected):
            on_collected(result)
            self.assertEqual(order, ['upload', 'collected'])
            result['connection'] = {'status': 'closed'}
            order.append('disconnect')
            return result

        def submit(*args, **kwargs):
            order.append('upload')
            return {'status': 'accepted'}

        with mock.patch.object(desktop.upload, 'submit_result', side_effect=submit):
            desktop.run_session_worker({'companion': {}}, lambda r: None,
                                       lambda r, e: order.append('done'), stop, runner=runner,
                                       collected=lambda r: order.append('collected'))
        self.assertEqual(order, ['upload', 'collected', 'disconnect', 'done'])

    def test_callback_error_still_closes_connections(self):
        stop, clock, conns = threading.Event(), ts.Clock(), []

        def factory(host, port, timeout, **kwargs):
            conn = ts.FakeConn(port, ts.auth_script() if port == 12000 else ts.game_script(), clock, [])
            conns.append(conn)
            return conn

        with mock.patch.object(session, 'Connection', factory), mock.patch.object(session, 'time', clock):
            with self.assertRaisesRegex(ValueError, 'callback'):
                session.run(ts.config(), lambda r: None, stop,
                            on_collected=mock.Mock(side_effect=ValueError('callback')))
        self.assertTrue(all(c.closed for c in conns))
