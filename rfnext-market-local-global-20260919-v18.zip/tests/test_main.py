import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from rfnext_market import __main__ as cli
from tests.mock_server import (
    ScriptedServer, auth_0102_payload, auth_0108_payload, game_0102_payload,
    game_0104_payload, game_0106_payload, market_1d02_payload,
)

ACCOUNT_ID = "SINTETICO"

# Credenciais sintéticas cobrindo auth.REQUIRED_FIELDS para todo envio não-mercado de
# session.ALLOWED_SENDS (12000 0x0101/0x0103/0x0107 e 12020 0x0101/0x0103/0x0105), exceto
# os campos derivados em tempo de execução por session.run (session.DERIVED_FIELDS:
# world_id, u64@2688 — ver __main__._check_credentials).
_CREDENTIALS = {
    "account_id": ACCOUNT_ID,
    "connection_mode": 4,
    "country_code": "BR",
    "device_info": "test-device",
    "auth_jwt": "jwt-fake",
    "auth_host": "127.0.0.1",
    "session_key": "session-fake",
    "joined_country_code": "BR",
    "tail_flag": 0,
    "tail_value": 0,
    "tail_reserved": 0,
    "mac_address": "00:00:00:00:00:00",
    "unknown_@0_hex": "04",  # 12020 0x0101, exigido por auth.REQUIRED_FIELDS
    "u8@66": 0,
    "u32@67": 0,
    "u32@71": 0,
    "u32@75": 0,
    "unknown_@79_hex": "0000000000",
    "unknown_@2696_hex": "0000000000000000",
    "unknown_@2834_hex": "",
}


def _config(tmp: Path, *, credentials=None, **changes) -> Path:
    data = json.loads(Path(__file__).parents[1].joinpath("config.example.json").read_text())
    data.update(changes)
    (tmp / "sessao.json").write_text(json.dumps(_CREDENTIALS if credentials is None else credentials))
    path = tmp / "config.json"
    path.write_text(json.dumps(data))
    return path


class MainTests(unittest.TestCase):
    def test_example_config_is_valid(self):
        with tempfile.TemporaryDirectory() as tmp:
            config = cli.load_config(_config(Path(tmp)))
            self.assertEqual(config["credentials"]["account_id"], ACCOUNT_ID)

    def test_invalid_values_exit_nonzero_without_sockets(self):
        bad = [
            {"market": {"list_requests": [{"payload_hex": "0000"}], "response_timeout": 1, "both_markets": "true"}},
            {"auth": {"host": "", "port": 12000, "timeout": 1}},
            {"game": {"host": "h", "port": 70000, "timeout": 1}},
            {"game": {"host": "h", "port": 12020, "timeout": 0}},
            {"world_id": None},
            {"session_file": ""},
            {"market": {"list_requests": [{"payload_hex": "00"}], "response_timeout": 1}},
            {"market": {"list_requests": [], "detail_requests": [], "response_timeout": 1}},
        ]
        for change in bad:
            with self.subTest(change=change), tempfile.TemporaryDirectory() as tmp:
                with mock.patch("socket.create_connection") as connect:
                    code = cli.main(["--config", str(_config(Path(tmp), **change)), "--output", str(Path(tmp) / "r.jsonl")])
                self.assertEqual(code, 2)
                connect.assert_not_called()

    def test_output_extension(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(cli.main(["--config", str(_config(Path(tmp))), "--output", str(Path(tmp) / "r.json")]), 2)

    def test_missing_required_credential_field_exits_nonzero_without_sockets(self):
        # session_file sem auth_jwt (exigido por auth.REQUIRED_FIELDS[(12000, 0x0101)]):
        # detectado antes de abrir qualquer socket.
        incomplete = dict(_CREDENTIALS)
        del incomplete["auth_jwt"]
        with tempfile.TemporaryDirectory() as tmp:
            path = _config(Path(tmp), credentials=incomplete)
            with mock.patch("socket.create_connection") as connect:
                code = cli.main(["--config", str(path), "--output", str(Path(tmp) / "r.jsonl")])
            self.assertEqual(code, 2)
            connect.assert_not_called()
            with self.assertRaises(ValueError) as ctx:
                cli.load_config(path)
            self.assertIn("auth_jwt", str(ctx.exception))

    def test_missing_required_12020_credential_field_is_rejected(self):
        # Campo exigido só pelo 0x0103 da 12020 (não pelo 0x0101 da 12000).
        incomplete = dict(_CREDENTIALS)
        del incomplete["u32@67"]
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError) as ctx:
                cli.load_config(_config(Path(tmp), credentials=incomplete))
            self.assertIn("u32@67", str(ctx.exception))

    def test_missing_12020_0101_credential_field_is_rejected_without_socket(self):
        # unknown_@0_hex (12020 0x0101, auth.REQUIRED_FIELDS) faltando: sem isso, session.run
        # gastaria um login real na 12000 antes de falhar ao abrir a 12020 (0x0103) — a
        # checagem precisa pegar isso antes de qualquer socket ser aberto.
        incomplete = dict(_CREDENTIALS)
        del incomplete["unknown_@0_hex"]
        with tempfile.TemporaryDirectory() as tmp:
            path = _config(Path(tmp), credentials=incomplete)
            with mock.patch("socket.create_connection") as connect:
                code = cli.main(["--config", str(path), "--output", str(Path(tmp) / "r.jsonl")])
            self.assertEqual(code, 2)
            connect.assert_not_called()
            with self.assertRaises(ValueError) as ctx:
                cli.load_config(path)
            self.assertIn("unknown_@0_hex", str(ctx.exception))

    def test_invalid_credential_field_size_is_rejected_without_socket(self):
        # unknown_@79_hex (12020 0x0103) precisa ter 5 bytes; com 1 byte, auth.build_payload
        # rejeitaria só ao montar 12020 0x0103, depois de um login real na 12000 — a checagem
        # precisa pegar isso antes de qualquer socket ser aberto.
        invalid = dict(_CREDENTIALS)
        invalid["unknown_@79_hex"] = "00"
        with tempfile.TemporaryDirectory() as tmp:
            path = _config(Path(tmp), credentials=invalid)
            with mock.patch("socket.create_connection") as connect:
                code = cli.main(["--config", str(path), "--output", str(Path(tmp) / "r.jsonl")])
            self.assertEqual(code, 2)
            connect.assert_not_called()
            with self.assertRaises(ValueError) as ctx:
                cli.load_config(path)
            self.assertIn("unknown_@79_hex", str(ctx.exception))

    def test_invalid_credential_field_type_is_rejected_without_socket(self):
        # u32@71 (12020 0x0103) precisa ser inteiro; uma string passa na checagem de presença
        # mas falharia em auth.build_payload só depois de um login real na 12000.
        invalid = dict(_CREDENTIALS)
        invalid["u32@71"] = "30"
        with tempfile.TemporaryDirectory() as tmp:
            path = _config(Path(tmp), credentials=invalid)
            with mock.patch("socket.create_connection") as connect:
                code = cli.main(["--config", str(path), "--output", str(Path(tmp) / "r.jsonl")])
            self.assertEqual(code, 2)
            connect.assert_not_called()
            with self.assertRaises(ValueError) as ctx:
                cli.load_config(path)
            self.assertIn("u32@71", str(ctx.exception))

    def test_main_end_to_end_completed_writes_completion_record(self):
        # session.run contra um ScriptedServer real (ver tests/mock_server.py e
        # tests/test_integration.py) exercitando main() do começo ao fim, incluindo a
        # escrita do .jsonl de saída.
        auth_script = {
            0x0101: {"check_account": True, "reply": [(0x0102, auth_0102_payload(), False)]},
            0x0105: {"reply": [(0x0106, b"\x00" * 4, False)]},
            0x0107: {"reply": [(0x0108, auth_0108_payload(), False)]},
        }
        game_script = {
            0x0101: {"reply": [(0x0102, game_0102_payload(), False)]},
            0x0103: {"check_account": True, "reply": [(0x0104, game_0104_payload(), False)]},
            0x0105: {"reply": [(0x0106, game_0106_payload(), False)]},
            0x1D01: {"reply": [(0x1D02, market_1d02_payload([], is_end=True), False)]},
        }
        auth_srv = ScriptedServer(auth_script, valid_account_id=ACCOUNT_ID,
                                   reject_response=(0x0102, auth_0102_payload(result_code=7), False),
                                   port=0)
        game_srv = ScriptedServer(game_script, valid_account_id=ACCOUNT_ID, port=0)
        try:
            with tempfile.TemporaryDirectory() as tmp:
                tmp = Path(tmp)
                output = tmp / "resultado.jsonl"
                config_path = _config(
                    tmp,
                    auth={"host": "127.0.0.1", "port": auth_srv.port, "timeout": 10.0},
                    game={"host": "127.0.0.1", "port": game_srv.port, "timeout": 10.0},
                    market={"list_requests": [{"payload_hex": "0000"}], "detail_requests": [],
                            "response_timeout": 5.0},
                )
                code = cli.main(["--config", str(config_path), "--output", str(output)])
                self.assertEqual(code, 0)
                records = [json.loads(line) for line in output.read_text(encoding="utf-8").splitlines()]
                completions = [r for r in records if r.get("record_type") == "completion"]
                self.assertEqual(len(completions), 1)
                self.assertEqual(completions[0]["status"], "completed")
                self.assertEqual(completions[0]["stage"], "done")
        finally:
            auth_srv.close()
            game_srv.close()


if __name__ == "__main__":
    unittest.main()
