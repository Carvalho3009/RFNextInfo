import importlib.util
import os
import unittest
from pathlib import Path

from rfnext_market import protocol as p


def lz4_frame(body: bytes, sequence: int = 0, opcode: int = 0x0106) -> bytes:
    """Quadro com LZ4 e sem XOR (b0 = 0x40): exercita o caminho LZ4 isolado."""
    length = p.HEADER_SIZE + len(body)
    return bytes([0x40]) + length.to_bytes(2, "little") + bytes([sequence]) + opcode.to_bytes(2, "little") + body


class FramingTest(unittest.TestCase):
    def test_round_trip(self):
        wire = p.encode_frame(0x1D01, b"\x01\x01", 7, seed=0x15)
        self.assertEqual(wire[0], 0x95)
        self.assertEqual(p.frame_length_from_wire(wire), 8)
        frame = p.decode_frame(wire)
        self.assertEqual((frame["opcode"], frame["sequence"], frame["payload"]), (0x1D01, 7, b"\x01\x01"))
        self.assertEqual(frame["decoded_hex"], "150800" + "07" + "011d" + "0101")
        self.assertEqual((frame["wire_length"], frame["decoded_length"]), (8, 8))
        self.assertTrue(frame["obfuscated"])
        self.assertFalse(frame["compressed"])
        self.assertEqual(frame["seed"], 0x15)

    def test_xor_changes_bytes_and_reverses(self):
        plain = bytes([0x2A]) + (10).to_bytes(2, "little") + b"\x03\x05\x01" + b"\x00\x00\x00\x00"
        wire = p.apply_rolling_xor(plain, 0x2A)
        self.assertNotEqual(wire[1:], plain[1:])
        self.assertEqual(p.remove_rolling_xor(wire), plain)
        self.assertEqual(p.remove_rolling_xor(plain), plain)  # sem bit 0x80: intocado
        with self.assertRaises(ValueError):
            p.apply_rolling_xor(plain, 0x40)

    def test_empty_payload_and_all_seeds(self):
        for seed in range(0x40):
            frame = p.decode_frame(p.encode_frame(0x0103, b"", 255, seed=seed))
            self.assertEqual((frame["payload"], frame["sequence"], frame["seed"]), (b"", 255, seed))

    def test_encode_limits(self):
        with self.assertRaises(ValueError):
            p.encode_frame(0x0101, b"", 256, seed=0)
        with self.assertRaises(ValueError):
            p.encode_frame(0x0101, b"", -1, seed=0)
        with self.assertRaises(ValueError):
            p.encode_frame(0x10000, b"", 0, seed=0)
        with self.assertRaises(ValueError):
            p.encode_frame(0x0101, b"", 0, seed=0x40)
        with self.assertRaises(ValueError):
            p.encode_frame(0x0101, bytes(p.MAX_FRAME - p.HEADER_SIZE + 1), 0, seed=0)
        wire = p.encode_frame(0x0101, bytes(p.MAX_FRAME - p.HEADER_SIZE), 0, seed=1)
        self.assertEqual(len(wire), p.MAX_FRAME)
        self.assertEqual(p.decode_frame(wire)["decoded_length"], p.MAX_FRAME)

    def test_decode_limits(self):
        wire = p.encode_frame(0x0105, b"abc", 1, seed=3)
        for short in (b"", wire[:1], wire[:5]):
            with self.assertRaises(ValueError):
                p.decode_frame(short)
        with self.assertRaises(ValueError):
            p.decode_frame(wire + b"\x00")  # declarado != fornecido
        with self.assertRaises(ValueError):
            p.decode_frame(bytes(p.MAX_FRAME + 1))
        with self.assertRaises(ValueError):
            p.frame_length_from_wire(b"\x80\x00")


class Lz4Test(unittest.TestCase):
    GOOD = bytes([0x32]) + b"abc" + b"\x03\x00" + bytes([0x10]) + b"X"  # abc + match(3,6) + X

    def test_valid_block(self):
        self.assertEqual(p.lz4_block_decompress(self.GOOD), b"abcabcabcX")
        frame = p.decode_frame(lz4_frame(self.GOOD, 9))
        self.assertTrue(frame["compressed"])
        self.assertEqual(frame["payload"], b"abcabcabcX")
        self.assertEqual(frame["decoded_length"], 16)
        self.assertEqual(frame["decoded_hex"][:6], "001000")  # 0x40 limpo, length reescrito

    def test_extended_lengths(self):
        literals = bytes(range(20))
        block = bytes([0xF0, 20 - 15]) + literals
        self.assertEqual(p.lz4_block_decompress(block), literals)
        # match estendido: 1 literal + match offset 1 com 4+15+300 bytes (sobreposto)
        block = bytes([0x1F]) + b"z" + b"\x01\x00" + bytes([0xFF, 45]) + bytes([0x00])
        self.assertEqual(p.lz4_block_decompress(block), b"z" * (1 + 4 + 15 + 300))

    def test_malformed(self):
        cases = {
            "offset zero": bytes([0x10]) + b"a" + b"\x00\x00" + bytes([0x10]) + b"b",
            "offset beyond output": bytes([0x10]) + b"a" + b"\x02\x00" + bytes([0x10]) + b"b",
            "truncated literals": bytes([0x50]) + b"abc",
            "truncated literal length": bytes([0xF0]),
            "truncated match length": bytes([0x1F]) + b"a" + b"\x01\x00" + b"\xFF",
            "truncated offset": bytes([0x10]) + b"a" + b"\x01",
            "ends with match": bytes([0x10]) + b"a" + b"\x01\x00",
            "empty": b"",
        }
        for name, block in cases.items():
            with self.subTest(name):
                with self.assertRaises(ValueError):
                    p.lz4_block_decompress(block)
                with self.assertRaises(ValueError):
                    p.decode_frame(lz4_frame(block))

    def test_output_capacity(self):
        # 1 literal + match de 70000 bytes: excede MAX_FRAME - HEADER_SIZE
        extra = 70000 - 4 - 15
        ext = b"\xFF" * (extra // 255) + bytes([extra % 255])
        block = bytes([0x1F]) + b"a" + b"\x01\x00" + ext + bytes([0x00])
        with self.assertRaises(ValueError):
            p.lz4_block_decompress(block)
        with self.assertRaises(ValueError):
            p.decode_frame(lz4_frame(block))


class FrameBufferTest(unittest.TestCase):
    def frames(self):
        return [
            p.encode_frame(0x0101, b"\x04", 0, seed=5),
            p.encode_frame(0x0103, bytes(range(256)) * 3, 1, seed=0x3F),
            p.encode_frame(0x0105, b"", 2, seed=0),
            lz4_frame(Lz4Test.GOOD, 3),
        ]

    def test_byte_by_byte(self):
        frames = self.frames()
        stream = b"".join(frames)
        buf = p.FrameBuffer()
        out = []
        for i in range(len(stream)):
            out += buf.feed(stream[i : i + 1])
        self.assertEqual(out, frames)
        self.assertEqual(buf.pending, 0)

    def test_concatenated_and_partial_tail(self):
        frames = self.frames()
        buf = p.FrameBuffer()
        self.assertEqual(buf.feed(b"".join(frames) + frames[0][:4]), frames)
        self.assertEqual(buf.pending, 4)
        self.assertEqual(buf.feed(frames[0][4:]), [frames[0]])
        self.assertEqual(buf.pending, 0)
        self.assertEqual(buf.feed(b""), [])

    def test_invalid_length(self):
        buf = p.FrameBuffer()
        self.assertEqual(buf.feed(b"\x00\x05"), [])  # ainda sem 3 bytes
        with self.assertRaises(ValueError):
            buf.feed(b"\x00")  # length 5 < HEADER_SIZE


DECODER = os.environ.get("RFNEXT_CANONICAL_DECODER")
PCAP = os.environ.get("RFNEXT_REFERENCE_PCAP")


@unittest.skipUnless(DECODER and PCAP, "RFNEXT_CANONICAL_DECODER/RFNEXT_REFERENCE_PCAP not set")
class CanonicalCaptureTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("rfnext_canonical_decoder", DECODER)
        cls.canon = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.canon)

    def streams(self, port):
        for label, chunk, _ in self.canon.pcap_tcp_streams(Path(PCAP), port):
            client_to_server = not label.split(" -> ")[0].endswith(f":{port}")
            yield label, chunk, client_to_server

    def test_decode_matches_canonical(self):
        for port in (12000, 12020):
            total = 0
            for label, chunk, _ in self.streams(port):
                expected = self.canon.decode_stream(chunk)
                buf = p.FrameBuffer()
                wires = buf.feed(chunk)
                self.assertEqual(buf.pending, 0, label)
                self.assertEqual(len(wires), len(expected), label)
                for wire, (decoded, info) in zip(wires, expected):
                    frame = p.decode_frame(wire)
                    self.assertEqual(frame["decoded_hex"], decoded.hex())
                    self.assertEqual(frame["payload"], decoded[p.HEADER_SIZE:])
                    for key in ("opcode", "sequence", "wire_length", "decoded_length", "compressed", "obfuscated"):
                        self.assertEqual(frame[key], info[key], (label, key))
                total += len(wires)
            self.assertGreater(total, 0, port)

    def test_reencode_client_frames(self):
        count = 0
        for port in (12000, 12020):
            for label, chunk, c2s in self.streams(port):
                if not c2s:
                    continue
                for wire in p.FrameBuffer().feed(chunk):
                    frame = p.decode_frame(wire)
                    self.assertFalse(frame["compressed"])
                    again = p.encode_frame(frame["opcode"], frame["payload"], frame["sequence"], seed=frame["seed"])
                    self.assertEqual(again, wire, (label, frame["sequence"]))
                    count += 1
        self.assertEqual(count, 195)


if __name__ == "__main__":
    unittest.main()
