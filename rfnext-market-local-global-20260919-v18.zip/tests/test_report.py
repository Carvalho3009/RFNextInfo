"""Agente 6 - persistência (Agente 5): mercado_resumo.csv e mercado_ofertas.csv."""
import csv
import tempfile
import unittest
from pathlib import Path

from rfnext_market import report, selection

BIG = 18446744073709551615  # u64 máximo: precisa sobreviver como texto, sem float


def item(index=1002, produto="P", status=selection.COM_OFERTAS, offers=(), **extra):
    base = {"item_index": index, "produto": produto, "status": status, "offers": list(offers),
            "found_in_list": True, "aggregates": [], "registered_items": 0,
            "lowest_price": None, "highest_price": None, "error": None}
    base.update(extra)
    return base


def offer(**extra):
    info = {"id": BIG, "index": 1002, "count": 3, "lock": True, "enchant_level": 5,
            "talic_indices": [11, 12], "item_options": [
                {"option_index": 7, "value": 1.5, "change_lock": False}],
            "is_broken": False, "expire_time": 0}
    base = {"exchange_index": BIG - 1, "account_id": 0, "pc_id": BIG - 2, "item_info": info,
            "registed_time": 1_757_000_000, "expired_time": 1_757_600_000,
            "selling_time": 0, "selling_price": 1234567890123456789,
            "settlement_price": 987654321, "is_forc_expire": False}
    base.update(extra)
    return base


class TimestampTest(unittest.TestCase):
    def test_seconds_and_millis_are_formatted(self):
        self.assertEqual(report.format_timestamp(1_757_000_000), "2025-09-04T15:33:20+00:00")
        self.assertEqual(report.format_timestamp(1_757_000_000_000),
                         report.format_timestamp(1_757_000_000))

    def test_implausible_values_stay_empty(self):
        for raw in (0, 1, 5_000_000_000, 10**20, None, "x", 1.5, True):
            self.assertEqual(report.format_timestamp(raw), "")


class SummaryTest(unittest.TestCase):
    def test_prices_from_aggregate_and_quantity_from_offers(self):
        row = report.summary_rows([item(offers=[offer(), offer()], lowest_price=1.0,
                                        highest_price=9.0)])[0]
        self.assertEqual(row["ofertas"], 2)
        self.assertEqual((row["menor_preco"], row["maior_preco"]), (1.0, 9.0))
        self.assertEqual(row["quantidade_total"], 6)
        self.assertEqual(row["status"], selection.COM_OFERTAS)

    def test_prices_fall_back_to_offers_when_no_aggregate(self):
        offers = [offer(selling_price=50), offer(selling_price=10)]
        row = report.summary_rows([item(offers=offers)])[0]
        self.assertEqual((row["menor_preco"], row["maior_preco"]), (10, 50))

    def test_absent_and_no_offer_items_are_listed(self):
        rows = report.summary_rows([
            item(index=1007, status=selection.AUSENTE, found_in_list=False),
            item(index=1003, status=selection.SEM_OFERTAS, registered_items=4,
                 lowest_price=2.0, highest_price=2.0),
            item(index=1006, status=selection.ERRO, error="ret=7"),
        ])
        self.assertEqual([r["status"] for r in rows],
                         [selection.AUSENTE, selection.SEM_OFERTAS, selection.ERRO])
        self.assertEqual([r["ofertas"] for r in rows], [0, 0, 0])
        self.assertEqual(rows[0]["menor_preco"], "")
        # Sem ofertas: quantidade vem de number_of_registered_items do agregado.
        self.assertEqual(rows[1]["quantidade_total"], 4)

    def test_columns_match_the_contract(self):
        self.assertEqual(report.SUMMARY_COLUMNS, [
            "exchange_server_type",
            "produto", "item_index", "ofertas", "menor_preco", "maior_preco",
            "quantidade_total", "status"])


class OfferRowsTest(unittest.TestCase):
    def test_columns_match_the_contract(self):
        self.assertEqual(report.OFFER_COLUMNS, [
            "exchange_server_type",
            "produto", "item_index", "exchange_index", "account_id", "pc_id", "item_id",
            "quantidade", "enchant_level", "selling_price", "settlement_price",
            "registered_time_raw", "expired_time_raw", "registered_time", "expired_time",
            "selling_time", "lock", "broken", "expire_time_raw", "talics", "options"])

    def test_ids_stay_exact_text_and_times_keep_raw_and_formatted(self):
        row = report.offer_rows([item(offers=[offer()])])[0]
        self.assertEqual(row["item_id"], str(BIG))
        self.assertEqual(row["exchange_index"], str(BIG - 1))
        self.assertEqual(row["pc_id"], str(BIG - 2))
        self.assertEqual(row["account_id"], "0")          # account_id == 0 preservado
        self.assertEqual(row["selling_price"], 1234567890123456789)
        self.assertEqual(row["registered_time_raw"], 1_757_000_000)
        self.assertEqual(row["registered_time"], "2025-09-04T15:33:20+00:00")
        self.assertEqual(row["talics"], "11;12")
        self.assertEqual(row["options"], "7:1.5:0")
        self.assertEqual((row["lock"], row["broken"]), (1, 0))

    def test_items_without_offers_produce_no_rows(self):
        self.assertEqual(report.offer_rows([item(status=selection.AUSENTE)]), [])


class WriteReportsTest(unittest.TestCase):
    def test_files_have_header_and_rows(self):
        items = [item(offers=[offer()]), item(index=1007, status=selection.AUSENTE,
                                              found_in_list=False)]
        with tempfile.TemporaryDirectory() as tmp:
            summary = Path(tmp) / "mercado_resumo.csv"
            offers = Path(tmp) / "mercado_ofertas.csv"
            written = report.write_reports(items, summary, offers)
            self.assertEqual((written["summary_rows"], written["offer_rows"]), (2, 1))
            with open(summary, encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual([r["status"] for r in rows],
                             [selection.COM_OFERTAS, selection.AUSENTE])
            with open(offers, encoding="utf-8-sig", newline="") as handle:
                offer_rows = list(csv.DictReader(handle))
            self.assertEqual(len(offer_rows), 1)
            # Nenhuma notação científica / perda de precisão nos IDs escritos.
            self.assertEqual(offer_rows[0]["item_id"], str(BIG))
            self.assertEqual(offer_rows[0]["selling_price"], "1234567890123456789")

    def test_counts_for_the_final_record(self):
        items = [item(offers=[offer(), offer()]),
                 item(index=1003, status=selection.SEM_OFERTAS),
                 item(index=1007, status=selection.AUSENTE, found_in_list=False),
                 item(index=1006, status=selection.ERRO, error="ret=7")]
        self.assertEqual(report.counts(items), {
            "items_requested": 4, "items_found": 2, "items_absent": 1,
            "items_error": 1, "offers_total": 2})


if __name__ == "__main__":
    unittest.main()
