import importlib.util
import os
import struct
import unittest
from pathlib import Path

from rfnext_market import market
from rfnext_market.market import MarketAccumulator, build_payload, parse_message


def list_payload(ret, is_end, server_type, items, count=None):
    body = b"".join(struct.pack("<IHddI", i, 0, 1.5, 2.5, 3) for i in items)
    return struct.pack("<HBBH", ret, is_end, server_type, len(items) if count is None else count) + body


def item_info():
    return (struct.pack("<QIQBH", 21, 22, 23, 1, 24) + struct.pack("<HII", 2, 25, 26)
            + struct.pack("<HIfB", 1, 27, 28.5, 1) + struct.pack("<BQ", 0, 29))


def offer_payload(count=1):
    entry = struct.pack("<QQQ", 30, 9001, 9002) + item_info() + struct.pack("<QQQQQB", 33, 34, 35, 36, 37, 1)
    return struct.pack("<HIBBH", 0, 22, 1, 0, count) + entry * count


def msg(qid, payload, opcode=0x1D02):
    return dict(parse_message(opcode, payload), query_id=qid)


class ParseTests(unittest.TestCase):
    def test_1d02_aggregate(self):
        m = parse_message(0x1D02, list_payload(0, 1, 1, [10, 11]))
        self.assertEqual(m["status"], "confirmed")
        f = m["fields"]
        self.assertEqual((f["ret"], f["is_end"], f["exchange_server_type"]), (0, True, 1))
        self.assertEqual([e["item_index"] for e in f["entries"]], [10, 11])
        self.assertEqual(f["entries"][0]["lowest_price"], 1.5)

    def test_1d02_count_mismatch(self):
        with self.assertRaises(ValueError):
            parse_message(0x1D02, list_payload(0, 1, 0, [1, 2], count=3))
        with self.assertRaises(ValueError):
            parse_message(0x1D02, list_payload(0, 1, 0, [1, 2], count=1))
        with self.assertRaises(ValueError):
            parse_message(0x1D02, b"\x00\x00\x01")

    def test_1d04_offers_keep_ids(self):
        f = parse_message(0x1D04, offer_payload())["fields"]
        offer = f["offers"][0]
        self.assertEqual((offer["account_id"], offer["pc_id"]), (9001, 9002))
        self.assertEqual(offer["item_info"]["talic_indices"], [25, 26])
        self.assertEqual(offer["item_info"]["item_options"][0]["value"], 28.5)
        self.assertNotIn("entries", f)
        with self.assertRaises(ValueError):
            parse_message(0x1D04, offer_payload()[:-1])
        with self.assertRaises(ValueError):
            parse_message(0x1D04, offer_payload() + b"\x00")

    def test_1d17_1d18_1d1a(self):
        f = parse_message(0x1D17, struct.pack("<HIHddB", 0, 7, 1, 2.0, 3.0, 1))["fields"]
        self.assertEqual(f["market_price_info"]["last_price"], 3.0)
        with self.assertRaises(ValueError):
            parse_message(0x1D17, b"\x00" * 24)
        f = parse_message(0x1D18, struct.pack("<BHIHHIH", 2, 1, 50, 5, 1, 51, 6))["fields"]
        self.assertEqual(f["recommended_item_info"]["most_registrations_in_one_week_item_info"],
                         [{"item_index": 51, "enchant_level": 6}])
        f = parse_message(0x1D1A, struct.pack("<HBBHIH", 0, 1, 2, 1, 52, 7))["fields"]
        self.assertEqual(f["bookmark_info_list"][0]["item_index"], 52)
        with self.assertRaises(ValueError):
            parse_message(0x1D1A, struct.pack("<HBBH", 0, 1, 2, 1))

    def test_1d1f_unknown_preserved(self):
        m = parse_message(0x1D1F, bytes(range(48)))
        self.assertEqual(m["status"], "unparsed")
        self.assertEqual(m["unknown_fields"], [{"offset": 0, "hex": bytes(range(48)).hex(), "name": "unknown_@0"}])


class BuildTests(unittest.TestCase):
    def test_1d01(self):
        self.assertEqual(build_payload(0x1D01, {"payload_hex": "0001"}), b"\x00\x01")
        self.assertEqual(build_payload(0x1D01, {"raw": b"\x01\x01"}), b"\x01\x01")
        for bad in ({}, {"payload_hex": "00"}, {"payload_hex": "000000"}, {"payload_hex": "zz"},
                    {"raw": b"\x00\x00", "payload_hex": "0001"}):
            with self.assertRaises(ValueError):
                build_payload(0x1D01, bad)
        self.assertEqual(parse_message(0x1D01, b"\x00\x01")["fields"], {"payload_hex": "0001"})

    def test_1d03(self):
        payload = build_payload(0x1D03, {"item_index": 1000001, "trailing_u8": 0})
        self.assertEqual(payload, bytes.fromhex("41420f0000"))
        self.assertEqual(parse_message(0x1D03, payload)["fields"], {"item_index": 1000001, "trailing_u8": 0})
        with self.assertRaisesRegex(ValueError, "trailing_u8"):
            build_payload(0x1D03, {"item_index": 1})
        with self.assertRaises(ValueError):
            build_payload(0x1D03, {"item_index": 1 << 32, "trailing_u8": 0})

    def test_1d1e_empty(self):
        self.assertEqual(build_payload(0x1D1E, {}), b"")
        with self.assertRaises(ValueError):
            build_payload(0x1D1E, {"x": 1})

    def test_forbidden_and_unsupported(self):
        for opcode in (0x1D0C, 0x1D0E, 0x1D10, 0x1D12, 0x1D14, 0x1D06, 0x1D02):
            with self.assertRaises(ValueError):
                build_payload(opcode, {"item_index": 1, "trailing_u8": 0})


class AccumulatorTests(unittest.TestCase):
    def test_split_list_completes(self):
        acc = MarketAccumulator()
        acc.begin_query("q1", {"payload_hex": "0000"})
        acc.accept(msg("q1", list_payload(0, 0, 0, [1, 2])))
        q = acc.snapshot()["queries"][0]
        self.assertFalse(q["complete"])
        acc.accept(msg("q1", list_payload(0, 1, 0, [3])))
        q = acc.snapshot()["queries"][0]
        self.assertTrue(q["complete"])
        self.assertEqual((q["frames"], q["error"], q["exchange_server_type"]), (2, None, 0))
        self.assertEqual([e["item_index"] for e in q["entries"]], [1, 2, 3])

    def test_error_not_empty_list(self):
        acc = MarketAccumulator()
        acc.begin_query("q1", {})
        acc.accept(msg("q1", list_payload(7, 1, 0, [])))
        q = acc.snapshot()["queries"][0]
        self.assertEqual((q["ret"], q["complete"]), (7, False))
        self.assertTrue(q["error"])

    def test_server_types_and_queries_separate(self):
        acc = MarketAccumulator()
        acc.begin_query("q1", {})
        acc.accept(msg("q1", list_payload(0, 0, 0, [1])))
        acc.accept(msg("q1", list_payload(0, 1, 1, [9])))
        acc.begin_query("q2", {})
        acc.accept(msg("q2", list_payload(0, 1, 0, [5])))
        acc.accept(msg("q1", list_payload(0, 1, 0, [2])))
        rows = {(q["query_id"], q["exchange_server_type"]): q for q in acc.snapshot()["queries"]}
        self.assertEqual([e["item_index"] for e in rows["q1", 0]["entries"]], [1, 2])
        self.assertEqual([e["item_index"] for e in rows["q1", 1]["entries"]], [9])
        self.assertEqual([e["item_index"] for e in rows["q2", 0]["entries"]], [5])

    def test_restart_same_query_starts_new_list(self):
        acc = MarketAccumulator()
        acc.begin_query("q1", {})
        acc.accept(msg("q1", list_payload(0, 0, 0, [1])))
        acc.begin_query("q1", {})
        acc.accept(msg("q1", list_payload(0, 1, 0, [2])))
        queries = acc.snapshot()["queries"]
        self.assertEqual(len(queries), 2)
        self.assertFalse(queries[0]["complete"])
        self.assertEqual([e["item_index"] for e in queries[1]["entries"]], [2])

    def test_orphan_not_mixed(self):
        acc = MarketAccumulator()
        acc.accept(msg(None, list_payload(0, 1, 0, [1])))
        acc.begin_query("q1", {})
        acc.accept(msg("other", list_payload(0, 1, 0, [2])))
        snap = acc.snapshot()
        self.assertEqual(snap["queries"], [])
        self.assertEqual(len(snap["orphans"]), 2)

    def test_offers_kept_apart_from_aggregates(self):
        acc = MarketAccumulator()
        acc.begin_query("q1", {})
        acc.accept(msg("q1", list_payload(0, 0, 0, [1])))
        acc.accept(msg("q1", offer_payload(), opcode=0x1D04))
        kinds = {q["kind"]: q for q in acc.snapshot()["queries"]}
        self.assertFalse(kinds["aggregate"]["complete"])
        self.assertTrue(kinds["offers"]["complete"])
        self.assertEqual(kinds["offers"]["entries"][0]["account_id"], 9001)


CANON = os.environ.get("RFNEXT_CANONICAL_DECODER")
PCAP = os.environ.get("RFNEXT_REFERENCE_PCAP")


@unittest.skipUnless(CANON and PCAP, "RFNEXT_CANONICAL_DECODER / RFNEXT_REFERENCE_PCAP not set")
class CaptureTests(unittest.TestCase):
    # nome da lista no canônico -> nome aqui
    RENAMES = {"exchange_item_simple_infos": "entries", "detailed_list": "offers"}

    def test_capture_matches_canonical(self):
        spec = importlib.util.spec_from_file_location("rfnext_canonical", CANON)
        canon = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(canon)
        seen = {}
        acc = MarketAccumulator()
        acc.begin_query("capture", {})
        for _label, chunk, _spans in canon.pcap_tcp_streams(Path(PCAP), 12020):
            for decoded, info in canon.decode_stream(chunk):
                opcode = info["opcode"]
                mine = parse_message(opcode, decoded[6:])
                if opcode in (0x1D01, 0x1D03, 0x1D1E):
                    self.assertEqual(build_payload(opcode, mine["fields"]), decoded[6:])
                if opcode == 0x1D02:
                    acc.accept(dict(mine, query_id="capture"))
                if opcode == 0x1D1F:
                    self.assertEqual(mine["unknown_fields"][0]["hex"], decoded[6:].hex())
                if opcode not in market.NAMES:
                    continue
                expected = canon.parse_exchange_payload(decoded)
                expected.pop("message")
                expected = {self.RENAMES.get(k, k): v for k, v in expected.items()}
                self.assertEqual(mine["fields"], expected, f"{opcode:#06x}")
                self.assertEqual(mine["status"], "confirmed")
                seen[opcode] = seen.get(opcode, 0) + 1
        lists = [(q["exchange_server_type"], q["complete"], len(q["entries"])) for q in acc.snapshot()["queries"]]
        self.assertEqual(lists, [(1, True, 281), (0, True, 2272), (0, True, 2272)])
        self.assertEqual(seen, {0x1D02: 5, 0x1D04: 1, 0x1D17: 1, 0x1D18: 1, 0x1D1A: 1})


if __name__ == "__main__":
    unittest.main()
