import struct
import unittest
from rfnext_market import character
from tests import test_session as ts


class CharacterTest(unittest.TestCase):
    run_session = ts.SessionTest.run_session

    def test_initialization_updates_live_handles_and_checks_response(self):
        cfg = ts.config(); cfg["initialize_character"] = True
        creds = cfg["credentials"]
        raw = ts.s16(creds["account_id"]) + struct.pack("<QQ14sQ", 99, 123, bytes(14), 88) + ts.s16(creds["auth_jwt"])
        creds["character_enter_payload_hex"] = raw.hex()
        script = ts.game_script({0x0201: [[(0x0202, struct.pack("<HQ", 0, 123))]]})
        answer = self.run_session(cfg=cfg, game_s=script)
        self.assertEqual(answer["status"], "completed")
        sent = self.conns[12020].sent
        ops = [f["opcode"] for f in sent]
        self.assertLess(ops.index(0x0201), ops.index(0x1D01))
        packet = next(f["payload"] for f in sent if f["opcode"] == 0x0201)
        offset = len(ts.s16(creds["account_id"]))
        self.assertEqual(struct.unpack_from("<Q", packet, offset)[0], 0x1122)
        self.assertEqual(struct.unpack_from("<Q", packet, offset + 30)[0], ts.LINK_U64)
        self.assertEqual(packet[offset + 8:offset + 30], raw[offset + 8:offset + 30])
        script[0x0201] = [[(0x0202, struct.pack("<HQ", 1, 123))]]
        self.assertEqual(self.run_session(cfg=cfg, game_s=script)["status"], "failed")
        creds["auth_jwt"] = "different"
        with self.assertRaises(ValueError): character.template(creds)
