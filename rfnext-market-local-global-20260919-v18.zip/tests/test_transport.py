"""Tests for rfnext_market.transport using a real loopback TCP server.

Frames here are built by hand (not via protocol.encode_frame) per the
Agent 2 brief: 6-byte header b0(no 0x80)/length u16 LE/sequence u8/opcode
u16 LE, followed by payload bytes equal to the declared length.
"""
import socket
import struct
import threading
import time
import unittest
from unittest import mock

import rfnext_market.transport as transport
from rfnext_market.transport import CancelledError, Connection


def make_frame(opcode: int, payload: bytes, sequence: int = 0, seed: int = 0) -> bytes:
    b0 = seed & 0x3F  # no obfuscation, no LZ4
    header = struct.pack("<BHBH", b0, 6 + len(payload), sequence, opcode)
    return header + payload


def _call_send(conn, event):
    try:
        conn.send(b"abcd", stop_event=event)
    except BaseException as exc:
        return exc
    return None


class LoopbackServer:
    """Minimal TCP server accepting one connection, driven by a handler."""

    def __init__(self, handler):
        self._handler = handler
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.bind(("127.0.0.1", 0))
        self._sock.listen(1)
        self.port = self._sock.getsockname()[1]
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def _run(self):
        conn, _ = self._sock.accept()
        try:
            self._handler(conn)
        finally:
            conn.close()

    def close(self):
        self._sock.close()
        self._thread.join(timeout=2)


class TransportTests(unittest.TestCase):
    def test_cancelled_before_connect_does_not_open_socket(self):
        event = threading.Event()
        event.set()
        with self.assertRaises(CancelledError):
            Connection("127.0.0.1", 1, timeout=1, stop_event=event)

    def test_cancelled_dns_worker_never_connects_after_resolver_release(self):
        event = threading.Event()
        resolver_started = threading.Event()
        release = threading.Event()
        result = []

        def blocked_resolver(*args):
            resolver_started.set()
            release.wait(1)
            return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", ("127.0.0.1", 1))]

        def connect():
            try:
                Connection("synthetic.invalid", 1, timeout=1, stop_event=event)
            except BaseException as exc:
                result.append(exc)

        with mock.patch.object(transport.socket, "getaddrinfo", blocked_resolver), \
                mock.patch.object(transport.socket, "socket", side_effect=AssertionError("socket opened")):
            worker = threading.Thread(target=connect)
            worker.start()
            self.assertTrue(resolver_started.wait(1))
            event.set()
            worker.join(0.5)
            self.assertFalse(worker.is_alive())
            release.set()
            worker.join(0.5)
        self.assertIsInstance(result[0], CancelledError)

    def test_send_partial_backpressure_cancels_without_sendall(self):
        event = threading.Event()

        class PartialSocket:
            def __init__(self):
                self.calls = 0
                self.timeout = 5

            def gettimeout(self):
                return self.timeout

            def settimeout(self, value):
                self.timeout = value

            def send(self, data):
                self.calls += 1
                if self.calls == 1:
                    return 1
                event.set()
                raise socket.timeout()

        conn = Connection.__new__(Connection)
        conn._sock = PartialSocket()
        conn.remote_endpoint = "fake:1"
        result = []
        worker = threading.Thread(target=lambda: result.append(_call_send(conn, event)))
        worker.start()
        deadline = time.monotonic() + 1
        while conn._sock.calls < 2 and time.monotonic() < deadline:
            time.sleep(0.005)
        worker.join(0.5)
        self.assertFalse(worker.is_alive())
        self.assertIsInstance(result[0], CancelledError)
        self.assertEqual(conn._sock.calls, 2)


    def test_fragmented_read(self):
        frame = make_frame(0x0101, b"hello world")

        def handler(conn):
            for byte in frame:
                conn.sendall(bytes([byte]))
                time.sleep(0.001)

        server = LoopbackServer(handler)
        try:
            c = Connection("127.0.0.1", server.port, timeout=5)
            self.assertEqual(c.receive(), frame)
            c.close()
        finally:
            server.close()

    def test_two_responses_single_send(self):
        f1 = make_frame(0x0102, b"abc", sequence=1)
        f2 = make_frame(0x0103, b"", sequence=2)

        def handler(conn):
            conn.sendall(f1 + f2)

        server = LoopbackServer(handler)
        try:
            c = Connection("127.0.0.1", server.port, timeout=5)
            self.assertEqual(c.receive(), f1)
            self.assertEqual(c.receive(), f2)
            c.close()
        finally:
            server.close()

    def test_timeout(self):
        def handler(conn):
            time.sleep(1.0)

        server = LoopbackServer(handler)
        try:
            c = Connection("127.0.0.1", server.port, timeout=0.1)
            with self.assertRaises(TimeoutError):
                c.receive()
            c.close()
        finally:
            server.close()

    def test_eof_mid_frame(self):
        frame = make_frame(0x0104, b"0123456789")

        def handler(conn):
            conn.sendall(frame[:4])  # cut inside the header/payload

        server = LoopbackServer(handler)
        try:
            c = Connection("127.0.0.1", server.port, timeout=5)
            with self.assertRaises(ConnectionError):
                c.receive()
            c.close()
        finally:
            server.close()

    def test_eof_clean_no_pending_frame(self):
        def handler(conn):
            pass  # close immediately, nothing sent

        server = LoopbackServer(handler)
        try:
            c = Connection("127.0.0.1", server.port, timeout=5)
            with self.assertRaises(ConnectionError):
                c.receive()
            c.close()
        finally:
            server.close()

    def test_close_idempotent(self):
        server = LoopbackServer(lambda conn: time.sleep(0.2))
        try:
            c = Connection("127.0.0.1", server.port, timeout=5)
            c.close()
            c.close()  # must not raise
        finally:
            server.close()

    def test_cancelled_receive_is_bounded(self):
        server = LoopbackServer(lambda conn: time.sleep(0.2))
        try:
            c = Connection("127.0.0.1", server.port, timeout=5)
            event = threading.Event()
            event.set()
            with self.assertRaises(CancelledError):
                c.receive(stop_event=event)
            c.close()
        finally:
            server.close()

    def test_endpoints_and_connection_id(self):
        server = LoopbackServer(lambda conn: time.sleep(0.2))
        try:
            c1 = Connection("127.0.0.1", server.port, timeout=5)
            self.assertEqual(c1.service_port, server.port)
            self.assertTrue(c1.local_endpoint.startswith("127.0.0.1:"))
            self.assertTrue(c1.remote_endpoint.startswith("127.0.0.1:"))
            c1.close()
        finally:
            server.close()

    def test_connection_ids_distinct(self):
        server1 = LoopbackServer(lambda conn: time.sleep(0.2))
        server2 = LoopbackServer(lambda conn: time.sleep(0.2))
        try:
            c1 = Connection("127.0.0.1", server1.port, timeout=5)
            c2 = Connection("127.0.0.1", server2.port, timeout=5)
            self.assertNotEqual(c1.connection_id, c2.connection_id)
            c1.close()
            c2.close()
        finally:
            server1.close()
            server2.close()


if __name__ == "__main__":
    unittest.main()
