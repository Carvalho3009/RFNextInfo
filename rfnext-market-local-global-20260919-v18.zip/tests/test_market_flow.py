"""Agente 6 - fluxo integrado: 0x1D02 -> seleção -> 0x1D03/0x1D04 -> CSV/JSONL.

Reaproveita as conexões roteirizadas de test_session (sem sockets, sem sleeps).
"""
import csv
import json
import struct
import tempfile
import unittest
from pathlib import Path

from rfnext_market import report, selection
from tests import test_session as ts


def agg(item_index, enchant=0, registered=1, lowest=1.0, highest=2.0):
    return struct.pack("<IHddI", item_index, enchant, lowest, highest, registered)


def list_1d02(is_end, entries, ret=0, server_type=0):
    return struct.pack("<HBBH", ret, is_end, server_type, len(entries)) + b"".join(entries)


def offer_bytes(exchange_index=1, account_id=0, pc_id=2, item_id=7, index=1002, count=3,
                enchant=0, price=1000, settlement=900, registed=1_757_000_000,
                expired=1_757_600_000, talics=(11,), options=((7, 1.5, 0),)):
    out = struct.pack("<QQQ", exchange_index, account_id, pc_id)
    out += struct.pack("<QIQBH", item_id, index, count, 1, enchant)
    out += struct.pack("<H", len(talics)) + b"".join(struct.pack("<I", t) for t in talics)
    out += struct.pack("<H", len(options))
    out += b"".join(struct.pack("<IfB", *option) for option in options)
    out += struct.pack("<BQ", 0, 0)
    out += struct.pack("<QQQQQB", registed, expired, 0, price, settlement, 0)
    return out


def detail_1d04(item_index, offers=(), is_end=1, ret=0, server_type=0):
    return (struct.pack("<HIBBH", ret, item_index, is_end, server_type, len(offers))
            + b"".join(offers))


def flow_config(**market):
    cfg = ts.config()
    cfg["market"] = {"list_requests": [{"payload_hex": "0000"}], "detail_requests": [],
                     "trailing_u8": 0, "response_timeout": 5.0, **market}
    return cfg


BASE_GAME = {0x0101: [[(0x0102, ts.ANS_0102_12020)]],
             0x0103: [[(0x0104, ts.ANS_0104_12020)]],
             0x0105: [[(0x0106, b"\x00" * 4)]]}


def game_with(extra):
    return {**BASE_GAME, **extra}


class FlowBase(unittest.TestCase):
    """Só os utilitários de SessionTest (não herda os testes daquela classe)."""

    run_session = ts.SessionTest.run_session
    sent_ops = ts.SessionTest.sent_ops


class MarketFlowTest(FlowBase):
    def test_disconnect_reauthenticates_before_next_detail(self):
        from unittest.mock import patch
        from rfnext_market import session
        for send_failure in (False, True):
            with self.subTest(send_failure=send_failure):
                clock, log, conns = ts.Clock(), [], []
                scripts = [ts.auth_script(), game_with({
                    0x1D01: [[(0x1D02, list_1d02(1, [agg(1002), agg(1003)]))]],
                    0x1D03: [["eof"], [(0x1D04, detail_1d04(1002))]],
                }), game_with({0x1D03: [[(0x1D04, detail_1d04(1003))]]})]
                class Conn(ts.FakeConn):
                    def send(self, wire):
                        if send_failure and len(conns) > 1 and self is conns[1] and ts.protocol.decode_frame(wire)["opcode"] == 0x1D03:
                            raise BrokenPipeError("test broken pipe")
                        super().send(wire)
                def factory(host, port, timeout):
                    conn = Conn(port, scripts[len(conns)], clock, log)
                    conns.append(conn)
                    return conn
                with patch.object(session, "Connection", factory), patch.object(session.time, "monotonic", clock.monotonic):
                    result = session.run(flow_config(), lambda r: None)
                self.assertEqual(len(conns), 3)
                self.assertTrue(conns[1].closed)
                self.assertEqual([f["opcode"] for f in conns[2].sent], [0x0101, 0x0103, 0x0105, 0x1D03])
                self.assertEqual(len(result["errors"]), 1)
                self.assertIn(next(i for i in result["items"] if i["item_index"] == 1003)["status"], {selection.ERRO, selection.SEM_OFERTAS})

    def test_selection_drives_details_and_states(self):
        # 0x1D02 em dois quadros: 1002 (dois refinos) e 1003; 1007/1006 não aparecem.
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(0, [agg(1002, 0, 2, 5.0, 9.0), agg(4242)])),
                      (0x1D02, list_1d02(1, [agg(1002, 3, 1, 1.0, 4.0), agg(1003, 0, 4)]))]],
            0x1D03: [[(0x1D04, detail_1d04(1002, [offer_bytes(1, 0, 20, price=1000, count=3),
                                                  offer_bytes(2, 0, 21, price=2000, count=1)]))],
                     [(0x1D04, detail_1d04(1003))]],
        })
        result = self.run_session(cfg=flow_config(), game_s=script)

        self.assertEqual(result["status"], "completed", result["diagnostic"])
        self.assertEqual(self.sent_ops(12020), [0x0101, 0x0103, 0x0105, 0x1D01, 0x1D03, 0x1D03])
        states = {i["item_index"]: i["status"] for i in result["items"]}
        self.assertEqual(states, {1002: selection.COM_OFERTAS, 1003: selection.SEM_OFERTAS,
                                  1007: selection.AUSENTE, 1006: selection.AUSENTE})
        # Ordem do mapa de produtos, um registro por item, sem repetir item_index.
        self.assertEqual([i["item_index"] for i in result["items"]], [1002, 1007, 1006, 1003])
        self.assertEqual(len(result["offers"]), 2)
        self.assertEqual({o["produto"] for o in result["offers"]},
                         {"Secret Nemesis Base Permit Extension"})
        self.assertEqual(result["errors"], [])
        self.assertTrue(len(result["frames"]) >= 6)

        completion = self.records[-1]
        self.assertEqual(completion["record_type"], "completion")
        self.assertEqual(completion["items_requested"], 4)
        self.assertEqual(completion["items_found"], 2)
        self.assertEqual(completion["offers_total"], 2)
        self.assertEqual(completion["errors"], [])
        self.assertEqual(completion["frames"], len(result["frames"]))

        summary = {r["item_index"]: r for r in report.summary_rows(result["items"])}
        self.assertEqual(summary[1002]["ofertas"], 2)
        self.assertEqual((summary[1002]["menor_preco"], summary[1002]["maior_preco"]), (1.0, 9.0))
        self.assertEqual(summary[1002]["quantidade_total"], 4)      # 3 + 1 de item_info.count
        self.assertEqual(summary[1003]["quantidade_total"], 4)      # sem ofertas: do agregado
        self.assertEqual(summary[1007]["ofertas"], 0)

    def test_absent_item_is_never_requested(self):
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(1003)]))]],
            0x1D03: [[(0x1D04, detail_1d04(1003))]],
        })
        result = self.run_session(cfg=flow_config(), game_s=script)
        self.assertEqual(result["status"], "completed", result["diagnostic"])
        self.assertEqual(self.sent_ops(12020).count(0x1D03), 1)
        absent = [i for i in result["items"] if i["status"] == selection.AUSENTE]
        self.assertEqual({i["item_index"] for i in absent}, {1002, 1007, 1006})
        self.assertTrue(all(i["offers"] == [] and i["error"] is None for i in absent))

    def test_detail_ret_marks_only_that_item_as_error(self):
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(1002), agg(1003)]))]],
            0x1D03: [[(0x1D04, detail_1d04(1002, ret=7))],
                     [(0x1D04, detail_1d04(1003, [offer_bytes(3, 0, 22, index=1003)]))]],
        })
        result = self.run_session(cfg=flow_config(), game_s=script)
        self.assertEqual(result["status"], "incomplete")
        states = {i["item_index"]: i["status"] for i in result["items"]}
        self.assertEqual(states[1002], selection.ERRO)
        self.assertEqual(states[1003], selection.COM_OFERTAS)
        erro = next(i for i in result["items"] if i["item_index"] == 1002)
        self.assertIn("ret=7", erro["error"])
        self.assertEqual([e["item_index"] for e in result["errors"]], [1002])
        self.assertEqual(self.records[-1]["items_error"], 1)

    def test_detail_timeout_stops_further_queries(self):
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(1002), agg(1003)]))]],
            0x1D03: [[], []],  # nenhuma resposta: timeout na primeira consulta de detalhe
        })
        result = self.run_session(cfg=flow_config(), game_s=script)
        self.assertEqual(result["status"], "incomplete")
        self.assertIn("timeout", result["diagnostic"] + result["errors"][0]["error"])
        self.assertEqual(self.sent_ops(12020).count(0x1D03), 1)  # conexão não reutilizada
        states = {i["item_index"]: i["status"] for i in result["items"]}
        self.assertEqual(states[1002], selection.ERRO)
        self.assertEqual(states[1003], selection.ERRO)   # consulta não realizada
        self.assertIn("não realizada",
                      next(i for i in result["items"] if i["item_index"] == 1003)["error"])

    def test_list_ret_fails_before_any_detail(self):
        script = game_with({0x1D01: [[(0x1D02, list_1d02(0, [], ret=9))]]})
        result = self.run_session(cfg=flow_config(), game_s=script)
        self.assertEqual(result["status"], "failed")
        self.assertNotIn(0x1D03, self.sent_ops(12020))
        # Sem lista completa não se afirma ausência: todos os produtos ficam em erro.
        self.assertEqual({i["status"] for i in result["items"]}, {selection.ERRO})
        self.assertEqual(self.records[-1]["items_error"], 4)

    def test_explicit_detail_requests_override_selection_without_duplicates(self):
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(1002)]))]],
            0x1D03: [[(0x1D04, detail_1d04(1003))]],
        })
        cfg = flow_config(detail_requests=[{"item_index": 1003, "trailing_u8": 0},
                                           {"item_index": 1003, "trailing_u8": 0}])
        result = self.run_session(cfg=cfg, game_s=script)
        self.assertEqual(self.sent_ops(12020).count(0x1D03), 1)
        states = {i["item_index"]: i["status"] for i in result["items"]}
        # 1002 apareceu na lista mas não foi consultado: erro explícito, não "sem ofertas".
        self.assertEqual(states[1002], selection.ERRO)

    def test_custom_products_map_from_config(self):
        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(4242)]))]],
            0x1D03: [[(0x1D04, detail_1d04(4242, [offer_bytes(9, 0, 30, index=4242)]))]],
        })
        cfg = flow_config(products={"4242": "Produto Do Operador"})
        result = self.run_session(cfg=cfg, game_s=script)
        self.assertEqual(result["status"], "completed", result["diagnostic"])
        self.assertEqual([(i["item_index"], i["produto"], i["status"]) for i in result["items"]],
                         [(4242, "Produto Do Operador", selection.COM_OFERTAS)])


class MainWritesReportsTest(unittest.TestCase):
    """`python -m rfnext_market` grava resultado.jsonl + os dois CSV."""

    def test_cli_writes_jsonl_and_two_csv(self):
        from unittest import mock

        from rfnext_market import __main__ as cli

        script = game_with({
            0x1D01: [[(0x1D02, list_1d02(1, [agg(1002, 0, 2, 5.0, 9.0)]))]],
            0x1D03: [[(0x1D04, detail_1d04(1002, [offer_bytes(1, 0, 20, item_id=2**63)]))]],
        })
        cfg = flow_config()
        clock, log = ts.Clock(), []
        scripts = {cfg["auth"]["port"]: ts.auth_script(), cfg["game"]["port"]: script}

        def factory(host, port, timeout):
            return ts.FakeConn(port, scripts[port], clock, log)

        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            out = tmp / "resultado.jsonl"
            with mock.patch.object(cli, "load_config", return_value=cfg), \
                    mock.patch("rfnext_market.session.Connection", factory), \
                    mock.patch("rfnext_market.session.time", clock):
                code = cli.main(["--config", str(tmp / "config.json"), "--output", str(out)])
            self.assertEqual(code, 0)
            records = [json.loads(line) for line in out.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(records[-1]["record_type"], "completion")
            self.assertEqual(records[-1]["offers_total"], 1)
            self.assertTrue(any(r["record_type"] == "frame" for r in records))
            summary = tmp / "mercado_resumo.csv"
            offers = tmp / "mercado_ofertas.csv"
            with open(summary, encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
            self.assertEqual(len(rows), 4)
            self.assertEqual(rows[0]["produto"], "Secret Nemesis Base Permit Extension")
            with open(offers, encoding="utf-8-sig", newline="") as handle:
                offer_rows = list(csv.DictReader(handle))
            self.assertEqual(offer_rows[0]["item_id"], str(2**63))
            self.assertEqual(offer_rows[0]["account_id"], "0")


if __name__ == "__main__":
    unittest.main()


