"""Agente 6 - seleção de itens (Agente 3): mapa de produtos, estados e pedidos 0x1D03."""
import unittest

from rfnext_market import selection


def aggregate(item_index, enchant=0, registered=1, lowest=1.0, highest=2.0):
    return {"item_index": item_index, "enchant_level": enchant, "lowest_price": lowest,
            "highest_price": highest, "number_of_registered_items": registered}


class ProductsTest(unittest.TestCase):
    def test_default_map_comes_from_instructions(self):
        self.assertEqual(selection.load_products({}), {
            1002: "Secret Nemesis Base Permit Extension",
            1007: "Albern Crater Permit Extension",
            1006: "Exclusive Mining Field Permit Extension",
            1003: "Mining Field Permit Extension (Accretia)",
        })
        self.assertEqual(list(selection.load_products(None)), [1002, 1007, 1006, 1003])

    def test_config_map_string_keys_become_int(self):
        products = selection.load_products({"products": {"5": "Cinco", "9": "Nove"}})
        self.assertEqual(products, {5: "Cinco", 9: "Nove"})

    def test_default_map_is_a_copy(self):
        selection.load_products({})[1002] = "mudado"
        self.assertEqual(selection.PRODUCTS[1002], "Secret Nemesis Base Permit Extension")

    def test_invalid_maps_are_rejected(self):
        for bad in ({"products": {}}, {"products": []}, {"products": {"x": "n"}},
                    {"products": {"5": ""}}, {"products": {"5": 7}},
                    {"products": {"4294967296": "n"}}):
            with self.assertRaises(ValueError):
                selection.load_products(bad)

    def test_duplicate_item_index_in_map_is_rejected(self):
        with self.assertRaises(ValueError):
            selection.load_products({"products": {"5": "a", " 5": "b"}})


class SelectTest(unittest.TestCase):
    def test_absent_present_and_zero_registered(self):
        entries = [aggregate(1002), aggregate(1003, registered=0), aggregate(4242)]
        picked = selection.select(entries)
        self.assertEqual([s["item_index"] for s in picked], [1002, 1007, 1006, 1003])
        by_index = {s["item_index"]: s for s in picked}
        self.assertEqual(by_index[1002]["status"], selection.SEM_OFERTAS)
        self.assertTrue(by_index[1002]["found_in_list"])
        self.assertEqual(by_index[1007]["status"], selection.AUSENTE)
        self.assertFalse(by_index[1007]["found_in_list"])
        self.assertEqual(by_index[1003]["registered_items"], 0)
        # Item fora do mapa nunca entra na seleção (nome não é inferido de ID).
        self.assertNotIn(4242, by_index)

    def test_names_come_from_map_only(self):
        picked = selection.select([aggregate(1006)], {1006: "Nome Do Operador"})
        self.assertEqual(picked[0]["produto"], "Nome Do Operador")

    def test_multiple_enchant_levels_are_aggregated(self):
        entries = [aggregate(1002, enchant=0, registered=2, lowest=5.0, highest=9.0),
                   aggregate(1002, enchant=3, registered=1, lowest=1.0, highest=4.0)]
        picked = {s["item_index"]: s for s in selection.select(entries)}[1002]
        self.assertEqual(len(picked["aggregates"]), 2)
        self.assertEqual(picked["registered_items"], 3)
        self.assertEqual((picked["lowest_price"], picked["highest_price"]), (1.0, 9.0))

    def test_absent_item_has_no_prices(self):
        picked = {s["item_index"]: s for s in selection.select([])}[1002]
        self.assertIsNone(picked["lowest_price"])
        self.assertIsNone(picked["highest_price"])
        self.assertEqual(picked["aggregates"], [])


class DetailRequestsTest(unittest.TestCase):
    def test_only_found_items_without_duplicates(self):
        entries = [aggregate(1002), aggregate(1002, enchant=1), aggregate(1003)]
        requests = selection.detail_requests(selection.select(entries))
        self.assertEqual(requests, [{"item_index": 1002, "trailing_u8": 0},
                                    {"item_index": 1003, "trailing_u8": 0}])

    def test_trailing_u8_is_configurable_and_validated(self):
        picked = selection.select([aggregate(1002)])
        self.assertEqual(selection.detail_requests(picked, 1)[0]["trailing_u8"], 1)
        for bad in (-1, 256, 1.0, True, "0"):
            with self.assertRaises(ValueError):
                selection.detail_requests(picked, bad)

    def test_no_requests_when_nothing_found(self):
        self.assertEqual(selection.detail_requests(selection.select([])), [])


if __name__ == "__main__":
    unittest.main()
