"""Servidor simulado (somente loopback) para os testes de integração.

REGRAS ARTIFICIAIS deste simulador (nenhuma delas é fato confirmado do servidor real;
ver CONTRACTS.md para o que a captura de fato mostra):

1. Loopback apenas: cada ``ScriptedServer`` abre um socket TCP em 127.0.0.1 com porta
   efêmera (porta 0) e aceita exatamente uma conexão. Não há suporte a múltiplos
   clientes nem a endereços externos.
2. Vínculo de sessão: o simulador NÃO reproduz nenhuma regra real de vínculo entre a
   conexão 12000 e a 12020 (esse vínculo está marcado como não confirmado em
   CONTRACTS.md). Ele apenas verifica, em cada conexão de forma independente, se o
   primeiro campo string do payload (``account_id`` em 0x0101/0x0103) é igual ao
   ``valid_account_id`` configurado para aquele servidor. Isso é só uma conveniência de
   teste, não uma verdade de protocolo.
3. Sequência: contador esperado por conexão (uma direção por vez, servidor só recebe
   C->S), começa em 0, mod 256. Um quadro fora de ordem faz o simulador fechar a
   conexão imediatamente — é uma regra artificial de teste; o servidor real pode reagir
   de outra forma (não observado na captura).
4. Conteúdo dos pedidos: além do account_id (``check_account=True``), o roteiro aceita
   ``expect_payload`` (bytes exatos, ou callable(payload) -> bool) para conferir sequência
   e conteúdo de qualquer outro opcode roteirizado. Sem ``expect_payload`` num opcode,
   nenhum outro campo dele (JWT, session_key, device_info, MAC) é validado; um payload
   mal formado no account_id, ou reprovado por ``expect_payload``, conta como pedido
   inválido (mesmo tratamento: reject_response se houver, senão fecha a conexão).
5. Layout sintético das respostas 12000 0x0102/0x0108 e 12020 0x0102/0x0104/0x0106:
   os campos confirmados/parciais de ``auth.LAYOUTS`` são preenchidos com valores
   sintéticos; os bytes "unknown_@..." são preenchidos com zero só aqui, no simulador —
   isso é aceitável para gerar fixtures de teste, mas não deve ser lido como hipótese
   sobre o conteúdo real desses bytes (auth.py, ao processar dados reais, nunca faz
   esse preenchimento).
6. Mercado sem 0x0201: o simulador responde a 0x1D01/0x1D03 assim que chegam, sem exigir
   nenhuma mensagem de 0x0201 nem qualquer outra mensagem que o cliente oficial envia
   antes do mercado (não confirmado se o servidor real exige isso).
7. Compressão LZ4 das respostas: ``lz4_literals_only`` produz sempre um bloco só de
   literais (sem sequências de cópia), o que é válido para o descompressor mas mais
   simples do que os blocos reais, que podem conter cópias.
8. Opcodes não roteirizados (ausentes do dict ``script`` passado ao servidor) são
   ignorados silenciosamente — servem para representar mensagens assíncronas do
   cliente que este simulador não precisa responder (ex.: heartbeats 0x0103/0x0105).
"""
from __future__ import annotations

import socket
import struct
import threading
import time

from rfnext_market import protocol

_DEFAULT_SEED = 0x05


# ---- construção de bytes à mão (não usa auth.build_payload nem market.build_payload) ----

def _str(text: str) -> bytes:
    raw = text.encode("utf-16le")
    return struct.pack("<H", len(raw) // 2) + raw


def _read_account_id(payload: bytes) -> str:
    """Lê só o primeiro campo string (account_id em 0x0101/0x0103); não interpreta o resto."""
    if len(payload) < 2:
        raise ValueError("payload curto demais para account_id")
    (units,) = struct.unpack_from("<H", payload, 0)
    end = 2 + units * 2
    if end > len(payload):
        raise ValueError("account_id truncado")
    return payload[2:end].decode("utf-16le")


def lz4_literals_only(data: bytes) -> bytes:
    """Bloco LZ4 válido, só literais (sem sequência de cópia), como descrito na regra 7."""
    out = bytearray()
    n = len(data)
    if n < 0x0F:
        out.append(n << 4)
    else:
        out.append(0x0F << 4)
        rem = n - 0x0F
        while True:
            chunk = min(rem, 0xFF)
            out.append(chunk)
            rem -= chunk
            if chunk < 0xFF:
                break
    out += data
    return bytes(out)


def _obfuscate(frame: bytes, seed: int) -> bytes:
    """Rolling XOR reescrito à mão: protocol.apply_rolling_xor só serve para quadros
    C->S sem LZ4 (sempre zera o bit 0x40); o servidor simulado precisa manter esse bit."""
    data = bytearray(frame)
    state = data[0] ^ 0xEF
    for index in range(1, len(data)):
        data[index] ^= state
        state = data[index] ^ ((-0x11 * index) & 0xFF)
    return bytes(data)


def build_wire(opcode: int, payload: bytes, sequence: int, *, seed: int = _DEFAULT_SEED,
               compressed: bool = False) -> bytes:
    """Monta um quadro S->C à mão a partir do cabeçalho de 6 bytes do canônico."""
    body = lz4_literals_only(bytes(payload)) if compressed else bytes(payload)
    length = protocol.HEADER_SIZE + len(body)
    if length > protocol.MAX_FRAME:
        raise ValueError(f"quadro de {length} bytes excede MAX_FRAME")
    flags = 0x80 | (0x40 if compressed else 0) | (seed & 0x3F)
    header = (bytes([flags]) + length.to_bytes(2, "little") + bytes([sequence & 0xFF])
              + opcode.to_bytes(2, "little"))
    return _obfuscate(header + body, seed)


# ---- payloads sintéticos das respostas (layouts de auth.LAYOUTS/market.py, à mão) ----

def auth_0102_payload(*, result_code: int = 0, heartbeat_ms: int = 3000) -> bytes:
    return (struct.pack("<HQI", result_code, 1_700_000_000_000, heartbeat_ms) + bytes(3)
            + struct.pack("<QB", 1_700_000_000_500, 0) + bytes(10) + _str("BR") + _str("BR"))


def auth_0108_payload(*, result_code: int = 0, world_id: int = 1, f4: int = 0, f6: int = 0,
                       game_host: str = "127.0.0.1", game_port: int = 12020) -> bytes:
    return (struct.pack("<HHHQH", result_code, world_id, f4, f6, 0)
            + _str(game_host) + struct.pack("<H", game_port))


def game_0102_payload() -> bytes:
    return struct.pack("<HB", 0, 0) + _str("PROD_TEST") + struct.pack("<H", 0)


def game_0104_payload() -> bytes:
    return struct.pack("<HQHQ", 1, 0x1122, 2, 0x1122) + _str("rfnext")


def game_0106_payload() -> bytes:
    return bytes(4)


def market_1d02_payload(entries, *, is_end: bool, server_type: int = 0, ret: int = 0) -> bytes:
    """entries: iterável de (item_index, enchant_level, lowest, highest, registered)."""
    out = struct.pack("<HBBH", ret, int(is_end), server_type, len(entries))
    for item_index, enchant, lowest, highest, registered in entries:
        out += struct.pack("<IHddI", item_index, enchant, lowest, highest, registered)
    return out


def market_1d04_payload(*, item_index: int, offers, is_end: bool = True,
                         server_type: int = 0, ret: int = 0) -> bytes:
    """offers: iterável de dicts com as chaves de market._offer (ver market.py)."""
    out = struct.pack("<HIBBH", ret, item_index, int(is_end), server_type, len(offers))
    for offer in offers:
        info = offer["item_info"]
        out += struct.pack("<QQQ", offer["exchange_index"], offer["account_id"], offer["pc_id"])
        out += struct.pack("<QIQBH", info["id"], info["index"], info["count"],
                            int(info["lock"]), info["enchant_level"])
        out += struct.pack("<H", 0)  # talic_count = 0 (nenhum talic sintético)
        out += struct.pack("<H", 0)  # option_count = 0 (nenhuma opção sintética)
        out += struct.pack("<BQ", int(info["is_broken"]), info["expire_time"])
        out += struct.pack("<QQQQQB", offer["registed_time"], offer["expired_time"],
                            offer["selling_time"], offer["selling_price"],
                            offer["settlement_price"], int(offer["is_forc_expire"]))
    return out


def _send_frames(sock: socket.socket, wires: list[bytes], mode: str) -> None:
    if mode == "concat":
        sock.sendall(b"".join(wires))
    elif mode == "fragment":
        blob = b"".join(wires)
        for i in range(0, len(blob), 5):
            sock.sendall(blob[i:i + 5])
            time.sleep(0.001)
    else:
        for wire in wires:
            sock.sendall(wire)


class ScriptedServer:
    """Servidor de uma conexão em loopback, roteirizado por opcode recebido.

    ``script``: dict opcode -> {
        "reply": [(opcode, payload, compressed), ...]  # quadros enviados em ordem
        "mode": "normal" | "concat" | "fragment"        # como os "reply" são enviados
        "close": bool                                    # fecha a conexão após responder
        "check_account": bool                             # confere account_id (regra 2/4)
        "expect_payload": bytes | callable(bytes) -> bool  # confere sequência/conteúdo (regra 4)
        "silence": bool                                    # não responde (usado p/ timeout)
    }
    Opcodes ausentes do script são ignorados (regra 8).
    """

    def __init__(self, script: dict, *, valid_account_id: str = "synthetic",
                 reject_response: tuple | None = None, port: int = 0):
        # port=0 (padrão) usa uma porta efêmera. session.py escolhe ALLOWED_SENDS pela
        # seção do config (auth/game), não pelo número de porta, então os testes de
        # integração via session.run podem (e devem) usar portas efêmeras, passando
        # srv.port para _config.
        self.script = script
        self.valid_account_id = valid_account_id
        self.reject_response = reject_response
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind(("127.0.0.1", port))
        self._sock.listen(1)
        self.port = self._sock.getsockname()[1]
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._serve, daemon=True)
        self._thread.start()

    def close(self) -> None:
        # accept() usa timeout curto (ver _serve) para que o close() de um teste nunca
        # deixe a porta presa num accept() ainda bloqueado na outra thread.
        self._stop.set()
        try:
            self._sock.close()
        except OSError:
            pass
        self._thread.join(timeout=1.0)

    def _serve(self) -> None:
        self._sock.settimeout(0.1)
        conn = None
        while not self._stop.is_set():
            try:
                conn, _addr = self._sock.accept()
                break
            except socket.timeout:
                continue
            except OSError:
                return
        if conn is None:
            return
        conn.settimeout(5.0)
        buf = protocol.FrameBuffer()
        recv_seq = 0
        send_seq = 0
        try:
            while True:
                chunk = conn.recv(4096)
                if not chunk:
                    return
                for wire in buf.feed(chunk):
                    frame = protocol.decode_frame(wire)
                    if frame["sequence"] != recv_seq:
                        return  # regra artificial 3: sequência errada encerra a conexão
                    recv_seq = (recv_seq + 1) & 0xFF
                    spec = self.script.get(frame["opcode"])
                    if spec is None:
                        continue  # regra artificial 8
                    ok = True
                    if spec.get("check_account"):
                        try:
                            ok = _read_account_id(frame["payload"]) == self.valid_account_id
                        except ValueError:
                            ok = False
                    if ok and "expect_payload" in spec:
                        expected = spec["expect_payload"]
                        ok = expected(frame["payload"]) if callable(expected) else frame["payload"] == expected
                    if not ok:
                        if self.reject_response is not None:
                            op, payload, comp = self.reject_response
                            conn.sendall(build_wire(op, payload, send_seq, compressed=comp))
                        return
                    if spec.get("silence"):
                        continue
                    replies = spec.get("reply", [])
                    wires = [build_wire(op, payload, send_seq + i, compressed=comp)
                             for i, (op, payload, comp) in enumerate(replies)]
                    send_seq = (send_seq + len(wires)) & 0xFF
                    if wires:
                        _send_frames(conn, wires, spec.get("mode", "normal"))
                    if spec.get("close"):
                        return
        except (ConnectionError, OSError, ValueError):
            return
        finally:
            conn.close()
