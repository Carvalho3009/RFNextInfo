"""Testes de integração: session.run contra o ScriptedServer (sockets TCP reais em
127.0.0.1). Credenciais e payloads são sintéticos; ver mock_server.py para as regras
artificiais do simulador.

Conformidade coberta aqui é "local": session.run contra este simulador de loopback.
Nada disso confirma comportamento do servidor real (ver relatório final)."""
import socket
import struct
import time
import unittest

from rfnext_market import auth, protocol, session
from rfnext_market.transport import DIRECTION_C2S
from tests.mock_server import (
    ScriptedServer, auth_0102_payload, auth_0108_payload, build_wire,
    game_0102_payload, game_0104_payload, game_0106_payload,
    market_1d02_payload, market_1d04_payload,
)

ACCOUNT_ID = "synthetic"


def _s16(text: str) -> bytes:
    raw = text.encode("utf-16le")
    return struct.pack("<H", len(raw) // 2) + raw


def _credentials() -> dict:
    """Preenche REQUIRED_FIELDS a partir de auth.LAYOUTS com valores sintéticos, exceto os
    campos derivados em tempo de execução por session.run (session.DERIVED_FIELDS):
    world_id (12000 0x0107) e u64@2688 (12020 0x0103, ver session.py)."""
    fake = {"str": ACCOUNT_ID, "u8": 0, "u16": 4, "u32": 0, "u64": 0}
    out = {}
    for (port, direction, op), (_name, _status, spec) in auth.LAYOUTS.items():
        if direction != DIRECTION_C2S or (port, op) == (12000, 0x0107):
            continue
        for name, kind in spec:
            if name == "u64@2688":
                continue  # derivado por session.run a partir do 0x0108 da 12000
            if isinstance(kind, tuple):
                out[name + "_hex"] = "00" * (kind[1] or 1)
            elif kind == "str" and name == "account_id":
                out[name] = ACCOUNT_ID
            else:
                out[name] = fake[kind]
    return out


def _config(auth_port: int, game_port: int, **overrides) -> dict:
    cfg = {
        "auth": {"host": "127.0.0.1", "port": auth_port, "timeout": 0.6},
        "game": {"host": "127.0.0.1", "port": game_port, "timeout": 0.6},
        "world_id": 1,
        "credentials": _credentials(),
        "market": {"list_requests": [], "detail_requests": [], "response_timeout": 0.6},
    }
    cfg.update(overrides)
    return cfg


HAPPY_AUTH_SCRIPT = {
    0x0101: {"check_account": True, "reply": [(0x0102, auth_0102_payload(), False)]},
    0x0105: {"reply": [(0x0106, b"\x00" * 4, False)]},
    0x0107: {"reply": [(0x0108, auth_0108_payload(), False)]},
}


def _happy_game_script(*, list_replies=(), detail_replies=(), list_mode="normal",
                        detail_mode="normal", async_before_0104=None):
    reply_0103 = list(async_before_0104 or []) + [(0x0104, game_0104_payload(), False)]
    script = {
        0x0101: {"reply": [(0x0102, game_0102_payload(), False)]},
        0x0103: {"check_account": True, "reply": reply_0103},
        0x0105: {"reply": [(0x0106, game_0106_payload(), False)]},
    }
    if list_replies:
        script[0x1D01] = {"reply": list(list_replies), "mode": list_mode}
    if detail_replies:
        script[0x1D03] = {"reply": list(detail_replies), "mode": detail_mode}
    return script


def _run(auth_script, game_script, **config_overrides):
    auth_script = dict(auth_script)
    auth_script.setdefault(0x0105, HAPPY_AUTH_SCRIPT[0x0105])
    auth_srv = ScriptedServer(auth_script, valid_account_id=ACCOUNT_ID,
                               reject_response=(0x0102, auth_0102_payload(result_code=7), False),
                               port=0)
    game_srv = ScriptedServer(game_script, valid_account_id=ACCOUNT_ID, port=0)
    try:
        records = []
        result = session.run(_config(auth_srv.port, game_srv.port, **config_overrides), records.append)
        return result, records
    finally:
        auth_srv.close()
        game_srv.close()


class HandshakeAndMarketTest(unittest.TestCase):
    def test_auth_rejected_invalid_credential(self):
        # Credenciais válidas para o simulador de mercado, mas erradas para o de auth.
        auth_srv = ScriptedServer(HAPPY_AUTH_SCRIPT, valid_account_id="expected-account",
                                   reject_response=(0x0102, auth_0102_payload(result_code=7), False),
                                   port=0)
        game_srv = ScriptedServer(_happy_game_script(), valid_account_id=ACCOUNT_ID, port=0)
        try:
            records = []
            result = session.run(_config(auth_srv.port, game_srv.port), records.append)
        finally:
            auth_srv.close()
            game_srv.close()
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["stage"], "12000:0x0101")
        self.assertIn("rejeitado", result["diagnostic"])
        self.assertIsNone(result["authenticated"])

    def test_timeout_waiting_for_response(self):
        script = {0x0101: {"check_account": True, "silence": True}}
        result, _records = _run(script, _happy_game_script())
        self.assertEqual(result["status"], "failed")
        self.assertIn("timeout", result["diagnostic"])
        self.assertEqual(result["stage"], "12000:0x0101")

    def test_disconnect_mid_handshake(self):
        script = {0x0101: {"check_account": True, "close": True}}  # fecha sem responder
        result, _records = _run(script, _happy_game_script())
        self.assertEqual(result["status"], "failed")
        self.assertIn("desconex", result["diagnostic"])

    def test_happy_path_handshake_only(self):
        result, records = _run(HAPPY_AUTH_SCRIPT, _happy_game_script())
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["stage"], "done")
        # market snapshot fica vazio: nenhuma consulta configurada.
        self.assertEqual(result["market"]["queries"], [])
        record_types = {r.get("record_type") for r in records if isinstance(r, dict)}
        self.assertIn("frame", record_types)
        self.assertIn("completion", record_types)

    def test_async_messages_interleaved(self):
        # Quadro assíncrono (opcode não tratado por session/auth) antes da resposta real.
        decoy = (0x0206, bytes.fromhex("0102030405"), False)
        auth_script = dict(HAPPY_AUTH_SCRIPT)
        auth_script[0x0101] = {"check_account": True,
                                "reply": [decoy, (0x0102, auth_0102_payload(), False)]}
        game_script = _happy_game_script(async_before_0104=[decoy])
        result, records = _run(auth_script, game_script)
        self.assertEqual(result["status"], "completed")
        opcodes_seen = [r["opcode"] for r in records
                        if isinstance(r, dict) and r.get("record_type") == "frame" and "opcode" in r]
        self.assertIn(0x0206, opcodes_seen)

    def test_market_list_multi_frame_lz4_fragmented_and_concatenated(self):
        entries_a = [(1000000 + i, 0, 10.0 + i, 20.0 + i, 5) for i in range(3)]
        entries_b = [(2000000, 1, 11.0, 22.0, 2)]
        list_replies = [
            (0x1D02, market_1d02_payload(entries_a, is_end=False), True),
            (0x1D02, market_1d02_payload(entries_b, is_end=True), True),
        ]
        game_script = _happy_game_script(list_replies=list_replies, list_mode="concat")
        result, _records = _run(
            HAPPY_AUTH_SCRIPT, game_script,
            market={"list_requests": [{"payload_hex": "0000"}], "detail_requests": [],
                    "response_timeout": 0.6},
        )
        self.assertEqual(result["status"], "completed")
        queries = result["market"]["queries"]
        self.assertEqual(len(queries), 1)
        self.assertTrue(queries[0]["complete"])
        self.assertEqual(len(queries[0]["entries"]), len(entries_a) + len(entries_b))
        self.assertEqual(queries[0]["frames"], 2)

    def test_market_detail_0x1d04_fragmented(self):
        offer = {
            "exchange_index": 1, "account_id": 42, "pc_id": 7,
            "item_info": {"id": 555, "index": 1000001, "count": 1, "lock": False,
                          "enchant_level": 0, "is_broken": False, "expire_time": 0},
            "registed_time": 0, "expired_time": 0, "selling_time": 0,
            "selling_price": 100, "settlement_price": 90, "is_forc_expire": False,
        }
        detail_replies = [(0x1D04, market_1d04_payload(item_index=1000001, offers=[offer]), False)]
        game_script = _happy_game_script(detail_replies=detail_replies, detail_mode="fragment")
        result, _records = _run(
            HAPPY_AUTH_SCRIPT, game_script,
            market={"list_requests": [], "detail_requests": [{"item_index": 1000001, "trailing_u8": 0}],
                    "response_timeout": 0.6},
        )
        self.assertEqual(result["status"], "completed")
        queries = result["market"]["queries"]
        self.assertEqual(len(queries), 1)
        self.assertTrue(queries[0]["complete"])
        self.assertEqual(len(queries[0]["entries"]), 1)
        self.assertEqual(queries[0]["entries"][0]["account_id"], 42)


def _field_check(port, opcode, name, expected):
    """expect_payload que decodifica com auth.parse_message (já testado em test_auth.py)
    e confere um campo específico. Evita depender do offset absoluto num payload de
    tamanho variável (strings precedentes), o que uma comparação de bytes fixa não
    suportaria sem reimplementar auth.build_payload à mão."""
    def check(payload):
        parsed = auth.parse_message(port, DIRECTION_C2S, opcode, payload)
        return parsed["fields"].get(name) == expected
    return check


class RequestContentTest(unittest.TestCase):
    """Confere sequência e conteúdo dos pedidos (não só account_id) via expect_payload,
    cobrindo os casos que a revisão apontou como não verificados."""

    def test_world_id_sent_in_0x0107(self):
        auth_script = {
            0x0101: HAPPY_AUTH_SCRIPT[0x0101],
            0x0107: {"expect_payload": struct.pack("<H", 7),
                      "reply": [(0x0108, auth_0108_payload(world_id=7), False)]},
        }
        result, _records = _run(auth_script, _happy_game_script(), world_id=7)
        self.assertEqual(result["status"], "completed")

    def test_game_0101_payload_matches_credential(self):
        creds = _credentials()
        creds["unknown_@0_hex"] = "04"  # amostra real da captura (CONTRACTS.md)
        game_script = _happy_game_script()
        game_script[0x0101] = dict(game_script[0x0101], expect_payload=bytes.fromhex("04"))
        result, _records = _run(HAPPY_AUTH_SCRIPT, game_script, credentials=creds)
        self.assertEqual(result["status"], "completed")

    def test_market_list_0x1d01_payload_exact_bytes(self):
        game_script = _happy_game_script(
            list_replies=[(0x1D02, market_1d02_payload([], is_end=True), False)])
        game_script[0x1D01] = dict(game_script[0x1D01], expect_payload=bytes.fromhex("0101"))
        result, _records = _run(
            HAPPY_AUTH_SCRIPT, game_script,
            market={"list_requests": [{"payload_hex": "0101"}], "detail_requests": [],
                    "response_timeout": 0.6})
        self.assertEqual(result["status"], "completed")

    def test_market_detail_0x1d03_item_index_and_trailing_u8(self):
        offer_reply = market_1d04_payload(item_index=555, offers=[], server_type=9)
        game_script = _happy_game_script(detail_replies=[(0x1D04, offer_reply, False)])
        game_script[0x1D03] = dict(game_script[0x1D03],
                                    expect_payload=struct.pack("<IB", 555, 9))
        result, _records = _run(
            HAPPY_AUTH_SCRIPT, game_script,
            market={"list_requests": [], "response_timeout": 0.6,
                    "detail_requests": [{"item_index": 555, "trailing_u8": 9}]})
        self.assertEqual(result["status"], "completed")

    def test_0x0103_carries_u64_2688_derived_from_0x0108(self):
        # link_value = f4 | (f6 << 16), ver session.py: derivado do 0x0108 da 12000, não
        # fornecido pelas credenciais (u64@2688 está em session.DERIVED_FIELDS).
        f4, f6 = 0x1234, 0x0102030405060708
        link_value = (f4 | (f6 << 16)) & 0xFFFFFFFFFFFFFFFF
        auth_script = {
            0x0101: HAPPY_AUTH_SCRIPT[0x0101],
            0x0107: {"reply": [(0x0108, auth_0108_payload(f4=f4, f6=f6), False)]},
        }
        game_script = _happy_game_script()
        game_script[0x0103] = dict(
            game_script[0x0103], check_account=True,
            expect_payload=_field_check(12020, 0x0103, "u64@2688", link_value))
        result, _records = _run(auth_script, game_script)
        self.assertEqual(result["status"], "completed")

    def test_0x0103_rejected_when_u64_2688_wrong(self):
        # Confirma que o mock realmente fecha/rejeita quando expect_payload reprova
        # (senão os dois testes acima passariam mesmo com um servidor mudo).
        game_script = _happy_game_script()
        game_script[0x0103] = dict(
            game_script[0x0103], check_account=True,
            expect_payload=_field_check(12020, 0x0103, "u64@2688", 0xDEADBEEF))
        result, _records = _run(HAPPY_AUTH_SCRIPT, game_script)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["stage"], "12020:0x0103")

    def test_12020_device_info_differs_from_12000(self):
        # 12020 0x0103 tem seu próprio device_info (sub-chave "12020_0x0103"), diferente
        # do device_info top-level usado no 0x0101 da 12000 (CONTRACTS.md: "compare campos
        # do 0x0103 com respostas da 12000" -- aqui comparamos os dois device_info entre si).
        creds = _credentials()
        creds["device_info"] = "top-level-device"
        creds["12020_0x0103"] = {"device_info": "game-device"}
        auth_script = {
            0x0101: dict(HAPPY_AUTH_SCRIPT[0x0101],
                         expect_payload=_field_check(12000, 0x0101, "device_info",
                                                      "top-level-device")),
            0x0107: HAPPY_AUTH_SCRIPT[0x0107],
        }
        game_script = _happy_game_script()
        game_script[0x0103] = dict(
            game_script[0x0103], check_account=True,
            expect_payload=_field_check(12020, 0x0103, "device_info", "game-device"))
        result, _records = _run(auth_script, game_script, credentials=creds)
        self.assertEqual(result["status"], "completed")


class ScriptedServerUnitTest(unittest.TestCase):
    """Testa o próprio simulador diretamente (sem session.py), com sockets crus."""

    def test_rejects_out_of_order_sequence(self):
        srv = ScriptedServer({0x0101: {"check_account": True,
                                        "reply": [(0x0102, auth_0102_payload(), False)]}},
                              valid_account_id=ACCOUNT_ID)
        try:
            sock = socket.create_connection(("127.0.0.1", srv.port), timeout=2.0)
            wire = protocol.encode_frame(0x0101, _s16(ACCOUNT_ID), sequence=5, seed=0x10)
            sock.sendall(wire)
            time.sleep(0.05)
            self.assertEqual(sock.recv(4096), b"")  # servidor fechou: sequência errada
            sock.close()
        finally:
            srv.close()

    def test_rejects_invalid_account_id_without_reject_response(self):
        srv = ScriptedServer({0x0101: {"check_account": True,
                                        "reply": [(0x0102, auth_0102_payload(), False)]}},
                              valid_account_id="expected-only")
        try:
            sock = socket.create_connection(("127.0.0.1", srv.port), timeout=2.0)
            wire = protocol.encode_frame(0x0101, _s16(ACCOUNT_ID), sequence=0, seed=0x10)
            sock.sendall(wire)
            time.sleep(0.05)
            self.assertEqual(sock.recv(4096), b"")  # sem reject_response: só fecha
            sock.close()
        finally:
            srv.close()

    def test_accepts_valid_account_id_and_replies(self):
        srv = ScriptedServer({0x0101: {"check_account": True,
                                        "reply": [(0x0102, auth_0102_payload(result_code=0), False)]}},
                              valid_account_id=ACCOUNT_ID)
        try:
            sock = socket.create_connection(("127.0.0.1", srv.port), timeout=2.0)
            wire = protocol.encode_frame(0x0101, _s16(ACCOUNT_ID), sequence=0, seed=0x10)
            sock.sendall(wire)
            buf = protocol.FrameBuffer()
            chunk = sock.recv(4096)
            frames = buf.feed(chunk)
            self.assertEqual(len(frames), 1)
            frame = protocol.decode_frame(frames[0])
            self.assertEqual(frame["opcode"], 0x0102)
            sock.close()
        finally:
            srv.close()

    def test_expect_payload_mismatch_without_reject_response_closes(self):
        srv = ScriptedServer({0x0101: {"expect_payload": b"\x01\x02"}})
        try:
            sock = socket.create_connection(("127.0.0.1", srv.port), timeout=2.0)
            wire = protocol.encode_frame(0x0101, b"\x09\x09", sequence=0, seed=0x10)
            sock.sendall(wire)
            time.sleep(0.05)
            self.assertEqual(sock.recv(4096), b"")  # payload diferente do esperado: fecha
            sock.close()
        finally:
            srv.close()

    def test_expect_payload_match_replies_normally(self):
        srv = ScriptedServer({0x0101: {"expect_payload": b"\x01\x02",
                                        "reply": [(0x0102, auth_0102_payload(), False)]}})
        try:
            sock = socket.create_connection(("127.0.0.1", srv.port), timeout=2.0)
            wire = protocol.encode_frame(0x0101, b"\x01\x02", sequence=0, seed=0x10)
            sock.sendall(wire)
            buf = protocol.FrameBuffer()
            frames = buf.feed(sock.recv(4096))
            self.assertEqual(len(frames), 1)
            self.assertEqual(protocol.decode_frame(frames[0])["opcode"], 0x0102)
            sock.close()
        finally:
            srv.close()

    def test_build_wire_lz4_round_trips_through_decode_frame(self):
        payload = market_1d02_payload([(1, 0, 1.0, 2.0, 1)], is_end=True)
        wire = build_wire(0x1D02, payload, sequence=0, compressed=True)
        frame = protocol.decode_frame(wire)
        self.assertTrue(frame["compressed"])
        self.assertEqual(frame["payload"], payload)


if __name__ == "__main__":
    unittest.main()
