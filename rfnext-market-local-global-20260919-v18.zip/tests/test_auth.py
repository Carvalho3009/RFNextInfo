"""Testes de rfnext_market.auth com credenciais sintéticas.

Os testes com a captura (skipUnless) só comparam tamanhos/estrutura e nunca
imprimem nem gravam os valores reais.
"""
import hashlib
import importlib.util
import os
import struct
import unittest
from pathlib import Path

from rfnext_market import auth
from rfnext_market.transport import DIRECTION_C2S as C, DIRECTION_S2C as S


def u16s(text: str) -> bytes:
    raw = text.encode("utf-16le")
    return struct.pack("<H", len(raw) // 2) + raw


LOGIN_12000 = {
    "account_id": "A" * 32,
    "connection_mode": 4,
    "country_code": "ZZ",
    "device_info": '{"I_DeviceID": "synthetic",  "I_World": "1"}',  # espaçamento proposital
    "auth_jwt": "aaa.bbb.ccc",
    "auth_host": "auth.example.invalid",
    "session_key": "0" * 32,
    "joined_country_code": "YY",
    "tail_flag": 1,
    "tail_value": 0,
    "tail_reserved": 0,
    "mac_address": "02-00-00-00-00-01",
}

AUTH_12020 = {
    "account_id": "A" * 32,
    "u8@66": 4,
    "u32@67": 1,
    "u32@71": 30,
    "u32@75": 12345,
    "unknown_@79_hex": "0000000000",
    "joined_country_code": "YY",
    "device_info": '{"I_World": "7"}',
    "u64@2688": 0x0011223344556677,
    "unknown_@2696_hex": "0102030405060708",
    "auth_host": "auth.example.invalid",
    "session_key": "0" * 32,
    "unknown_@2834_hex": "00",
}


class Build12000LoginTest(unittest.TestCase):
    def test_layout_bytes(self):
        payload = auth.build_payload(12000, 0x0101, LOGIN_12000)
        f = LOGIN_12000
        expected = (u16s(f["account_id"]) + struct.pack("<H", 4) + u16s(f["country_code"])
                    + u16s(f["device_info"]) + u16s(f["auth_jwt"]) + u16s(f["auth_host"])
                    + u16s(f["session_key"]) + u16s(f["joined_country_code"])
                    + struct.pack("<BIH", 1, 0, 0) + u16s(f["mac_address"]))
        self.assertEqual(payload, expected)

    def test_round_trip_preserves_device_info_exactly(self):
        payload = auth.build_payload(12000, 0x0101, LOGIN_12000)
        msg = auth.parse_message(12000, C, 0x0101, payload)
        self.assertEqual(msg["fields"], LOGIN_12000)
        self.assertEqual(msg["status"], "confirmed")
        self.assertEqual(msg["unknown_fields"], [])
        self.assertEqual(msg["name"], "ask_connection")

    def test_string_sizes_and_non_ascii(self):
        for value in ["", "x", "y" * 255, "ação-日本", "emoji\U0001F600"]:
            with self.subTest(length=len(value)):
                fields = dict(LOGIN_12000, account_id=value, mac_address=value)
                payload = auth.build_payload(12000, 0x0101, fields)
                units = len(value.encode("utf-16le")) // 2
                self.assertEqual(struct.unpack_from("<H", payload, 0)[0], units)
                self.assertEqual(auth.parse_message(12000, C, 0x0101, payload)["fields"], fields)

    def test_missing_field_names_it(self):
        for key in auth.REQUIRED_FIELDS[(12000, 0x0101)]:
            fields = dict(LOGIN_12000)
            del fields[key]
            with self.assertRaisesRegex(ValueError, key):
                auth.build_payload(12000, 0x0101, fields)

    def test_invalid_values(self):
        bad = [("connection_mode", 70000), ("connection_mode", -1), ("tail_flag", True),
               ("account_id", 5), ("auth_jwt", "\ud800"), ("account_id", "z" * 65536)]
        for key, value in bad:
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, key):
                auth.build_payload(12000, 0x0101, dict(LOGIN_12000, **{key: value}))

    def test_every_truncation_rejected(self):
        payload = auth.build_payload(12000, 0x0101, LOGIN_12000)
        for cut in range(len(payload)):
            with self.subTest(cut=cut), self.assertRaises(ValueError):
                auth.parse_message(12000, C, 0x0101, payload[:cut])

    def test_trailing_and_bad_utf16_rejected(self):
        payload = auth.build_payload(12000, 0x0101, LOGIN_12000)
        with self.assertRaisesRegex(ValueError, "sobrando"):
            auth.parse_message(12000, C, 0x0101, payload + b"\x00")
        with self.assertRaisesRegex(ValueError, "UTF-16"):
            auth.parse_message(12000, C, 0x010C, b"\x01\x00\x00\xd8")


class Other12000Test(unittest.TestCase):
    def test_empty_and_world(self):
        self.assertEqual(auth.build_payload(12000, 0x0103, {}), b"")
        self.assertEqual(auth.build_payload(12000, 0x0105, {}), b"")
        self.assertEqual(auth.build_payload(12000, 0x0107, {"world_id": 5000}), b"\x88\x13")
        self.assertEqual(auth.parse_message(12000, C, 0x0107, b"\x88\x13")["fields"], {"world_id": 5000})
        with self.assertRaisesRegex(ValueError, "world_id"):
            auth.build_payload(12000, 0x0107, {})
        self.assertEqual(auth.parse_message(12000, C, 0x010C, auth.build_payload(
            12000, 0x010C, {"account_id": "B" * 32}))["fields"], {"account_id": "B" * 32})

    def test_0108(self):
        payload = struct.pack("<HHHQH", 0, 7, 1, 2, 0) + u16s("game.example.invalid") + struct.pack("<H", 12020)
        msg = auth.parse_message(12000, S, 0x0108, payload)
        self.assertEqual(msg["fields"]["game_server_host"], "game.example.invalid")
        self.assertEqual(msg["fields"]["game_server_port"], 12020)
        self.assertEqual(msg["fields"]["world_id"], 7)
        with self.assertRaises(ValueError):
            auth.parse_message(12000, S, 0x0108, payload[:-1])

    def test_0102(self):
        payload = (struct.pack("<HQI", 0, 123, 3000) + b"\x01\x02\x03" + struct.pack("<QB", 456, 9)
                   + bytes(range(10)) + u16s("ZZ") + u16s("YY") + b"\xaa" * 31)
        msg = auth.parse_message(12000, S, 0x0102, payload)
        self.assertEqual(msg["fields"]["heartbeat_interval_ms"], 3000)
        self.assertEqual(msg["fields"]["joined_country_code"], "YY")
        self.assertEqual(msg["status"], "partial")
        self.assertEqual([u["offset"] for u in msg["unknown_fields"]], [14, 26, 48])
        self.assertEqual(msg["unknown_fields"][2]["hex"], "aa" * 31)

    def test_unknown_opaque(self):
        msg = auth.parse_message(12000, S, 0x0106, b"\x01\x02")
        self.assertEqual(msg["status"], "unparsed")
        self.assertEqual(msg["unknown_fields"], [{"offset": 0, "hex": "0102", "name": "unknown_@0"}])
        msg = auth.parse_message(12000, C, 0x7777, b"\xff")
        self.assertEqual((msg["name"], msg["status"]), ("unknown_0x7777", "unparsed"))
        with self.assertRaises(ValueError):
            auth.build_payload(12000, 0x0102, {})
        with self.assertRaises(ValueError):
            auth.parse_message(12000, "sideways", 0x0101, b"")


class Port12020Test(unittest.TestCase):
    def test_same_opcode_differs_by_port(self):
        self.assertEqual(auth.parse_message(12020, C, 0x0101, b"\x04")["unknown_fields"][0]["hex"], "04")
        with self.assertRaises(ValueError):
            auth.parse_message(12000, C, 0x0101, b"\x04")

    def test_0101_requires_explicit_byte(self):
        with self.assertRaisesRegex(ValueError, "unknown_@0_hex"):
            auth.build_payload(12020, 0x0101, {})
        self.assertEqual(auth.build_payload(12020, 0x0101, {"unknown_@0_hex": "04"}), b"\x04")

    def test_0103_round_trip_and_lengths(self):
        for text in ["", "x", "é" * 255]:
            with self.subTest(length=len(text)):
                fields = dict(AUTH_12020, device_info=text, auth_host=text)
                payload = auth.build_payload(12020, 0x0103, fields)
                msg = auth.parse_message(12020, C, 0x0103, payload)
                rebuilt = dict(msg["fields"])
                rebuilt.update({u["name"] + "_hex": u["hex"] for u in msg["unknown_fields"]})
                self.assertEqual(rebuilt, fields)
                self.assertEqual(auth.build_payload(12020, 0x0103, rebuilt), payload)

    def test_0103_unknown_bytes_never_defaulted(self):
        for key in ("unknown_@79_hex", "unknown_@2696_hex", "unknown_@2834_hex", "u32@75", "u64@2688"):
            fields = dict(AUTH_12020)
            del fields[key]
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, key):
                auth.build_payload(12020, 0x0103, fields)
        with self.assertRaisesRegex(ValueError, "unknown_@79_hex"):
            auth.build_payload(12020, 0x0103, dict(AUTH_12020, **{"unknown_@79_hex": "00"}))

    def test_0103_truncations(self):
        payload = auth.build_payload(12020, 0x0103, dict(AUTH_12020, **{"unknown_@2834_hex": ""}))
        # o bloco final é "até o fim": só cortes que atingem campos fixos falham
        for cut in range(len(payload)):
            with self.subTest(cut=cut), self.assertRaises(ValueError):
                auth.parse_message(12020, C, 0x0103, payload[:cut])

    def test_0102_0104(self):
        p102 = struct.pack("<HB", 0, 0) + u16s("TEST_ZZ") + struct.pack("<H", 502)
        msg = auth.parse_message(12020, S, 0x0102, p102)
        self.assertEqual(msg["fields"], {"u16@0": 0, "u8@2": 0, "str@3": "TEST_ZZ", "u16@19": 502})
        p104 = struct.pack("<HQHQ", 0, 1, 7, 2) + u16s("abc") + b"\x09\x08"
        msg = auth.parse_message(12020, S, 0x0104, p104)
        self.assertEqual(msg["fields"]["str@20"], "abc")
        self.assertEqual(msg["unknown_fields"], [{"offset": 28, "hex": "0908", "name": "unknown_@34"}])
        self.assertEqual(auth.build_payload(12020, 0x0105, {}), b"")


@unittest.skipUnless(os.environ.get("RFNEXT_CANONICAL_DECODER") and os.environ.get("RFNEXT_REFERENCE_PCAP"),
                     "referência canônica/captura não configurada")
class ReferenceCaptureTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location("rfnext_canonical", os.environ["RFNEXT_CANONICAL_DECODER"])
        d = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(d)
        cls.frames = {}
        pcap = Path(os.environ["RFNEXT_REFERENCE_PCAP"])
        for port in (12000, 12020):
            for label, chunk, _ in d.pcap_tcp_streams(pcap, port):
                direction = S if label.split(" -> ")[0].endswith(f":{port}") else C
                for decoded, info in d.decode_stream(chunk):
                    cls.frames.setdefault((port, direction, info["opcode"]), decoded[6:])
        cls.canonical = d

    def check_exact(self, key):
        payload = self.frames[key]
        msg = auth.parse_message(*key, payload)  # ValueError se não fechar exatamente
        if key[1] == C and (key[0], key[2]) in auth.REQUIRED_FIELDS:
            fields = dict(msg["fields"])
            fields.update({u["name"] + "_hex": u["hex"] for u in msg["unknown_fields"]})
            rebuilt = auth.build_payload(key[0], key[2], fields)
            # compara por hash para não expor bytes em mensagens de falha
            self.assertEqual(hashlib.sha256(rebuilt).digest(), hashlib.sha256(payload).digest())
        return msg

    def test_12000_0101_matches_canonical(self):
        msg = self.check_exact((12000, C, 0x0101))
        ref = self.canonical.parse_login_session_payload(
            b"\x00" * 4 + (0x0101).to_bytes(2, "little") + self.frames[(12000, C, 0x0101)], 12000)["fields"]
        f = msg["fields"]
        for key in ("account_id", "connection_mode", "country_code", "auth_host", "joined_country_code",
                    "tail_flag", "tail_value", "tail_reserved", "mac_address"):
            self.assertTrue(f[key] == ref[key], key)
        self.assertTrue(len(f["auth_jwt"]) == ref["auth_jwt_length"])
        self.assertTrue(len(f["session_key"]) == ref["session_key_length"])

    def test_12020_0103_closes_exactly(self):
        msg = self.check_exact((12020, C, 0x0103))
        login = auth.parse_message(12000, C, 0x0101, self.frames[(12000, C, 0x0101)])["fields"]
        f = msg["fields"]
        for key in ("account_id", "auth_host", "session_key", "joined_country_code"):
            self.assertTrue(f[key] == login[key], key)
        self.assertTrue(len(self.frames[(12020, C, 0x0103)]) == 2835)
        enter = auth.parse_message(12000, S, 0x0108, self.frames[(12000, S, 0x0108)])["fields"]
        self.assertTrue(f["u64@2688"] == (enter["f4"] | (enter["f6"] << 16)) & (2 ** 64 - 1))

    def test_other_reference_frames_close(self):
        for key in [(12000, S, 0x0102), (12000, S, 0x0104), (12000, S, 0x0106), (12000, C, 0x0107),
                    (12000, S, 0x0108), (12000, C, 0x010C), (12000, C, 0x0103), (12000, C, 0x0105),
                    (12020, C, 0x0101), (12020, S, 0x0102), (12020, S, 0x0104), (12020, C, 0x0105),
                    (12020, S, 0x0106)]:
            with self.subTest(key=(key[0], key[1], hex(key[2]))):
                self.check_exact(key)


if __name__ == "__main__":
    unittest.main()
