import json
import queue
import tempfile
import threading
import unittest
from collections import deque
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from rfnext_market import desktop, session
from tests import test_session as ts


class DesktopSafetyTest(unittest.TestCase):
    class Var:
        def __init__(self, value=""):
            self.value = value

        def set(self, value):
            self.value = str(value)

        def get(self):
            return self.value

    def test_load_values_resets_session_and_optional_paths(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.vars = {name: self.Var() for name in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        app.session_path = self.Var("old-session.json")
        app.item_database = self.Var("old-items.sqlite")
        app._load_values({
            "auth": {"host": "a", "port": 1, "timeout": 2},
            "game": {"host": "b", "port": 3, "timeout": 4},
            "world_id": 5, "market": {"response_timeout": 6},
        }, Path("C:/config"))
        self.assertEqual(app.session_path.get(), "")
        self.assertEqual(app.item_database.get(), "")
        self.assertEqual(app.vars["auth_host"].get(), "a")

    def test_invalid_path_types_are_rejected_without_partial_state(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.vars = {name: self.Var(f"old-{name}") for name in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        app.session_path = self.Var("old-session.json")
        app.item_database = self.Var("old-items.sqlite")
        before = {key: value.get() for key, value in app.vars.items()}
        for document, message in (
                ({"session_file": ["bad"]}, "session_file"),
                ({"session_file": 7}, "session_file"),
                ({"market": {"item_database": ["bad"]}}, "market.item_database"),
                ({"market": {"item_database": 7}}, "market.item_database")):
            with self.subTest(document=document), self.assertRaisesRegex(ValueError, message):
                app._load_values(document, Path("C:/config"))
            self.assertEqual(app.session_path.get(), "old-session.json")
            self.assertEqual(app.item_database.get(), "old-items.sqlite")
            self.assertEqual(before, {key: value.get() for key, value in app.vars.items()})

    def test_valid_config_without_paths_clears_previous_document_paths(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.vars = {name: self.Var() for name in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        app.session_path = self.Var()
        app.item_database = self.Var()
        app._load_values({"session_file": "old.json", "auth": {}, "game": {},
                          "market": {"item_database": "old.sqlite"}}, Path("C:/config"))
        app._load_values({"auth": {}, "game": {}, "market": {}}, Path("C:/other"))
        self.assertEqual((app.session_path.get(), app.item_database.get()), ("", ""))

    def test_config_callback_rejects_invalid_paths_without_mixing_documents(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.vars = {name: self.Var(f"old-{name}") for name in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        app.session_path = self.Var("old-session.json")
        app.item_database = self.Var("old-items.sqlite")
        app.config_document = {"old": True}
        app.config_path = self.Var("old-config.json")
        app.status = mock.Mock()
        base = {"auth": {}, "game": {}, "market": {}}
        with tempfile.TemporaryDirectory() as tmp:
            for bad in ({"session_file": ["bad"]}, {"market": {"item_database": 7}}):
                document = dict(base)
                document.update(bad)
                path = Path(tmp) / "bad.json"
                path.write_text(json.dumps(document), encoding="utf-8")
                with self.subTest(bad=bad), mock.patch.object(
                        desktop.filedialog, "askopenfilename", return_value=str(path)), \
                        mock.patch.object(desktop.messagebox, "showerror") as showerror:
                    app._choose_config()
                    showerror.assert_called_once()
                self.assertEqual(app.config_document, {"old": True})
                self.assertEqual(app.config_path.get(), "old-config.json")
                self.assertEqual(app.session_path.get(), "old-session.json")
                self.assertEqual(app.item_database.get(), "old-items.sqlite")

    def test_new_config_preserves_synthetic_credentials_and_payload_request(self):
        sentinel = "synthetic-password-token"
        config = {
            "credentials": {"password": sentinel, "token": "synthetic-token"},
            "unknown": {"nested": sentinel, "text": f"token={sentinel}"},
            "market": {"list_requests": [{"payload_hex": "a1b2"}]},
        }
        values = {
            "auth_host": "127.0.0.1", "auth_port": "12000", "auth_timeout": "2",
            "game_host": "127.0.0.1", "game_port": "12020", "game_timeout": "3",
            "world_id": "1", "response_timeout": "4", "session_file": "sessao.json",
            "item_database": "",
        }
        built = desktop.build_config(config, values)
        self.assertEqual(built["credentials"]["password"], sentinel)
        self.assertEqual(built["credentials"]["token"], "synthetic-token")
        self.assertEqual(built["market"]["list_requests"][0]["payload_hex"], "a1b2")

    def test_frame_detail_preserves_payload_and_sensitive_fields(self):
        original = {
            "record_type": "frame", "direction": "client_to_server", "service_port": 12000,
            "opcode": 0x0101, "decoded_length": 44,
            "wire_hex": "a1b2c3d4", "decoded_hex": "0102a1b2",
            "parsed_fields": {"password": "synthetic-password", "token": "synthetic-token"},
            "unknown_fields": [{"offset": 4, "hex": "a1b2", "name": "payload_wire"}],
        }
        summary = desktop.summarize_record(original)
        details = desktop.message_details(original)
        self.assertEqual((summary["direction"], summary["type"], summary["state"]), ("TX", "0x0101", "enviado"))
        for value in ("synthetic-password", "synthetic-token", "a1b2c3d4", "0102a1b2", "payload_wire"):
            self.assertIn(value, details)

    def test_build_config_edits_values_and_keeps_credentials(self):
        config = {"credentials": {"session_key": "synthetic-session"},
                  "market": {"list_requests": [{"payload_hex": "0000"}]}}
        values = {
            "auth_host": "127.0.0.1", "auth_port": "12000", "auth_timeout": "2",
            "game_host": "127.0.0.1", "game_port": "12020", "game_timeout": "3",
            "world_id": "1", "response_timeout": "4", "session_file": "sessao.json",
            "item_database": "items.sqlite",
        }
        built = desktop.build_config(config, values)
        self.assertEqual(built["credentials"]["session_key"], "synthetic-session")
        self.assertEqual((built["auth"]["port"], built["game"]["timeout"]), (12000, 3.0))
        self.assertEqual(built["market"]["item_database"], "items.sqlite")

    def test_invalid_selected_session_is_rejected_without_socket(self):
        with self.assertRaisesRegex(ValueError, "arquivo não encontrado"):
            desktop.DesktopApp._validate_config({
                "auth": {"host": "127.0.0.1", "port": 12000, "timeout": 1},
                "game": {"host": "127.0.0.1", "port": 12020, "timeout": 1},
                "world_id": 1,
                "session_file": str(Path(tempfile.gettempdir()) / "arquivo-inexistente-rfnext.json"),
                "market": {"list_requests": [{"payload_hex": "0000"}], "response_timeout": 1},
            })


class DesktopWorkerTest(unittest.TestCase):
    class Tree:
        def __init__(self):
            self.rows = []

        def get_children(self):
            return tuple(range(len(self.rows)))

        def delete(self, *items):
            for _ in items:
                if self.rows:
                    self.rows.pop(0)

        def insert(self, _parent, _index, values):
            self.rows.append(values)

        def yview_moveto(self, _position):
            pass

    @classmethod
    def headless_app(cls):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.root = mock.Mock()
        app._queue = queue.Queue(maxsize=desktop.MAX_PENDING_RECORDS)
        app._control_queue = queue.SimpleQueue()
        app.records = deque(maxlen=desktop.MAX_VISIBLE_RECORDS)
        app.tx = (None, cls.Tree())
        app.rx = (None, cls.Tree())
        app.worker = None
        app.stop_event = None
        app._closing = False
        app._finished = False
        app._dropped_records = 0
        app._tree_order = deque()
        app._tree_records = {}
        app.start_button = mock.Mock()
        app.stop_button = mock.Mock()
        app.status = mock.Mock()
        return app

    def test_worker_passes_cooperative_stop_to_runner(self):
        event = threading.Event()
        received = []
        done = []

        def runner(config, emit, stop_event):
            received.append(stop_event)
            stop_event.set()
            return {"status": "cancelled"}

        desktop.run_session_worker({}, lambda record: None,
                                   lambda result, error: done.append((result, error)), event, runner)
        self.assertIs(received[0], event)
        self.assertTrue(event.is_set())
        self.assertEqual(done, [({"status": "cancelled"}, None)])

    def test_real_session_honors_cancel_during_fake_flow(self):
        clock, records, conns = ts.Clock(), [], {}
        scripts = {12000: ts.auth_script(), 12020: ts.game_script()}
        stop_event = threading.Event()

        class CancelAfterFirstReceive(ts.FakeConn):
            def receive(self):
                stop_event.set()
                return super().receive()

        def factory(host, port, timeout):
            conns[port] = CancelAfterFirstReceive(port, scripts[port], clock, [])
            return conns[port]

        with mock.patch.object(session, "Connection", factory), mock.patch.object(session, "time", clock):
            result = session.run(ts.config(), records.append, stop_event=stop_event)
        self.assertEqual(result["status"], "cancelled")
        self.assertEqual(records[-1]["record_type"], "completion")
        self.assertIn("cancelada", result["diagnostic"])

    def test_finish_keeps_public_partial_result_for_export(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.start_button = mock.Mock()
        app.stop_button = mock.Mock()
        app.status = mock.Mock()
        app._finish({
            "status": "cancelled", "diagnostic": "token=synthetic-token",
            "credentials": {"password": "synthetic-password"},
            "items": [{"item_index": 7, "produto": "Item público", "offers": [], "error": None}],
            "offers": [],
        }, None)
        self.assertEqual(app.result["items"][0]["produto"], "Item público")
        self.assertIn("synthetic-token", json.dumps(app.result))
        self.assertIn("synthetic-password", json.dumps(app.result))

    def test_observer_retains_full_message_for_selected_detail(self):
        app = self.headless_app()
        original = {
            "record_type": "frame", "direction": "client_to_server", "service_port": 12000,
            "opcode": 0x0101, "wire_hex": "a1b2c3d4", "decoded_hex": "0102a1b2",
            "parsed_fields": {"password": "synthetic-password", "token": "synthetic-token"},
        }
        app._observe(original)
        app._drain_queue()
        self.assertEqual(app.records[-1], original)
        detail = desktop.message_details(app.records[-1])
        for value in ("synthetic-password", "synthetic-token", "a1b2c3d4", "0102a1b2"):
            self.assertIn(value, detail)
        self.assertEqual(app.tx[1].rows[0][1:], ("0x0101", "enviado", "serviço 12000; quadro ? bytes"))

    def test_inspection_uses_event_tree_and_button_focus_without_cross_tree_fallback(self):
        class Tree:
            def __init__(self):
                self.selected = ()

            def selection(self):
                return self.selected

        class Text:
            instances = []

            def __init__(self, *_args, **_kwargs):
                self.inserted = []
                self.__class__.instances.append(self)

            def configure(self, **_kwargs):
                pass

            def grid(self, **_kwargs):
                pass

            def insert(self, _index, value):
                self.inserted.append(value)

            def yview(self, *_args):
                pass

            def xview(self, *_args):
                pass

        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.root = mock.Mock()
        tx, rx = Tree(), Tree()
        app.tx, app.rx = (None, tx), (None, rx)
        tx_item, rx_item = "tx-row", "rx-row"
        tx.selected, rx.selected = (tx_item,), (rx_item,)
        app._tree_records = {
            (tx, tx_item): {"direction": "TX", "payload": "tx-example"},
            (rx, rx_item): {"direction": "RX", "payload": "rx-example"},
        }
        app._last_selected_tree = rx
        app.root.focus_get.return_value = rx
        app._remember_selected_tree(SimpleNamespace(widget=rx))
        window = mock.Mock()
        with mock.patch.object(desktop.tk, "Toplevel", return_value=window), \
                mock.patch.object(desktop.tk, "Text", Text), \
                mock.patch.object(desktop.ttk, "Scrollbar", return_value=mock.Mock()), \
                mock.patch.object(desktop.messagebox, "showinfo") as showinfo:
            app._inspect_selected(SimpleNamespace(widget=rx))
            self.assertIn("rx-example", Text.instances[-1].inserted[-1])
            app._inspect_selected(SimpleNamespace(widget=tx))
            self.assertIn("tx-example", Text.instances[-1].inserted[-1])
            app._inspect_selected()
            self.assertIn("rx-example", Text.instances[-1].inserted[-1])

            before = len(Text.instances)
            rx.selected = ()
            app._inspect_selected(SimpleNamespace(widget=rx))
            self.assertEqual(len(Text.instances), before)
            showinfo.assert_called_once()

    def test_export_writes_jsonl_and_existing_market_reports(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.records = [{
            "record_type": "frame", "direction": "client_to_server", "service_port": 12000,
            "opcode": 0x0101, "wire_hex": "a1b2c3", "decoded_hex": "0102",
            "parsed_fields": {"password": "synthetic-password", "token": "synthetic-token"},
        }]
        app.result = {"status": "cancelled", "items": [{
            "item_index": 7, "produto": "Item público", "offers": [],
            "status": "sem_ofertas", "registered_items": 1,
        }]}
        app.status = mock.Mock()
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
                desktop.filedialog, "asksaveasfilename", return_value=str(Path(tmp) / "saida.jsonl")):
            app._export()
            self.assertTrue((Path(tmp) / "saida.jsonl").is_file())
            self.assertTrue((Path(tmp) / "mercado_resumo.csv").is_file())
            self.assertTrue((Path(tmp) / "mercado_ofertas.csv").is_file())
            exported = (Path(tmp) / "saida.jsonl").read_text(encoding="utf-8")
        for value in ("synthetic-password", "synthetic-token", "a1b2c3", "0102"):
            self.assertIn(value, exported)

    def test_close_requests_cancel_without_destroying_live_worker(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.root = mock.Mock()
        app.stop_event = threading.Event()
        release = threading.Event()
        app.worker = threading.Thread(target=release.wait, daemon=True)
        app._closing = False
        app.status = mock.Mock()
        app.worker.start()
        try:
            app._close()
            self.assertTrue(app.stop_event.is_set())
            app.root.destroy.assert_not_called()
        finally:
            release.set()
            app.worker.join(timeout=2)

    def test_queue_records_tree_are_bounded_and_done_is_delivered(self):
        app = self.headless_app()
        record = {"record_type": "diagnostic", "message": "x"}
        for _ in range(10000):
            app._observe(record)
        self.assertLessEqual(app._queue.qsize(), desktop.MAX_PENDING_RECORDS)
        self.assertGreaterEqual(app._dropped_records, 10000 - desktop.MAX_PENDING_RECORDS)
        app._observe({"record_type": "completion", "status": "completed"})
        app._control_queue.put(("done", {"status": "completed", "items": [{"offers": [1]}]}, None))
        app._drain_queue()
        self.assertLessEqual(app._queue.qsize(), desktop.MAX_PENDING_RECORDS - desktop.DRAIN_BATCH)
        self.assertLessEqual(len(app.records), desktop.MAX_VISIBLE_RECORDS)
        self.assertLessEqual(len(app.tx[1].rows) + len(app.rx[1].rows), desktop.MAX_VISIBLE_RECORDS)
        self.assertTrue(app._finished)
        self.assertEqual(app.result["items"][0]["offers"], [1])
        self.assertTrue(app.root.after.called)

    def test_close_drains_done_after_worker_exit_before_destroy(self):
        app = self.headless_app()
        app._queue.put(("done", {"status": "cancelled", "items": []}, None))
        app._closing = False
        app._close()
        self.assertTrue(app._finished)
        self.assertEqual(app.result["status"], "cancelled")
        app.root.destroy.assert_called_once()

    def test_export_warns_when_diagnostic_log_was_cut(self):
        app = self.headless_app()
        app.records.append({"record_type": "completion", "details": "ok"})
        app.result = {"status": "completed", "items": []}
        app._finished = True
        app._dropped_records = 9
        with tempfile.TemporaryDirectory() as tmp, mock.patch.object(
                desktop.filedialog, "asksaveasfilename", return_value=str(Path(tmp) / "saida.jsonl")):
            app._export()
            lines = (Path(tmp) / "saida.jsonl").read_text(encoding="utf-8").splitlines()
        self.assertTrue(any(json.loads(line).get("record_type") == "log_truncated" for line in lines))
        self.assertIn("9", app.status.set.call_args.args[0])

    def test_pre_cancelled_session_opens_no_connection(self):
        event = threading.Event()
        event.set()
        records = []
        with mock.patch.object(session, "Connection", side_effect=AssertionError("connection opened")):
            result = session.run(ts.config(), records.append, stop_event=event)
        self.assertEqual(result["status"], "cancelled")
        self.assertEqual([r["record_type"] for r in records[-2:]], ["market_result", "completion"])

    def test_cancel_during_connect_returns_without_opening_game(self):
        event = threading.Event()
        calls = []

        def connect(host, port, timeout, stop_event=None):
            calls.append(port)
            while not stop_event.is_set():
                threading.Event().wait(0.005)
            raise session.CancelledError()

        result_holder = []
        thread = threading.Thread(
            target=lambda: result_holder.append(session.run(ts.config(), lambda record: None,
                                                             stop_event=event)))
        with mock.patch.object(session, "Connection", connect):
            thread.start()
            threading.Event().wait(0.03)
            event.set()
            thread.join(timeout=2)
        self.assertFalse(thread.is_alive())
        self.assertEqual(calls, [12000])
        self.assertEqual(result_holder[0]["status"], "cancelled")


if __name__ == "__main__":
    unittest.main()
