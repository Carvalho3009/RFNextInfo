"""Máquina de estados da sessão com conexões falsas roteirizadas (sem sockets, sem sleeps).

Módulos reais protocol/auth/market/dump; só Connection e o relógio são substituídos.
Credenciais e payloads de servidor são sintéticos.
"""
import struct
import unittest
from unittest import mock

from rfnext_market import auth, protocol, session
from rfnext_market.transport import DIRECTION_C2S, DIRECTION_S2C


def s16(text):
    raw = text.encode("utf-16le")
    return struct.pack("<H", len(raw) // 2) + raw


def credentials():
    """Nível superior comum + seção "12020_0x0103" com device_info distinto (como na captura).
    Campos derivados em execução (world_id, u64@2688) ficam de fora."""
    fake = {"str": "synthetic", "u8": 0, "u16": 4, "u32": 0, "u64": 0}
    out = {}
    for (port, direction, op), (_, _, spec) in auth.LAYOUTS.items():
        if direction != DIRECTION_C2S:
            continue
        for name, kind in spec:
            if isinstance(kind, tuple):
                out[name + "_hex"] = "00" * (kind[1] or 1)
            elif name not in session.DERIVED_FIELDS:
                out[name] = fake[kind]
    out["12020_0x0103"] = {"device_info": "synthetic-game"}
    return out


F4, F6 = 0x3344, 0x1122
LINK_U64 = F4 | (F6 << 16)


def ans_0102_12000(result=0, heartbeat=3000):
    return (struct.pack("<HQI", result, 0, heartbeat) + bytes(3) + struct.pack("<QB", 0, 0) + bytes(10)
            + s16("XX") + s16("XX"))


def ans_0108(result=0):
    return struct.pack("<HHHQH", result, 1, F4, F6, 0) + s16("127.0.0.1") + struct.pack("<H", 12020)


ANS_0102_12020 = struct.pack("<HB", 0, 0) + s16("TEST") + struct.pack("<H", 1)
ANS_0104_12020 = struct.pack("<HQHQ", 0, 0x1122, 0, 0) + s16("test")


def list_1d02(is_end, server_type, items, ret=0):
    body = b"".join(struct.pack("<IHddI", i, 0, 1.0, 2.0, 1) for i in items)
    return struct.pack("<HBBH", ret, is_end, server_type, len(items)) + body


def detail_1d04(item_index):
    return struct.pack("<HIBBH", 0, item_index, 1, 0, 0)


class Clock:
    def __init__(self):
        self.now = 100.0

    def monotonic(self):
        return self.now


class FakeConn:
    """script: opcode enviado -> lista de respostas por envio; resposta = lista de
    (opcode, payload) | "timeout" | "eof". Fila vazia = TimeoutError."""

    def __init__(self, port, script, clock, log):
        self.service_port = port
        self.connection_id = f"fake-{port}"
        self.local_endpoint = "127.0.0.1:50000"
        self.remote_endpoint = f"127.0.0.1:{port}"
        self.script = {op: list(r) for op, r in script.items()}
        self.clock, self.log = clock, log
        self.queue, self.sent, self.server_seq, self.closed = [], [], 0, False
        log.append(("open", port))

    def send(self, wire):
        assert not self.closed
        frame = protocol.decode_frame(wire)
        self.sent.append(frame)
        responses = self.script.get(frame["opcode"])
        if responses:
            self.queue.extend(responses.pop(0))

    def receive(self):
        if not self.queue:
            self.clock.now += 1.0
            raise TimeoutError("fake timeout")
        item = self.queue.pop(0)
        if item == "timeout":
            self.clock.now += 1.0
            raise TimeoutError("fake timeout")
        if item == "eof":
            raise ConnectionError("fake eof")
        opcode, payload = item
        wire = protocol.encode_frame(opcode, payload, self.server_seq, seed=7)
        self.server_seq = (self.server_seq + 1) & 0xFF
        return wire

    def close(self):
        if not self.closed:
            self.log.append(("close", self.service_port))
        self.closed = True


def auth_script(overrides=None):
    script = {
        0x0101: [[(0x0106, b"\x01\x02"), (0x0102, ans_0102_12000())]],
        0x0105: [[(0x0106, b"\x01\x02")]],
        0x0107: [[(0x0108, ans_0108())]],
        0x0103: [[(0x0104, bytes(8))]] * 10,
    }
    script.update(overrides or {})
    return script


def game_script(overrides=None):
    script = {
        0x0101: [[(0x0102, ANS_0102_12020)]],
        0x0103: [[(0x0206, bytes(8)), (0x0104, ANS_0104_12020)]],
        0x0105: [[(0x0106, b"\x00" * 4)]],
        0x1D01: [[(0x1D1F, bytes(48)), (0x1D02, list_1d02(0, 0, [1, 2])), (0x1D02, list_1d02(1, 0, [3]))]],
        0x1D03: [[(0x1D04, detail_1d04(1000001))]],
    }
    script.update(overrides or {})
    return script


def config():
    return {
        "auth": {"host": "127.0.0.1", "port": 12000, "timeout": 10.0},
        "game": {"host": "127.0.0.1", "port": 12020, "timeout": 10.0},
        "world_id": 1,
        "market": {"list_requests": [{"payload_hex": "0000"}],
                   "detail_requests": [{"item_index": 1000001, "trailing_u8": 0}],
                   "response_timeout": 5.0},
        "credentials": credentials(),
    }


class SessionTest(unittest.TestCase):
    def run_session(self, auth_s=None, game_s=None, cfg=None, conn_cls=None):
        cfg = cfg or config()
        self.clock, self.log, self.records, self.conns = Clock(), [], [], {}
        scripts = {cfg["auth"]["port"]: auth_s or auth_script(), cfg["game"]["port"]: game_s or game_script()}
        conn_cls = conn_cls or FakeConn

        def factory(host, port, timeout):
            self.conns[port] = conn_cls(port, scripts[port], self.clock, self.log)
            return self.conns[port]

        with mock.patch.object(session, "Connection", factory), \
                mock.patch.object(session, "time", self.clock):
            return session.run(cfg, self.records.append)

    def sent_ops(self, port):
        return [f["opcode"] for f in self.conns[port].sent] if port in self.conns else []

    def assert_closing_records(self, result):
        self.assertEqual(self.records[-2]["record_type"], "market_result")
        self.assertEqual(self.records[-1]["record_type"], "completion")
        self.assertEqual(self.records[-1]["status"], result["status"])
        self.assertTrue(all(c.closed for c in self.conns.values()))

    def test_happy_path(self):
        result = self.run_session()
        self.assertEqual(result["status"], "completed", result["diagnostic"])
        self.assertEqual(result["stage"], "done")
        self.assertIsNone(result["authenticated"])  # 0x0104 sem retorno confirmado
        self.assertEqual(self.sent_ops(12000), [0x0101, 0x0105, 0x0107])
        self.assertEqual(self.sent_ops(12020), [0x0101, 0x0103, 0x0105, 0x1D01, 0x1D03])
        # 12000 fechada antes de abrir 12020 (ordem observada).
        self.assertEqual(self.log[:3], [("open", 12000), ("close", 12000), ("open", 12020)])
        for port in (12000, 12020):
            self.assertEqual([f["sequence"] for f in self.conns[port].sent], list(range(len(self.conns[port].sent))))
        frames = [r for r in self.records if r["record_type"] == "frame"]
        self.assertEqual(len(frames), 3 + 4 + 5 + 8)  # 12000: 3 C2S + 4 S2C; 12020: 5 C2S + 8 S2C
        self.assertEqual({r["direction"] for r in frames if r["opcode"] == 0x1D01}, {DIRECTION_C2S})
        self.assertEqual({r["direction"] for r in frames if r["opcode"] == 0x1D02}, {DIRECTION_S2C})
        self.assertFalse([r for r in self.records if r["record_type"] == "diagnostic"])
        queries = result["market"]["queries"]
        self.assertEqual([(q["query_id"], q["complete"], len(q["entries"]), q["frames"]) for q in queries],
                         [("list-0", True, 3, 2), ("detail-0", True, 0, 1)])
        self.assertTrue(result["unconfirmed"])
        # Credenciais por mensagem e u64@2688 derivado do 0x0108 desta execução.
        c0101 = auth.parse_message(12000, DIRECTION_C2S, 0x0101, self.conns[12000].sent[0]["payload"])["fields"]
        g0103 = auth.parse_message(12020, DIRECTION_C2S, 0x0103, self.conns[12020].sent[1]["payload"])["fields"]
        self.assertEqual(c0101["device_info"], "synthetic")
        self.assertEqual(g0103["device_info"], "synthetic-game")
        self.assertEqual(g0103["u64@2688"], LINK_U64)
        self.assertEqual(struct.pack("<Q", g0103["u64@2688"]), ans_0108()[4:12])
        self.assert_closing_records(result)

    def test_supplied_u64_2688_matching_is_accepted(self):
        cfg = config()
        cfg["credentials"]["u64@2688"] = LINK_U64
        self.assertEqual(self.run_session(cfg=cfg)["status"], "completed")

    def test_supplied_u64_2688_mismatch_stops(self):
        cfg = config()
        cfg["credentials"]["12020_0x0103"]["u64@2688"] = 0
        result = self.run_session(cfg=cfg)
        self.assertEqual((result["status"], result["stage"]), ("failed", "12000:0x0107"))
        self.assertIn("u64@2688", result["diagnostic"])
        self.assertNotIn(12020, self.conns)
        self.assert_closing_records(result)

    def test_non_default_ports_use_config_section(self):
        cfg = config()
        cfg["auth"]["port"], cfg["game"]["port"] = 40000, 40001
        result = self.run_session(cfg=cfg)
        self.assertEqual(result["status"], "completed", result["diagnostic"])
        self.assertEqual(self.sent_ops(40001), [0x0101, 0x0103, 0x0105, 0x1D01, 0x1D03])
        frames = [r for r in self.records if r["record_type"] == "frame" and r["opcode"] == 0x0104]
        self.assertTrue(frames and all(r["service_port"] == 40001 for r in frames))
        self.assertTrue(all(r["parsed_fields"] for r in frames))  # layout 12020, não unknown

    def test_malformed_frame_emits_closing_records(self):
        class BadConn(FakeConn):
            def receive(self):
                if self.service_port == 12020 and self.queue:
                    raise ValueError("comprimento inválido")
                return super().receive()

        result = self.run_session(conn_cls=BadConn)
        self.assertEqual((result["status"], result["stage"]), ("failed", "12020:0x0101"))
        self.assertIn("ValueError", result["diagnostic"])
        self.assert_closing_records(result)

    def test_send_error_emits_closing_records(self):
        class PipeConn(FakeConn):
            def send(self, wire):
                if protocol.decode_frame(wire)["opcode"] == 0x1D01:
                    raise BrokenPipeError("pipe")
                super().send(wire)

        result = self.run_session(conn_cls=PipeConn)
        self.assertEqual((result["status"], result["stage"]), ("failed", "market:list-0"))
        self.assertIn("BrokenPipeError", result["diagnostic"])
        self.assert_closing_records(result)

    def test_heartbeat_limits_socket_timeout(self):
        clock = Clock()
        conn = FakeConn(12000, {}, clock, [])
        conn._sock = mock.Mock()
        conn._sock.gettimeout.return_value = 10.0
        link = session._Link(conn, lambda r: None, 12000)
        link.beat_s, link.next_beat = 3.0, clock.now + 1.5  # último 0x0103 há 1,5 s
        with mock.patch.object(session, "time", clock), self.assertRaises(session._Stop):
            session._await(link, 0x0108, 5.0, "t", heartbeat=True)
        waits = [c.args[0] for c in conn._sock.settimeout.call_args_list]
        self.assertEqual(waits[0], 1.5)            # acorda no prazo do heartbeat, não em 10 s
        self.assertTrue(all(w <= 3.0 for w in waits[:-1]))
        self.assertEqual(waits[-1], 10.0)          # restaurado
        self.assertEqual([f["opcode"] for f in conn.sent], [0x0103, 0x0103])  # t=1,5+ e t=4,5+

    def test_rejection_12000(self):
        result = self.run_session(auth_s=auth_script({0x0101: [[(0x0102, ans_0102_12000(result=5))]]}))
        self.assertEqual((result["status"], result["stage"]), ("failed", "12000:0x0101"))
        self.assertIn("result_code=5", result["diagnostic"])
        self.assertEqual(self.sent_ops(12000), [0x0101])
        self.assertNotIn(12020, self.conns)
        self.assert_closing_records(result)

    def test_rejection_0108(self):
        result = self.run_session(auth_s=auth_script({0x0107: [[(0x0108, ans_0108(result=2))]]}))
        self.assertEqual((result["status"], result["stage"]), ("failed", "12000:0x0107"))
        self.assertNotIn(12020, self.conns)

    def test_timeout_with_heartbeat(self):
        # Sem 0x0108: 0x0103 a cada 3 s (relógio falso) até o timeout de 10 s.
        result = self.run_session(auth_s=auth_script({0x0107: [[]], 0x0103: [[]] * 10}))
        self.assertEqual((result["status"], result["stage"]), ("failed", "12000:0x0107"))
        self.assertIn("timeout", result["diagnostic"])
        ops = self.sent_ops(12000)
        self.assertEqual(ops[:3], [0x0101, 0x0105, 0x0107])
        self.assertEqual(set(ops[3:]), {0x0103})
        self.assertEqual(len(ops[3:]), 3)
        self.assert_closing_records(result)

    def test_disconnect(self):
        result = self.run_session(game_s=game_script({0x0105: [["eof"]]}))
        self.assertEqual((result["status"], result["stage"]), ("failed", "12020:0x0105"))
        self.assertIn("desconexão", result["diagnostic"])
        self.assertEqual(self.sent_ops(12020), [0x0101, 0x0103, 0x0105])
        self.assert_closing_records(result)

    def test_async_interleaved(self):
        noise = [(0x0206, bytes(8)), "timeout", (0x1D1F, bytes(48)), (0x0999, b"\xaa")]
        result = self.run_session(game_s=game_script({
            0x0101: [noise + [(0x0102, ANS_0102_12020)]],
            0x1D03: [noise + [(0x1D02, list_1d02(1, 1, [9])), (0x1D04, detail_1d04(1000001))]],
        }))
        self.assertEqual(result["status"], "completed", result["diagnostic"])
        detail = [q for q in result["market"]["queries"] if q["query_id"] == "detail-0"]
        self.assertEqual([q["complete"] for q in detail], [True])

    def test_missing_field_incomplete(self):
        cfg = config()
        del cfg["credentials"]["session_key"]
        result = self.run_session(cfg=cfg)
        # 12000 0x0101 também exige session_key: para antes de enviar qualquer coisa.
        self.assertEqual((result["status"], result["stage"]), ("incomplete", "12000:0x0101"))
        self.assertIn("session_key", result["diagnostic"])
        self.assertEqual(self.sent_ops(12000), [])
        self.assert_closing_records(result)

    def test_missing_12020_field_incomplete(self):
        cfg = config()
        del cfg["credentials"]["unknown_@79_hex"]
        result = self.run_session(cfg=cfg)
        self.assertEqual((result["status"], result["stage"]), ("incomplete", "12020:0x0103"))
        self.assertIn("unknown_@79_hex", result["diagnostic"])
        self.assertEqual(self.sent_ops(12020), [0x0101])

    def test_market_timeout_then_next_query(self):
        result = self.run_session(game_s=game_script({0x1D01: [[(0x1D02, list_1d02(0, 0, [1]))]]}))
        self.assertEqual((result["status"], result["stage"]), ("incomplete", "market:list-0"))
        self.assertIn("list-0", result["diagnostic"])
        self.assertEqual(self.sent_ops(12020)[-1:], [0x1D01])
        list_q = result["market"]["queries"][0]
        self.assertFalse(list_q["complete"])

    def test_market_error_ret(self):
        result = self.run_session(game_s=game_script({0x1D01: [[(0x1D02, list_1d02(0, 0, [], ret=7))]]}))
        self.assertEqual(result["status"], "failed")
        self.assertEqual(result["market"]["queries"][0]["error"], "ret=7")

    def test_market_detail_wrong_item_is_rejected(self):
        result = self.run_session(game_s=game_script({0x1D03: [[(0x1D04, detail_1d04(999))]]}))
        self.assertEqual(result["status"], "incomplete")
        self.assertIn("não corresponde", result["diagnostic"])

    def test_bad_market_request_incomplete(self):
        cfg = config()
        cfg["market"]["detail_requests"] = [{"item_index": 5}]
        result = self.run_session(cfg=cfg)
        self.assertEqual((result["status"], result["stage"]), ("incomplete", "market:detail-0"))
        self.assertIn("trailing_u8", result["diagnostic"])
        self.assertNotIn(0x1D03, self.sent_ops(12020))

    def test_confirmed_0104_sets_authenticated(self):
        real = auth.parse_message

        def fake_parse(port, direction, opcode, payload, ret):
            msg = real(port, direction, opcode, payload)
            if (port, direction, opcode) == (12020, DIRECTION_S2C, 0x0104):
                msg = dict(msg, status="confirmed", fields=dict(msg["fields"], ret=ret))
            return msg

        with mock.patch.object(session.auth, "parse_message", lambda *a: fake_parse(*a, ret=0)):
            self.assertTrue(self.run_session()["authenticated"])
        with mock.patch.object(session.auth, "parse_message", lambda *a: fake_parse(*a, ret=3)):
            result = self.run_session()
        self.assertEqual((result["status"], result["stage"], result["authenticated"]),
                         ("failed", "12020:0x0103", False))
        self.assertEqual(self.sent_ops(12020), [0x0101, 0x0103])

    def test_connect_failure(self):
        def boom(host, port, timeout):
            raise ConnectionRefusedError("refused")

        records = []
        with mock.patch.object(session, "Connection", boom):
            result = session.run(config(), records.append)
        self.assertEqual((result["status"], result["stage"]), ("failed", "12000:connect"))
        self.assertEqual(records[-1]["record_type"], "completion")

    def test_send_restricted(self):
        link = session._Link(FakeConn(12020, {}, Clock(), []), lambda r: None, 12020)
        with self.assertRaises(session._Stop):
            link.send(0x1D0C, b"")


if __name__ == "__main__":
    unittest.main()
