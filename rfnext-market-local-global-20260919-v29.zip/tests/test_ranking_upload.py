from contextlib import closing
import copy
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch, Mock
from rfnext_market import rankings, upload
from tests.test_rankings import exp, faction

STAMP = "2026-09-19T22:00:00Z"


def result():
    values = {"exp": dict(rankings.parse_message(0x1A02, exp())["fields"], status="completed")}
    for fid, name in enumerate(("accretia", "bellato", "cora"), 1):
        values[name] = dict(rankings.parse_message(0x240B, faction(fid))["fields"], status="completed")
    return {"rankings": values, "market": {"queries": []}, "items": []}


class RankingUploadTest(unittest.TestCase):
    def test_mapping_and_invalid_independence(self):
        source = result(); original = copy.deepcopy(source)
        payloads = rankings.upload_payloads(source, STAMP)
        self.assertEqual(len(payloads), 4)
        self.assertEqual(len(payloads[0]["ranking_records"]), 100)
        self.assertEqual(payloads[1]["faction"], "Accretia")
        self.assertEqual(source, original)
        source["rankings"]["exp"]["records"].pop(0)
        source["rankings"]["bellato"]["records"][0]["contribution"] = 1.5
        messages = []
        self.assertEqual(len(rankings.upload_payloads(source, STAMP, messages.append)), 2)
        self.assertEqual(len(messages), 2)

    def test_queue_retries_same_batches(self):
        with tempfile.TemporaryDirectory() as folder:
            config = {"companion": {"base_url": "https://example.com", "state_dir": folder}}
            with patch.object(upload, "_identity", return_value=({"installation_id": "test"}, None)), \
                 patch.object(upload, "_flush", return_value={"status": "pending"}):
                upload.submit_result(result(), config)
                with closing(sqlite3.connect(Path(folder) / "market-upload.sqlite3")) as db:
                    before = db.execute("SELECT body FROM batches ORDER BY sequence").fetchall()
                upload.retry_pending(config)
                with closing(sqlite3.connect(Path(folder) / "market-upload.sqlite3")) as db:
                    self.assertEqual(before, db.execute("SELECT body FROM batches ORDER BY sequence").fetchall())
                kinds = [json.loads(row[0])["events"][0]["type"] for row in before]
                self.assertEqual(kinds, ["community.exp_ranking_snapshot"] + ["community.faction_ranking_snapshot"] * 3)

    def test_level_boundaries(self):
        source = result()
        for row, value in zip(source["rankings"]["exp"]["records"], (0, 19, 20, 35)):
            row["total_exp"] = value
        rows = rankings.upload_payloads(source, STAMP)[0]["ranking_records"]
        self.assertEqual([(r["level"], r["level_percent"]) for r in rows[:4]], [(1, 0.0), (1, 95.0), (2, 0.0), (2, 50.0)])

    def test_upload_progress_follows_receipts(self):
        messages = []
        key = Mock(); key.sign.return_value = b"signature"
        def post(options, path, body, *args, **kwargs):
            if path.endswith("authorization"):
                return {"installation_id": "test", "status": "authorized"}
            batch = json.loads(body)
            return {"batch_id": batch["batch_id"], "accepted": True,
                    "accepted_through_sequence": batch["last_sequence"], "duplicate": False,
                    "rejected_events": [], "server_time": STAMP}
        with tempfile.TemporaryDirectory() as folder, \
             patch.object(upload, "_identity", return_value=({"installation_id": "test", "key_id": "key"}, key)), \
             patch.object(upload, "_post", side_effect=post):
            answer = upload.submit_result(result(), {"companion": {"base_url": "https://example.com", "state_dir": folder}}, messages.append)
        self.assertEqual(answer["status"], "accepted")
        self.assertEqual([(r["completed"], r["total"]) for r in messages if r["record_type"] == "progress"], [(n, 4) for n in range(5)])

    def test_broken_pipe_reopens_connection_for_same_batch(self):
        key = Mock(); key.sign.return_value = b"signature"
        calls = []
        def post(options, path, body, *args, **kwargs):
            calls.append(path)
            if path.endswith("authorization"):
                return {"installation_id": "test", "status": "authorized"}
            if len(calls) == 2:
                raise BrokenPipeError(10058, "socket encerrado")
            batch = json.loads(body)
            return {"batch_id": batch["batch_id"], "accepted": True,
                    "accepted_through_sequence": batch["last_sequence"], "duplicate": False,
                    "rejected_events": [], "server_time": STAMP}
        with tempfile.TemporaryDirectory() as folder, \
             patch.object(upload, "_identity", return_value=({"installation_id": "test", "key_id": "key"}, key)), \
             patch.object(upload, "_post", side_effect=post):
            answer = upload.submit_result(result(), {"companion": {"base_url": "https://example.com", "state_dir": folder}})
        self.assertEqual(answer["status"], "accepted")
        self.assertEqual(calls.count(upload.INGEST_PATH), 5)

    def test_bar_replaces_item_log(self):
        import queue
        from rfnext_market.desktop import DesktopApp
        app = DesktopApp.__new__(DesktopApp)
        app._control_queue = queue.SimpleQueue()
        app._queue = queue.Queue()
        app.progress_bars = {"read": Mock(), "upload": Mock()}
        app.progress_labels = {"read": Mock(), "upload": Mock()}
        app._observe({"record_type": "progress", "stage": "market:details", "completed": 25, "total": 100})
        self.assertTrue(app._queue.empty())
        app._handle_event(app._control_queue.get_nowait())
        app.progress_bars["read"].configure.assert_called_once_with(value=25.0)

    def test_seller_exact_uid_all_rankings_and_conflicts(self):
        from rfnext_market import market
        from tests.test_market_flow import detail_1d04, offer_bytes
        source = result()
        uid = 2**63 + 123  # não passar por float (perderia precisão)
        row = source["rankings"]["exp"]["records"][299]
        row.update(character_uid=uid, character_uid_repeat=uid, character_name="Vendedor EXP 300")
        source["rankings"]["cora"]["records"][0].update(character_uid=uid + 1, character_name="Vendedor Cora")
        raw = market.parse_message(0x1D04, detail_1d04(1002, [offer_bytes()]))["fields"]["offers"][0]
        source["market"]["queries"] = [{"kind": "offers", "exchange_server_type": server,
            "complete": True, "ret": 0, "item_index": 1002,
            "entries": [dict(raw, pc_id=n, exchange_index=i) for i,n in enumerate((uid, uid+1, uid+2))]}
            for server in (0,1)]
        original = copy.deepcopy(source)
        payloads = [p for p in upload.market_payloads(source, STAMP) if "offers" in p]
        for p in payloads:
            self.assertEqual([r["seller"] for r in p["offers"]], ["Vendedor EXP 300", "Vendedor Cora", None])
            self.assertEqual(p["offers"][0]["pc_id"], str(uid))
        self.assertEqual(source, original)
        source["rankings"]["bellato"]["records"][0].update(character_uid=uid, character_name="Conflito")
        self.assertNotIn(str(uid), rankings.seller_names(source))
        source["rankings"] = {}
        self.assertEqual(rankings.seller_names(source), {})
