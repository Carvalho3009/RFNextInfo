from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import sys

root = Path(__file__).parent
channel = root.parent / "publication/client-channel"
version = int(sys.argv[1]) if len(sys.argv) > 1 else 22
name = f"rfnext-market-local-global-20260919-v{version}.zip"
updated = {"rfnext_market/desktop.py", "rfnext_market/session.py",
           "rfnext_market/complete.py", "tests/test_complete.py"}
with ZipFile(channel / f"rfnext-market-local-global-20260919-v{version-1}.zip") as old, ZipFile(channel / name, "w", ZIP_DEFLATED) as new:
    for entry in old.infolist():
        if "__pycache__" in entry.filename or entry.filename.endswith(".pyc") or entry.filename in updated:
            continue
        new.writestr(entry.filename, old.read(entry))
    for path in sorted(updated):
        new.write(root / path, path)
with (channel / "SHA256SUMS.txt").open("a", encoding="utf-8") as output:
    output.write(hashlib.sha256((channel / name).read_bytes()).hexdigest() + "  " + name + "\n")
with ZipFile(channel / name) as archive:
    assert archive.testzip() is None
    for path in updated:
        assert archive.read(path) == (root / path).read_bytes()
print(name)
