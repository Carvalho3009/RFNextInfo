@echo off
if "%~1"=="" (
 echo Arraste o arquivo .pcap principal sobre este arquivo.
 pause
 exit /b 1
)
python "%~dp0rfnext_dump_portable.py" "%~1" -o "%~dpn1.completo.json"
if errorlevel 1 (
 echo Falha na conversao.
) else (
 echo Dump completo criado junto da captura. Use-o no preparador com --initialize-character.
)
pause
