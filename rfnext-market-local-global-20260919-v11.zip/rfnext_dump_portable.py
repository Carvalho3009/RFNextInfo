"""Portable RF NEXT all-opcode dump (Python 3.10+, standard library only)."""
import argparse, collections, datetime, hashlib, json, socket, struct
from pathlib import Path

def frame_len(h):
    if not h[0] & 0x80: return int.from_bytes(h[1:3], 'little')
    s=h[0]^0xEF; lo=h[1]^s; s=h[1]^0xEF; hi=h[2]^s; return lo|(hi<<8)

def xor_unwrap(f):
    if not f[0]&0x80: return f
    b=bytearray(f); state=b[0]^0xEF
    for i in range(1,len(b)):
        c=b[i]; b[i]=c^state; state=c^((-0x11*i)&255)
    b[0]&=0x7f; return bytes(b)

def lz4(src):
    out=bytearray(); p=0
    def ext(n):
        nonlocal p
        if n!=15:return n
        z=15
        while True:
            v=src[p];p+=1;z+=v
            if v!=255:return z
    while p<len(src):
        t=src[p];p+=1; n=ext(t>>4); out+=src[p:p+n];p+=n
        if p==len(src):break
        off=src[p]|src[p+1]<<8;p+=2; m=ext(t&15)+4
        for _ in range(m): out.append(out[-off])
    return bytes(out)

def decode(f):
    f=xor_unwrap(f); comp=bool(f[0]&0x40)
    if comp:
        body=lz4(f[6:]); f=f[:6]+body; f=bytes([f[0]&0xbf])+len(f).to_bytes(2,'little')+f[3:]
    return f

def streams(path, port):
    raw=path.read_bytes(); endian='<' if raw[:4] in (b'\xd4\xc3\xb2\xa1',b'\x4d\x3c\xb2\xa1') else '>'
    link=struct.unpack_from(endian+'IHHIIII',raw)[6]; cur=24; flows=collections.defaultdict(list)
    while cur+16<=len(raw):
        sec,usec,cap,_=struct.unpack_from(endian+'IIII',raw,cur);cur+=16; pkt=raw[cur:cur+cap];cur+=cap
        if link==1: net=pkt[14:] if len(pkt)>=14 else b''
        elif link==101: net=pkt
        else: continue
        if len(net)<20 or net[0]>>4!=4 or net[9]!=6: continue
        ihl=(net[0]&15)*4
        if len(net)<ihl+20: continue
        tcp=net[ihl:]; sp,dp,seq,_,of=struct.unpack_from('!HHIIH',tcp); hl=(of>>12)*4; data=tcp[hl:]
        if not data or port not in (sp,dp): continue
        a=socket.inet_ntoa(net[12:16]); b=socket.inet_ntoa(net[16:20]); key=(a,sp,b,dp)
        flows[key].append((seq,data,sec*10**9+usec*1000))
    for key, segs in flows.items():
        segs.sort(); buf=bytearray(); spans=[]; end=None
        for seq,data,ts in segs:
            if end is None: end=seq
            if seq<end: data=data[end-seq:]; seq=end
            if seq!=end: continue
            buf+=data; end+=len(data); spans.append((len(buf),ts))
        yield key,bytes(buf),spans

def utf16(payload,p):
    n=struct.unpack_from('<H',payload,p)[0];p+=2; return payload[p:p+n*2].decode('utf-16le'),p+n*2

def parse_auth(f):
    if int.from_bytes(f[4:6],'little')!=0x0101 or len(f)<8:return None
    p=6; account,p=utf16(f,p); mode=struct.unpack_from('<H',f,p)[0];p+=2; country,p=utf16(f,p); device,p=utf16(f,p); jwt,p=utf16(f,p); host,p=utf16(f,p); key,p=utf16(f,p)
    return {'account_id':account,'connection_mode':mode,'country_code':country,'device_info':json.loads(device),'auth_jwt':jwt,'auth_host':host,'session_key':key,'auth_jwt_length':len(jwt),'session_key_length':len(key)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('pcap',type=Path);ap.add_argument('-o','--output',type=Path,required=True);ap.add_argument('--ports',type=int,nargs='+',default=[12000,12010,12020,12040]);a=ap.parse_args(); rows=[]
    for port in a.ports:
      for flow,stream,spans in streams(a.pcap,port):
        pos=0; i=0
        while pos+3<=len(stream):
            n=frame_len(stream[pos:pos+3])
            if n<6 or pos+n>len(stream):break
            wire=stream[pos:pos+n]; ts=next((t for end,t in spans if end>=pos+n),None)
            try:
                dec=decode(wire); op=int.from_bytes(dec[4:6],'little')
            except (IndexError, ValueError, struct.error) as exc:
                rows.append({'frame_index':i,'flow':f'{flow[0]}:{flow[1]} -> {flow[2]}:{flow[3]}','port':port,'direction':'client_to_server' if flow[3]==port else 'server_to_client','record_type':'decode_error','wire_length':n,'pcap_time_ns':ts,'error':f'{type(exc).__name__}: {exc}','wire_sha256':hashlib.sha256(wire).hexdigest()})
                pos+=n; i+=1; continue
            row={'frame_index':i,'flow':f'{flow[0]}:{flow[1]} -> {flow[2]}:{flow[3]}','port':port,'direction':'client_to_server' if flow[3]==port else 'server_to_client','opcode':f'0x{op:04X}','decoded_length':len(dec),'wire_length':n,'sha256':hashlib.sha256(dec).hexdigest(),'decoded_hex':dec.hex()}
            if ts: row['pcap_time_ns']=ts
            if op==0x0101 and port==12000:
                try:
                    row['authentication']=parse_auth(dec)
                except (IndexError, ValueError, struct.error, UnicodeError) as exc:
                    row['authentication_error']=f'{type(exc).__name__}: {exc}'
            if op==0x1d02 and len(dec)>=12:
                cnt=struct.unpack_from('<H',dec,10)[0]; row['market_item_count']=cnt; row['market_end']=bool(dec[7]); row['market_server_type']=dec[8]
            rows.append(row)
            pos+=n;i+=1
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps({'pcap':str(a.pcap),'ports':a.ports,'records':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(f'{len(rows)} quadros gravados em {a.output}')
if __name__=='__main__':main()
