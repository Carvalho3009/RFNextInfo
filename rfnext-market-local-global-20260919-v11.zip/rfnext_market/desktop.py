"""Interface desktop local para a execução de mercado já existente.

Não interpreta nem cria protocolo: ``session.run`` continua sendo o único executor.
Esta camada apenas valida arquivos, executa em worker e observa registros completos.
"""
from __future__ import annotations

import copy
import json
import queue
import tempfile
import threading
from collections import deque
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import dump, report, session, upload

CLIENT_TO_SERVER = "client_to_server"
PUBLIC_MARKET_KEYS = {
    "list_requests", "detail_requests", "trailing_u8", "detail_all_items",
    "item_database", "products", "response_timeout", "both_markets",
}
MAX_PENDING_RECORDS = 1000
MAX_VISIBLE_RECORDS = 1000
DRAIN_BATCH = 100


def summarize_record(record: dict) -> dict:
    """Produz somente as quatro colunas; o registro original fica retido separadamente."""
    kind = record.get("record_type", "event")
    raw_timestamp = record.get("timestamp")
    try:
        datetime.fromisoformat(raw_timestamp)
        timestamp = raw_timestamp
    except (TypeError, ValueError):
        timestamp = datetime.now().astimezone().isoformat()
    if kind == "frame":
        direction = "TX" if record.get("direction") == CLIENT_TO_SERVER else "RX"
        opcode = record.get("opcode")
        opcode_text = f"0x{opcode:04X}" if isinstance(opcode, int) else "quadro"
        length = record.get("decoded_length", record.get("wire_length", "?"))
        if not isinstance(length, int) or isinstance(length, bool):
            length = "?"
        service_port = record.get("service_port", "?")
        if not isinstance(service_port, int) or isinstance(service_port, bool):
            service_port = "?"
        return {
            "timestamp": timestamp,
            "direction": direction,
            "type": opcode_text,
            "state": "enviado" if direction == "TX" else "recebido",
            "details": f"serviço {service_port}; quadro {length} bytes",
        }
    if kind == "progress":
        completed = record.get("completed", 0)
        total = record.get("total", 0)
        if not isinstance(completed, int) or isinstance(completed, bool):
            completed = "?"
        if not isinstance(total, int) or isinstance(total, bool):
            total = "?"
        return {
            "timestamp": timestamp,
            "direction": "EVENTO",
            "type": "progresso",
            "state": str(record.get("status", "em andamento")),
            "details": ("rankings" if record.get("stage") == "rankings" else "detalhes") + f" {completed}/{total}" + (
                f" — { {0: 'Local', 1: 'Global'}.get(record['exchange_server_type'], record['exchange_server_type'])}"
                if "exchange_server_type" in record else ""),
        }
    if kind == "completion":
        return {
            "timestamp": timestamp,
            "direction": "EVENTO",
            "type": "conclusão",
            "state": str(record.get("status", "")),
            "details": str(record.get("diagnostic", "execução finalizada")),
        }
    return {
        "timestamp": timestamp,
        "direction": "EVENTO",
        "type": str(kind),
        "state": str(record.get("status", "erro")),
        "details": str(record.get("message", record.get("error", record.get("diagnostic", "")))),
    }


def message_details(record: dict) -> str:
    """Serializa o registro integral para inspeção, sem remover ou substituir campos."""
    return json.dumps(record, ensure_ascii=False, indent=2, default=dump._json_default)


def build_config(document: dict, values: dict) -> dict:
    """Aplica os campos editáveis sem alterar payloads de mercado."""
    source_market = document.get("market", {}) if isinstance(document.get("market", {}), dict) else {}
    config = {
        "auth": {}, "game": {}, "world_id": int(values["world_id"]),
        "rankings": document.get("rankings", True),
        "initialize_character": document.get("initialize_character", False),
        "session_file": str(Path(values["session_file"]).expanduser()),
        "market": {key: copy.deepcopy(source_market[key]) for key in PUBLIC_MARKET_KEYS
                   if key in source_market},
    }
    if "credentials" in document:
        config["credentials"] = copy.deepcopy(document["credentials"])
    if isinstance(document.get("companion"), dict):
        config["companion"] = copy.deepcopy(document["companion"])
    for service in ("auth", "game"):
        config[service]["host"] = values[f"{service}_host"].strip()
        config[service]["port"] = int(values[f"{service}_port"])
        config[service]["timeout"] = float(values[f"{service}_timeout"])
    item_database = values.get("item_database", "").strip()
    if item_database:
        config["market"]["item_database"] = item_database
    else:
        config["market"].pop("item_database", None)
    config["market"]["response_timeout"] = float(values["response_timeout"])
    return config


def run_session_worker(config, emit, done, stop_event, runner=session.run, collected=None):
    """Executa a sessão fora da UI e retorna resultado/erro somente pelo callback."""
    published = False

    def publish(result):
        nonlocal published
        if config.get("companion") is not None:
            try:
                result["upload"] = upload.submit_result(result, config, emit=emit, stop_event=stop_event)
            except Exception as exc:
                result["upload"] = {"status": "pending", "diagnostic": f"upload: {type(exc).__name__}: {exc}"}
        published = True
        if collected is not None:
            collected(result)

    try:
        kwargs = {"on_collected": publish} if collected is not None else {}
        result = runner(config, emit, stop_event=stop_event, **kwargs)
        if not published:
            publish(result)
        done(result, None)
    except Exception as exc:  # a UI precisa sempre liberar os botões
        done(None, exc)


def upload_status_text(value):
    labels = {"accepted": "recebido pelo Companion", "pending": "envio pendente",
              "rejected": "envio rejeitado", "awaiting_authorization": "aguardando vínculo/autorização",
              "disabled": "envio desativado", "idle": "sem pendências", "no_market_data": "sem dados de mercado",
              "blocked": "envio bloqueado; resultado salvo localmente"}
    text = labels.get(value.get("status"), str(value.get("status", "")))
    if value.get("pairing_code"):
        text += f"; código de vínculo: {value['pairing_code']}"
    if value.get("diagnostic"):
        text += "; " + value["diagnostic"]
    return text


class DesktopApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("RF Next — consulta de mercado")
        self.root.minsize(900, 560)
        self.config_document = {}
        self.config_path = tk.StringVar()
        self.session_path = tk.StringVar()
        self.item_database = tk.StringVar()
        self.companion_enabled = tk.BooleanVar(value=False)
        self.companion_url = tk.StringVar()
        self.companion_state_dir = tk.StringVar()
        self.vars = {name: tk.StringVar() for name in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        self.stop_event = None
        self.worker = None
        self.records = deque(maxlen=MAX_VISIBLE_RECORDS)
        self.result = None
        self._closing = False
        self._finished = True
        self._dropped_records = 0
        self._queue = queue.Queue(maxsize=MAX_PENDING_RECORDS)
        self._control_queue = queue.SimpleQueue()
        self._tree_order = deque()
        self._tree_records = {}
        self._last_selected_tree = None
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self.root.after(50, self._drain_queue)

    def _build(self):
        files = ttk.LabelFrame(self.root, text="Arquivos locais")
        files.pack(fill="x", padx=8, pady=8)
        self._file_row(files, 0, "Configuração", self.config_path, self._choose_config, False)
        self._file_row(files, 1, "Sessão", self.session_path, self._choose_session, True)
        self._file_row(files, 2, "Base de itens", self.item_database, self._choose_items, True)

        settings = ttk.LabelFrame(self.root, text="Configurações editáveis")
        settings.pack(fill="x", padx=8, pady=(0, 8))
        fields = (
            ("auth_host", "Login host"), ("auth_port", "Login porta"),
            ("auth_timeout", "Login timeout"), ("game_host", "Jogo host"),
            ("game_port", "Jogo porta"), ("game_timeout", "Jogo timeout"),
            ("world_id", "World ID"), ("response_timeout", "Mercado timeout"),
        )
        for index, (name, label) in enumerate(fields):
            row, col = divmod(index, 4)
            ttk.Label(settings, text=label).grid(row=row * 2, column=col, sticky="w", padx=5, pady=(4, 0))
            ttk.Entry(settings, textvariable=self.vars[name], width=22).grid(
                row=row * 2 + 1, column=col, sticky="ew", padx=5, pady=(0, 4))
            settings.columnconfigure(col, weight=1)

        actions = ttk.Frame(self.root)
        actions.pack(fill="x", padx=8, pady=(0, 8))
        self.open_button = ttk.Button(actions, text="Abrir configuração", command=self._choose_config)
        self.open_button.pack(side="left")
        ttk.Button(actions, text="Salvar configuração", command=self._save_config).pack(side="left", padx=5)
        ttk.Button(actions, text="Validar", command=self._validate).pack(side="left")
        self.start_button = ttk.Button(actions, text="Consultar mercado", command=self._start)
        self.start_button.pack(side="left", padx=5)
        self.stop_button = ttk.Button(actions, text="Parar", command=self._stop, state="disabled")
        self.stop_button.pack(side="left")
        ttk.Button(actions, text="Inspecionar selecionada", command=self._inspect_selected).pack(side="right", padx=5)
        ttk.Button(actions, text="Exportar log completo", command=self._export).pack(side="right")

        companion = ttk.LabelFrame(self.root, text="Companion")
        companion.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Checkbutton(companion, text="Enviar ao Companion", variable=self.companion_enabled).grid(row=0, column=0, padx=5)
        ttk.Label(companion, text="Servidor (HTTPS)").grid(row=0, column=1)
        ttk.Entry(companion, textvariable=self.companion_url, width=32).grid(row=0, column=2, padx=5, sticky="ew")
        self.retry_button = ttk.Button(companion, text="Reenviar pendentes", command=self._retry_upload)
        self.retry_button.grid(row=0, column=3, padx=5)
        ttk.Label(companion, text="Pasta da fila").grid(row=1, column=1)
        ttk.Entry(companion, textvariable=self.companion_state_dir).grid(row=1, column=2, columnspan=2, padx=5, sticky="ew")
        companion.columnconfigure(2, weight=1)
        self.progress_bars = {}
        self.progress_labels = {}
        for key, title in (("read", "Leitura"), ("upload", "Envio ao site")):
            frame = ttk.Frame(self.root)
            frame.pack(fill="x", padx=8, pady=(0, 5))
            label = tk.StringVar(value=f"{title}: aguardando")
            ttk.Label(frame, textvariable=label, width=52).pack(side="left")
            bar = ttk.Progressbar(frame, maximum=100, mode="determinate")
            bar.pack(side="left", fill="x", expand=True)
            self.progress_bars[key] = bar
            self.progress_labels[key] = label
        panes = ttk.Panedwindow(self.root, orient="horizontal")
        panes.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tx = self._log_pane(panes, "Mensagens enviadas (TX)")
        self.rx = self._log_pane(panes, "Mensagens recebidas / eventos (RX)")
        panes.add(self.tx[0], weight=1)
        panes.add(self.rx[0], weight=1)
        self.status = tk.StringVar(value="Pronto. Nenhuma conexão foi aberta.")
        ttk.Label(self.root, textvariable=self.status, anchor="w").pack(fill="x", padx=8, pady=(0, 8))

    @staticmethod
    def _file_row(parent, row, label, variable, command, readonly):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=5, pady=3)
        entry = ttk.Entry(parent, textvariable=variable, width=80)
        entry.grid(row=row, column=1, sticky="ew", padx=5, pady=3)
        if readonly:
            entry.configure(state="readonly")
        ttk.Button(parent, text="Selecionar", command=command).grid(row=row, column=2, padx=5, pady=3)
        parent.columnconfigure(1, weight=1)

    def _log_pane(self, parent, title):
        frame = ttk.LabelFrame(parent, text=title)
        tree = ttk.Treeview(frame, columns=("time", "type", "state", "details"), show="headings")
        for column, heading, width in (("time", "Horário", 155), ("type", "Tipo", 90),
                                       ("state", "Estado", 100), ("details", "Detalhes", 330)):
            tree.heading(column, text=heading)
            tree.column(column, width=width, anchor="w")
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.bind("<Double-1>", self._inspect_selected)
        tree.bind("<Return>", self._inspect_selected)
        tree.bind("<<TreeviewSelect>>", self._remember_selected_tree)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        return frame, tree

    def _choose_config(self):
        path = filedialog.askopenfilename(filetypes=(("JSON", "*.json"), ("Todos", "*.*")))
        if not path:
            return
        try:
            document = json.loads(Path(path).read_text(encoding="utf-8"))
            if not isinstance(document, dict):
                raise ValueError("objeto JSON esperado")
            self._load_values(document, Path(path).parent)
            self.config_document = document
            self.config_path.set(path)
            self.status.set("Configuração carregada; credenciais vêm do arquivo de sessão selecionado.")
        except (OSError, json.JSONDecodeError, ValueError, TypeError) as exc:
            messagebox.showerror("Configuração inválida", str(exc))

    def _load_values(self, document, base):
        if not isinstance(document, dict):
            raise ValueError("objeto JSON esperado")
        sections = {}
        for service in ("auth", "game"):
            data = document.get(service, {})
            if not isinstance(data, dict):
                raise ValueError(f"{service}: objeto esperado")
            sections[service] = data
        market = document.get("market", {})
        if not isinstance(market, dict):
            raise ValueError("market: objeto esperado")

        def path_value(raw, label):
            if raw is None or raw == "":
                return ""
            if not isinstance(raw, str):
                raise ValueError(f"{label}: caminho deve ser texto")
            path = Path(raw)
            if not path.is_absolute():
                path = base / path
            return str(path)

        values = {
            "auth_host": sections["auth"].get("host", ""),
            "auth_port": sections["auth"].get("port", ""),
            "auth_timeout": sections["auth"].get("timeout", ""),
            "game_host": sections["game"].get("host", ""),
            "game_port": sections["game"].get("port", ""),
            "game_timeout": sections["game"].get("timeout", ""),
            "world_id": document.get("world_id", ""),
            "response_timeout": market.get("response_timeout", ""),
            "session_path": path_value(document.get("session_file"), "session_file"),
            "item_database": path_value(market.get("item_database"), "market.item_database"),
        }
        companion = upload.validate_config(document, base=base)
        if hasattr(self, "companion_enabled"):
            self.companion_enabled.set(companion is not None)
            self.companion_url.set((companion or {}).get("base_url", ""))
            self.companion_state_dir.set((companion or {}).get("state_dir", str((base / "companion-state").resolve())))
        for name, value in values.items():
            if name in {"session_path", "item_database"}:
                getattr(self, name).set(value)
            else:
                self.vars[name].set(value)
        return values

    def _choose_session(self):
        path = filedialog.askopenfilename(filetypes=(("JSON", "*.json"), ("Todos", "*.*")))
        if path:
            self.session_path.set(path)

    def _choose_items(self):
        path = filedialog.askopenfilename(filetypes=(("SQLite", "*.sqlite"), ("Todos", "*.*")))
        if path:
            self.item_database.set(path)

    def _values(self):
        values = {key: variable.get() for key, variable in self.vars.items()}
        values.update(session_file=self.session_path.get(), item_database=self.item_database.get())
        for service in ("auth", "game"):
            if not values[f"{service}_host"].strip():
                raise ValueError(f"{service}.host: obrigatório")
            if not 1 <= int(values[f"{service}_port"]) <= 65535:
                raise ValueError(f"{service}.port: porta inválida")
            if float(values[f"{service}_timeout"]) <= 0:
                raise ValueError(f"{service}.timeout: deve ser positivo")
        if not 0 <= int(values["world_id"]) <= 0xFFFF:
            raise ValueError("world_id: inteiro 0..65535")
        if float(values["response_timeout"]) <= 0:
            raise ValueError("response_timeout: deve ser positivo")
        if not values["session_file"].strip():
            raise ValueError("sessão: selecione o arquivo JSON")
        return values

    def _current_config(self):
        config = build_config(self.config_document, self._values())
        config.pop("companion", None)
        config.update(self._companion_config())
        return config

    def _companion_config(self):
        if not self.companion_enabled.get():
            return {}
        previous = self.config_document.get("companion") or {}
        companion = {"base_url": self.companion_url.get().strip(),
                     "state_dir": self.companion_state_dir.get().strip() or "companion-state",
                     "timeout": previous.get("timeout", 10)}
        base = Path(self.config_path.get()).resolve().parent if self.config_path.get() else Path.cwd()
        return {"companion": upload.validate_config({"companion": companion}, base=base)}

    def _validate(self):
        try:
            config = self._current_config()
            self._validate_config(config)
            self.status.set("Configuração válida; nenhuma conexão foi aberta.")
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            messagebox.showerror("Erro de configuração", str(exc))

    @staticmethod
    def _validate_config(config):
        session_path = Path(config["session_file"])
        if not session_path.is_file():
            raise ValueError(f"session_file: arquivo não encontrado: {session_path}")
        if config.get("market", {}).get("item_database"):
            if not Path(config["market"]["item_database"]).is_file():
                raise ValueError("market.item_database: arquivo não encontrado")
        # A validação canônica exige um arquivo de configuração; use os mesmos contratos
        # sem abrir socket, temporariamente em memória não é suportado pelo CLI existente.
        from . import __main__ as cli
        handle = tempfile.NamedTemporaryFile(prefix="rfnext-desktop-", suffix=".json", delete=False)
        config_path = Path(handle.name)
        try:
            handle.write(json.dumps(config, ensure_ascii=False).encode("utf-8"))
            handle.close()
            return cli.load_config(config_path)
        finally:
            try:
                handle.close()
            except OSError:
                pass
            try:
                config_path.unlink()
            except FileNotFoundError:
                pass

    def _save_config(self):
        try:
            config = self._current_config()
        except (ValueError, TypeError) as exc:
            messagebox.showerror("Configuração inválida", str(exc))
            return
        path = self.config_path.get() or filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=(("JSON", "*.json"),))
        if not path:
            return
        try:
            Path(path).write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            self.config_path.set(path)
            self.config_document = config
            self.status.set("Configuração salva.")
        except OSError as exc:
            messagebox.showerror("Falha ao salvar", str(exc))

    def _start(self):
        if self.worker and self.worker.is_alive():
            return
        try:
            config = self._current_config()
            loaded = self._validate_config(config)
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            messagebox.showerror("Não foi possível iniciar", str(exc))
            return
        self.records.clear()
        self._dropped_records = 0
        self._finished = False
        self._control_queue = queue.SimpleQueue()
        self._tree_order.clear()
        self._tree_records.clear()
        self.result = None
        for tree in (self.tx[1], self.rx[1]):
            tree.delete(*tree.get_children())
        self.stop_event = threading.Event()
        self.start_button.configure(state="disabled")
        self.retry_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self._reset_progress()
        self.status.set("Executando a sequência existente em worker...")
        self.worker = threading.Thread(
            target=run_session_worker,
            args=(loaded, self._observe,
                  lambda result, error: self._control_queue.put(("done", result, error)), self.stop_event),
            kwargs={"collected": lambda result: self._control_queue.put(("collected", copy.deepcopy(result)))},
            daemon=True,
        )
        self.worker.start()

    def _reset_progress(self, keys=("read", "upload")):
        for key in keys:
            if key in getattr(self, "progress_bars", {}):
                self.progress_bars[key].configure(value=0)
                self.progress_labels[key].set("Leitura: aguardando" if key == "read" else "Envio ao site: aguardando")

    def _update_progress(self, record):
        key = "upload" if record.get("stage") == "upload" else "read"
        if key not in getattr(self, "progress_bars", {}):
            return
        completed, total = record.get("completed", 0), record.get("total", 0)
        percent = min(100, 100 * completed / total) if total else 0
        title = "Envio ao site (lotes processados)" if key == "upload" else (
            "Leitura dos rankings" if record.get("stage") == "rankings" else "Leitura dos detalhes")
        suffix = f"; {record['rejected']} rejeitados" if record.get("rejected") else ""
        self.progress_bars[key].configure(value=percent)
        self.progress_labels[key].set(f"{title}: {completed}/{total} ({percent:.0f}%){suffix}")

    def _observe(self, record):
        if record.get("record_type") == "progress":
            self._control_queue.put(("progress", dict(record)))
            return
        original = copy.deepcopy(record)
        summary = summarize_record(original)
        event = ("record", original, summary)
        if record.get("record_type") == "completion":
            self._control_queue.put(event)
            return
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            self._dropped_records += 1

    def _drain_queue(self):
        record_queue = getattr(self, "_queue", None)
        if record_queue is not None:
            for _ in range(DRAIN_BATCH):
                try:
                    self._handle_event(record_queue.get_nowait())
                except queue.Empty:
                    break
        control_queue = getattr(self, "_control_queue", None)
        if control_queue is not None:
            while True:
                try:
                    self._handle_event(control_queue.get_nowait())
                except queue.Empty:
                    break
        worker_alive = bool(getattr(self, "worker", None) and self.worker.is_alive())
        pending = bool(record_queue is not None and not record_queue.empty())
        if self._closing and not worker_alive and not pending and getattr(self, "_finished", True):
            self.root.destroy()
            return
        self.root.after(50, self._drain_queue)

    def _handle_event(self, event):
        if event[0] == "progress":
            self._update_progress(event[1])
        elif event[0] == "record":
            if len(self.records) >= MAX_VISIBLE_RECORDS:
                del self.records[0]
                self._dropped_records += 1
            self.records.append(event[1])
            self._append_record(event[1], event[2])
        elif event[0] == "done":
            self._finish(event[1], event[2])
        elif event[0] == "collected":
            self.result = event[1]
            if self.result.get("connection", {}).get("status") == "open":
                self.stop_button.configure(text="Desconectar", state="normal")
                suffix = "; " + upload_status_text(self.result["upload"]) if "upload" in self.result else ""
                self.status.set("Coleta concluída; conexão aberta" + suffix)
        elif event[0] == "upload_done":
            self._finished = True
            self.start_button.configure(state="normal")
            self.retry_button.configure(state="normal")
            self.stop_button.configure(state="disabled")
            self.status.set(upload_status_text(event[1]))

    def _append_record(self, record, summary=None):
        summary = summary or summarize_record(record)
        values = tuple(summary[key] for key in ("timestamp", "type", "state", "details"))
        tree = self.tx[1] if summary["direction"] == "TX" else self.rx[1]
        if hasattr(self, "_tree_order"):
            if len(self._tree_order) >= MAX_VISIBLE_RECORDS:
                old_tree, old_item = self._tree_order.popleft()
                old_tree.delete(old_item)
                getattr(self, "_tree_records", {}).pop((old_tree, old_item), None)
            item = tree.insert("", "end", values=values)
            self._tree_order.append((tree, item))
            getattr(self, "_tree_records", {})[(tree, item)] = record
        else:
            children = tree.get_children()
            if len(children) >= MAX_VISIBLE_RECORDS:
                tree.delete(children[0])
            tree.insert("", "end", values=values)
        tree.yview_moveto(1)

    def _finish(self, result, error):
        if getattr(self, "_finished", False):
            return
        self._finished = True
        if isinstance(result, dict):
            self.result = copy.deepcopy(result)
        elif self.result is None:
            self.result = {"status": "failed", "stage": "worker", "diagnostic": "falha de execução",
                           "items": [], "offers": [], "errors": [], "frames": [], "market": {}}
        self.start_button.configure(state="normal")
        if hasattr(self, "retry_button"):
            self.retry_button.configure(state="normal")
        self.stop_button.configure(text="Parar", state="disabled")
        if error:
            self.status.set(f"Erro local: {type(error).__name__}: {error}")
        else:
            status = result.get("status", "sem status") if isinstance(result, dict) else "sem status"
            diagnostic = result.get("diagnostic", "") if isinstance(result, dict) else ""
            suffix = "; " + upload_status_text(self.result["upload"]) if "upload" in self.result else ""
            if self.result.get("connection", {}).get("reason"):
                suffix += "; " + self.result["connection"]["reason"]
            self.status.set(f"Finalizado: {status}; {diagnostic}{suffix}")

    def _stop(self):
        if self.stop_event:
            self.stop_event.set()
            self.status.set("Parada solicitada; aguardando encerramento cooperativo...")

    def _retry_upload(self):
        if self.worker and self.worker.is_alive():
            return
        try:
            config = self._companion_config()
            if not config:
                raise ValueError("Ative o envio e informe o servidor do Companion.")
        except (ValueError, TypeError) as exc:
            messagebox.showerror("Configuração do Companion", str(exc))
            return
        self._finished = False
        self.stop_event = threading.Event()
        self.start_button.configure(state="disabled")
        self.retry_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self._reset_progress(("upload",))
        self.status.set("Reenviando pendentes...")
        def work():
            try:
                result = upload.retry_pending(config, emit=self._observe, stop_event=self.stop_event)
            except Exception as exc:
                result = {"status": "pending", "diagnostic": str(exc)}
            self._control_queue.put(("upload_done", result))
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _close(self):
        self._closing = True
        if self.stop_event and self.worker and self.worker.is_alive():
            self.stop_event.set()
            self.status.set("Parada solicitada; encerrando...")
        self._drain_queue()

    def _remember_selected_tree(self, event):
        tree = getattr(event, "widget", None)
        if any(tree is candidate for candidate in (self.tx[1], self.rx[1])):
            self._last_selected_tree = tree

    def _inspection_tree(self, event=None):
        trees = (self.tx[1], self.rx[1])
        if event is not None:
            widget = getattr(event, "widget", None)
            return next((tree for tree in trees if widget is tree), None)
        focused = self.root.focus_get()
        if any(focused is tree and tree.selection() for tree in trees):
            return focused
        last = getattr(self, "_last_selected_tree", None)
        if any(last is tree and tree.selection() for tree in trees):
            return last
        return focused if any(focused is tree for tree in trees) else None

    def _inspect_selected(self, _event=None):
        tree = self._inspection_tree(_event)
        if tree is not None:
            selected = tree.selection()
            if selected:
                record = getattr(self, "_tree_records", {}).get((tree, selected[0]))
                if record is not None:
                    window = tk.Toplevel(self.root)
                    window.title("Mensagem completa")
                    window.geometry("960x640")
                    text = tk.Text(window, wrap="none")
                    yscroll = ttk.Scrollbar(window, orient="vertical", command=text.yview)
                    xscroll = ttk.Scrollbar(window, orient="horizontal", command=text.xview)
                    text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
                    text.grid(row=0, column=0, sticky="nsew")
                    yscroll.grid(row=0, column=1, sticky="ns")
                    xscroll.grid(row=1, column=0, sticky="ew")
                    window.rowconfigure(0, weight=1)
                    window.columnconfigure(0, weight=1)
                    text.insert("1.0", message_details(record))
                    text.configure(state="disabled")
                    return
        messagebox.showinfo("Mensagem completa", "Selecione uma mensagem TX/RX para inspecionar.")

    def _export(self):
        if not self.records and not isinstance(self.result, dict):
            messagebox.showinfo("Exportação", "Ainda não há registros para exportar.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".jsonl", filetypes=(("JSON Lines", "*.jsonl"),))
        if not path:
            return
        try:
            records = list(self.records)
            omitted = getattr(self, "_dropped_records", 0)
            if omitted:
                records.append({"record_type": "log_truncated", "omitted_records": omitted})
            if isinstance(self.result, dict):
                records.append({"record_type": "result", "result": self.result})
            Path(path).write_text(
                "".join(json.dumps(record, ensure_ascii=False, default=dump._json_default) + "\n"
                        for record in records),
                encoding="utf-8",
            )
            written = None
            if isinstance(self.result, dict):
                base = Path(path).parent
                safe_items = self.result.get("items", [])
                written = report.write_reports(
                    safe_items, base / "mercado_resumo.csv", base / "mercado_ofertas.csv")
            message = "Log exportado com os campos completos retidos."
            if omitted:
                message = f"Log parcial exportado; {omitted} registros foram descartados pelos limites."
            if written:
                message += f" CSV: {written['summary_path']} e {written['offers_path']}."
            self.status.set(message)
        except (OSError, TypeError, ValueError) as exc:
            messagebox.showerror("Falha ao exportar", str(exc))


def main() -> int:
    root = tk.Tk()
    DesktopApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
