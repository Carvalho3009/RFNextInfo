"""Rankings 12020: layouts do decoder do Agent; pedidos observados no cliente."""
import math
import json
import uuid
from pathlib import Path
from .market import _read, _end

REQUESTS = (("exp", 0x1A01, 0x1A02, bytes.fromhex("000000002c010000")),
            ("accretia", 0x240A, 0x240B, b"\x01\x01"),
            ("bellato", 0x240A, 0x240B, b"\x02\x01"),
            ("cora", 0x240A, 0x240B, b"\x03\x01"))
OPCODES = {0x1A01, 0x1A02, 0x1A03, 0x1A04, 0x2408, 0x2409, 0x240A, 0x240B}


def _string(payload, cursor):
    (length,), cursor = _read(payload, cursor, "<H", "string length")
    (raw,), cursor = _read(payload, cursor, f"<{length * 2}s", "UTF-16 string")
    return raw.decode("utf-16le"), cursor


def _record(payload, cursor, exp):
    fmt = "<QQIIIIQ" if exp else "<Q"
    keys = ("character_uid", "total_exp", "rank", "previous_rank", "scope_id_raw",
            "ranking_cycle_raw", "character_uid_repeat") if exp else ("character_uid",)
    values, cursor = _read(payload, cursor, fmt, "rank prefix")
    row = dict(zip(keys, values))
    row["character_name"], cursor = _string(payload, cursor)
    values, cursor = _read(payload, cursor, "<QI" if exp else "<IQ", "rank profile")
    row.update(zip(("profile_uid_raw", "profile_value_raw") if exp else
                   ("biosuit_index", "guild_id"), values))
    row["guild_name"], cursor = _string(payload, cursor)
    if exp:
        (mark,), cursor = _read(payload, cursor, "<4s", "guild mark")
        row["guild_mark_hex"] = mark.hex()
    else:
        values, cursor = _read(payload, cursor, "<IId", "rank values")
        row.update(zip(("guild_mark_raw", "rank", "contribution"), values))
        if not math.isfinite(row["contribution"]):
            raise ValueError("contribution não finita")
    return row, cursor


def parse_message(opcode, payload):
    fields, cursor = {}, 0
    if opcode in (0x1A03, 0x2408):
        pass  # pedido vazio; _end rejeita bytes excedentes
    elif opcode in (0x1A04, 0x2409):
        fmt = "<IIIIQ" if opcode == 0x1A04 else "<HQIQQ"
        keys = (("rank", "previous_rank", "scope_id_raw", "ranking_cycle_raw", "ranking_time_ms")
                if opcode == 0x1A04 else
                ("result_raw", "value0_raw", "value1_raw", "period_start_time_ms", "period_end_time_ms"))
        values, cursor = _read(payload, cursor, fmt, "rank metadata")
        fields.update(zip(keys, values))
    elif opcode == 0x1A01:
        values, cursor = _read(payload, cursor, "<II", "EXP request")
        fields.update(zip(("start_index", "requested_count"), values))
    elif opcode == 0x240A:
        values, cursor = _read(payload, cursor, "<BB", "faction request")
        fields.update(zip(("faction_id_raw", "rank_variant_raw"), values))
    elif opcode in (0x1A02, 0x240B):
        if opcode == 0x240B:
            (faction, variant), cursor = _read(payload, cursor, "<BB", "rank ID")
            fields.update(faction_id_raw=faction, rank_variant_raw=variant)
            fields["self_rank"], cursor = _record(payload, cursor, False)
        (count,), cursor = _read(payload, cursor, "<H", "rank count")
        rows = []
        for _ in range(count):
            row, cursor = _record(payload, cursor, opcode == 0x1A02)
            rows.append(row)
        fields.update(record_count=count, records=rows)
    else:
        raise ValueError("opcode de ranking desconhecido")
    _end(opcode, payload, cursor)
    return {"status": "confirmed", "fields": fields, "unknown_fields": []}


def validate(fields, name):
    rows = fields["records"]
    limit = 300 if name == "exp" else 100
    positions = [r["rank"] for r in rows]
    uids = [r["character_uid"] for r in rows]
    if len(set(positions)) != len(rows) or len(set(uids)) != len(rows):
        raise ValueError("ranking contém posições ou personagens duplicados")
    if any(not 1 <= n <= limit for n in positions) or any(n <= 0 for n in uids):
        raise ValueError("posição ou personagem inválido")
    if name == "exp" and (any(r["character_uid"] != r["character_uid_repeat"] for r in rows)
            or len({(r["scope_id_raw"], r["ranking_cycle_raw"]) for r in rows}) > 1):
        raise ValueError("identidade, escopo ou ciclo de EXP divergente")
    return set(positions) == set(range(1, limit + 1))


def upload_payloads(result, captured_at, emit=None):
    """Mapeia somente Top 100 completos; conserva os demais dados no resultado local."""
    payloads = []
    for name, snapshot in result.get("rankings", {}).items():
        try:
            if name not in ("exp", "accretia", "bellato", "cora"):
                raise ValueError("ranking desconhecido")
            if snapshot.get("status") not in ("completed", "incomplete"):
                raise ValueError("consulta sem resposta válida")
            validate(snapshot, name)
            if snapshot["record_count"] != len(snapshot["records"]):
                raise ValueError("contagem de registros divergente")
            if name != "exp" and (snapshot["faction_id_raw"] !=
                    {"accretia": 1, "bellato": 2, "cora": 3}[name] or snapshot["rank_variant_raw"] != 0):
                raise ValueError("facção ou variante divergente")
            rows = sorted((r for r in snapshot["records"] if r["rank"] <= 100), key=lambda r: r["rank"])
            if [r["rank"] for r in rows] != list(range(1, 101)):
                raise ValueError("Top 100 incompleto")
            curve = None
            if name == "exp":
                data = json.loads(Path(__file__).with_name("level_curve.json").read_text(encoding="utf-8-sig"))
                curve = sorted((int(r["level"]), int(r["need_exp"])) for r in data["level_curve"])
                if not curve:
                    raise ValueError("curva de EXP ausente")
            records = []
            for row in rows:
                character, guild = row["character_name"], row["guild_name"]
                if (not isinstance(character, str) or not character.strip() or len(character) > 80
                        or not isinstance(guild, str) or len(guild) > 80):
                    raise ValueError("nome fora do contrato")
                record = {"rank": row["rank"], "previous_rank": 0,
                          "character_name": character, "guild_name": guild}
                if name == "exp":
                    total = row["total_exp"]
                    if type(total) is not int or not 0 <= total <= 2**63 - 1:
                        raise ValueError("EXP fora do contrato")
                    remaining, level, percent = total, curve[0][0], 100.0
                    for next_level, required in curve[1:]:
                        if required > 0 and remaining < required:
                            percent = round(remaining * 100 / required, 2)
                            break
                        remaining -= max(required, 0)
                        level = next_level
                    previous = row["previous_rank"]
                    record.update(total_exp=total, level=level, level_percent=percent,
                                  previous_rank=previous if type(previous) is int and 1 <= previous <= 100 else 0)
                else:
                    value = row["contribution"]
                    if (type(value) not in (int, float) or not math.isfinite(value)
                            or int(value) != value or not 0 <= value <= 2**63 - 1):
                        raise ValueError("contribuição fora do contrato")
                    record["faction_points"] = int(value)
                records.append(record)
            stamp = snapshot.get("captured_at", captured_at)
            payload = {"snapshot_ref": uuid.uuid4().hex, "top_limit": 100, "record_count": 100,
                       "completeness": "complete", "conflict_count": 0, "source_pages": 1,
                       "first_captured_at": stamp, "captured_at": stamp, "capture_span_ms": 0}
            if name == "exp":
                payload["ranking_records"] = records
            else:
                payload.update(faction=name.capitalize(), faction_ranking_records=records)
            payloads.append(payload)
        except (ValueError, KeyError, TypeError, OverflowError, OSError) as exc:
            if emit:
                emit({"record_type": "upload", "status": "skipped", "ranking": name,
                      "message": f"Ranking {name} não enviado: {exc}; dados mantidos localmente"})
    return payloads


def seller_names(result):
    """UID exato da mesma coleta; nomes conflitantes permanecem desconhecidos."""
    candidates = {}
    for name, snapshot in result.get("rankings", {}).items():
        if name not in ("exp", "accretia", "bellato", "cora") or snapshot.get("status") not in ("completed", "incomplete"):
            continue
        try:
            validate(snapshot, name)
        except (ValueError, KeyError, TypeError):
            continue
        for row in snapshot["records"]:
            uid, character = row["character_uid"], row.get("character_name")
            if (type(uid) is int and 0 < uid <= 2**64 - 1 and isinstance(character, str)
                    and character.strip() and len(character) <= 96):
                candidates.setdefault(str(uid), set()).add(character)
    return {uid: next(iter(names)) for uid, names in candidates.items() if len(names) == 1}
