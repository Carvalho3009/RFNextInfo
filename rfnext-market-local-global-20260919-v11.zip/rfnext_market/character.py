"""Entrada experimental: template 0x0201 observado em 20260919-171931.
Campos desconhecidos permanecem brutos; não há inferência de seleção de personagem.
"""
import struct
from .market import _read


def template(credentials):
    raw = bytes.fromhex(credentials.get("character_enter_payload_hex", ""))
    (units,), cursor = _read(raw, 0, "<H", "account length")
    (account,), cursor = _read(raw, cursor, f"<{units * 2}s", "account")
    if account.decode("utf-16le") != credentials.get("account_id"):
        raise ValueError("0x0201: conta do template difere da sessão")
    _, end = _read(raw, cursor, "<QQ14sQ", "character entry prefix")
    if len(raw) > 65529 or len(raw) <= end:
        raise ValueError("0x0201: template incompleto ou grande demais")
    jwt = credentials.get("auth_jwt")
    if not isinstance(jwt, str) or not jwt or jwt.encode("utf-16le") not in raw:
        raise ValueError("0x0201: JWT difere da sessão; gere os arquivos de uma nova captura de login")
    return raw, cursor


def build(credentials, connection_handle, enter_game_handle):
    raw, cursor = template(credentials)
    out = bytearray(raw)
    struct.pack_into("<Q", out, cursor, connection_handle)
    struct.pack_into("<Q", out, cursor + 30, enter_game_handle)
    return bytes(out), struct.unpack_from("<Q", out, cursor + 8)[0]


def parse_message(opcode, payload):
    if opcode == 0x0202:
        (result, uid), cursor = _read(payload, 0, "<HQ", "character response")
        return {"status": "partial", "fields": {"result_code": result, "character_uid": uid},
                "unknown_fields": [{"name": "tail", "offset": cursor, "hex": payload[cursor:].hex()}]}
    return {"status": "unparsed", "fields": {},
            "unknown_fields": [{"name": "character_entry", "offset": 0, "hex": payload.hex()}]}
