"""Headless shell checks: routing, callback wiring and scalable named fonts."""
import unittest
from types import SimpleNamespace
from unittest.mock import Mock, patch
from rfnext_market import desktop_shell as shell


class Variable:
    def __init__(self, value=""):
        self.value = value
    def get(self):
        return self.value
    def set(self, value):
        self.value = value
    def trace_add(self, *args):
        pass


class Widget:
    all = []
    def __init__(self, parent=None, **kwargs):
        self.parent = parent
        self.options = kwargs
        self.bindings = {}
        self.tabs = []
        self.raised = False
        self.all.append(self)
    def configure(self, **kwargs):
        self.options.update(kwargs)
    def bind(self, event, callback):
        self.bindings[event] = callback
    def add(self, child, **kwargs):
        self.tabs.append((child, kwargs))
    def tkraise(self):
        self.raised = True
    def __getattr__(self, name):
        return lambda *args, **kwargs: None


class ShellTests(unittest.TestCase):
    def make_app(self):
        app = SimpleNamespace(root=Widget(), ui_font_size=14)
        callbacks = ("_stop _start _start_rankings _start_complete _stop_mode _start_heartbeat _retry_upload "
                     "_add_market_selection _select_product _render_market _remove_purchase_selection "
                     "_fetch_shopping _prepare_shopping _execute_purchase_list _stop_purchase_list "
                     "_buy_proposal _add_site_proposals _change_font_size _choose_config _choose_session _choose_items "
                     "_file_row _save_config _validate _start_purchase _inspect_selected _export")
        for name in callbacks.split():
            setattr(app, name, Mock())
        for name in ("config_path session_path item_database companion_enabled companion_url companion_state_dir").split():
            setattr(app, name, Variable())
        app.vars = {key: Variable() for key in ("auth_host auth_port auth_timeout game_host game_port game_timeout world_id response_timeout").split()}
        app.mode_status = {key: Variable("Parado") for key in ("market", "rankings", "complete", "heartbeat")}
        app.mode_continuous = {key: Variable(False) for key in ("market", "rankings", "complete")}
        app.mode_intervals = {key: Variable("5") for key in app.mode_continuous}
        app._table = lambda parent, columns: Widget(parent, columns=columns)
        app._log_pane = lambda parent, title: (Widget(parent), Widget(parent))
        return app

    def test_routes_controls_and_scale_without_rebuilding(self):
        Widget.all = []
        app = self.make_app()
        fake_ttk = SimpleNamespace(**{name: Widget for name in ("Frame Label LabelFrame Button Entry Combobox Checkbutton Notebook Treeview Scrollbar Progressbar Panedwindow").split()}, Style=lambda root: Mock())
        with patch.object(shell, "ttk", fake_ttk), patch.object(shell.tk, "Canvas", Widget), patch.object(shell.tk, "StringVar", Variable), patch.object(shell.font, "families", return_value=("Segoe UI",)), patch.object(shell.font, "Font", side_effect=lambda **kw: Widget(**kw)):
            shell.build(app)
        self.assertEqual(tuple(app.pages), shell.PAGES)
        self.assertEqual(app.page_title.get(), "Dashboard")
        self.assertEqual(app.upload_status.get(), "Aguardando envio")
        self.assertTrue(any(w.options.get("textvariable") is app.mode_status["market"] for w in Widget.all))
        self.assertTrue(any(w.options.get("textvariable") is app.upload_status for w in Widget.all))
        self.assertTrue(any(w.options.get("text") == "Remover selecionada da execução" for w in Widget.all))
        app.show_page("Mercado")
        self.assertTrue(app.pages["Mercado"].raised)
        self.assertEqual(app.page_title.get(), "Mercado")
        with self.assertRaises(StopIteration):
            app.show_page("missing")
        app.mode_buttons["rankings"].options["command"]()
        app._start_rankings.assert_called_once()
        app._start.assert_not_called()
        app.purchase_heartbeat_button.options["command"]()
        app._start_purchase.assert_called_once_with(True)
        app.product_tree.bindings["<<TreeviewSelect>>"]("selection")
        app._select_product.assert_called_once_with("selection")
        self.assertEqual([opts["text"] for _, opts in app.shopping_tabs.tabs], ["Lista de compra", "Lista recebida do site", "Executar lista"])
        self.assertEqual(set(app.progress_bars), {"read", "upload", "market:read", "market:upload", "rankings:read", "rankings:upload"})
        before = app.market_table
        self.assertEqual(shell.apply_font_size(app, 99), 20)
        self.assertEqual(app.ui_fonts["body"].options["size"], 20)
        self.assertEqual(app.ui_fonts["title"].options["size"], 30)
        self.assertIs(before, app.market_table)
        self.assertEqual(shell.apply_font_size(app, 1), 8)
        self.assertTrue(any("alternativa" in w.options.get("text", "") for w in Widget.all))
        with self.assertRaises(ValueError):
            shell.apply_font_size(app, "not a number")
        self.assertEqual(app.font_size.get(), "8")

    def test_profile_container_dashboard_values_and_no_global_stop(self):
        Widget.all = []
        app = self.make_app()
        app.container = Widget(app.root)
        app.profile_label = "Conta Alpha · 123"
        name, diamonds, meta = Variable("Personagem Alpha"), Variable("0"), Variable("Último valor conhecido · 12:00")
        app.dashboard_values = {"character_name": name, "diamonds": diamonds}
        app.dashboard_meta = meta
        fake_ttk = SimpleNamespace(**{key: Widget for key in ("Frame Label LabelFrame Button Entry Combobox Checkbutton Notebook Treeview Scrollbar Progressbar Panedwindow").split()}, Style=lambda root: Mock())
        with patch.object(shell, "ttk", fake_ttk), patch.object(shell.tk, "Canvas", Widget), patch.object(shell.tk, "StringVar", Variable), patch.object(shell.font, "families", return_value=("Arial Rounded MT Bold",)), patch.object(shell.font, "Font", side_effect=lambda **kw: Widget(**kw)):
            shell.build(app)
        self.assertEqual(tuple(app.pages), ("Dashboard", "Captura", "Ranking", "Mercado", "Compras", "Configuração"))
        self.assertEqual(len([w for w in Widget.all if w.parent is app.container]), 2)
        self.assertEqual([w for w in Widget.all if w.parent is app.root], [app.container])
        self.assertIs(app.dashboard_values["character_name"], name)
        self.assertIs(app.dashboard_values["diamonds"], diamonds)
        self.assertIs(app.dashboard_meta, meta)
        self.assertEqual(app.dashboard_values["diamonds"].get(), "0")
        expected = {"character_name", "character_uid", "diamonds", "class", "biosuit", "rover", "level", "cp", "daily_missions", "android_junkyard", "secret_nemesis_base", "public_mining_field", "exclusive_mining_field", "location"}
        self.assertEqual(set(app.dashboard_values), expected)
        for key in expected - {"character_name", "diamonds"}:
            self.assertEqual(app.dashboard_values[key].get(), "Não observado")
        for value in app.dashboard_values.values():
            self.assertTrue(any(w.options.get("textvariable") is value for w in Widget.all))
        self.assertEqual(app.profile_label_var.get(), app.profile_label)
        self.assertTrue(any(w.options.get("textvariable") is app.profile_label_var for w in Widget.all))
        self.assertEqual(app.stop_button.options["text"], "Parar esta conta")
        app.stop_button.options["command"]()
        app._stop.assert_called_once()
        self.assertFalse(any(w.options.get("text") == "Parar tudo" for w in Widget.all))
        self.assertEqual(app.ui_fonts["body"].options["family"], "Arial Rounded MT Bold")


if __name__ == "__main__":
    unittest.main()
