"""Prepare an explicitly selected passive capture session; no network traffic."""
import argparse
import json
from pathlib import Path
from rfnext_market.capture_import import inspect_capture, prepare_candidate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('dump', type=Path)
    parser.add_argument('--auth-host')
    parser.add_argument('--game-host')
    parser.add_argument('--world-id', type=int)
    parser.add_argument('--candidate')
    parser.add_argument('--output-dir', type=Path, default=Path('.'))
    parser.add_argument('--initialize-character', action='store_true', default=None)
    args = parser.parse_args()
    result = inspect_capture(args.dump)
    candidates = result['candidates']
    if args.candidate: candidates = [c for c in candidates if c['candidate_id'] == args.candidate]
    if len(candidates) != 1:
        raise SystemExit('Selecione --candidate: ' + ', '.join(f"{c['candidate_id']} ({c['account_id']})" for c in result['candidates']))
    overrides = {key: value for key, value in vars(args).items() if key in ('auth_host', 'game_host', 'world_id', 'initialize_character') and value is not None}
    prepared = prepare_candidate(candidates[0], overrides)
    output = args.output_dir.resolve(); output.mkdir(parents=True, exist_ok=True)
    for key in ('session', 'config', 'provenance', 'dashboard'):
        (output / f'{key}.json').write_text(json.dumps(prepared[key], ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(f"gerados: {output / 'session.json'} e {output / 'config.json'}")


if __name__ == '__main__': main()
