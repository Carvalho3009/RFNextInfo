"""Workers independentes e intervalo contado depois da coleta e do envio."""
import copy
import math
import threading
import time
import queue
from concurrent.futures import Future, TimeoutError as FutureTimeout
from . import session, upload

SERVER = "https://apirf.karvalho.dev.br"


def mode_config(config, mode):
    value = copy.deepcopy(config)
    value.update(heartbeat_only=mode == "heartbeat", rankings_only=mode == "rankings",
                 rankings=mode == "rankings", initialize_character=mode in ("heartbeat", "rankings"))
    value["heartbeat"] = dict(value.get("heartbeat", {}), enabled=mode == "heartbeat")
    if mode == "heartbeat":
        value["heartbeat"].setdefault("constant", -371988797)
        value["heartbeat"].setdefault("flag", 0)
    value["market"] = dict(value.get("market", {}))
    value["market"].update(both_markets=mode == "market", detail_all_items=mode == "market",
                           detail_requests=[], list_requests=[])
    if mode == "market":
        value["market"]["list_requests"] = [{"payload_hex": "0000"}, {"payload_hex": "0100"}]
    if value.get("companion"):
        value["companion"]["base_url"] = SERVER
    return value


class HeartbeatWorker:
    """Uma conexão, um leitor; consultas não controlam sua parada."""
    def __init__(self, runner=None):
        self.runner = runner or session.run
        self.stop_event = threading.Event()
        self.ready = threading.Event()
        self.ended = threading.Event()
        self.worker = None
        self.confirmations = 0
        self.error = ""
        self._lock = threading.Lock()
        self.purchase_commands = queue.Queue()

    def purchase(self, request, cancel):
        session.purchase.build(request)
        future = Future()
        with self._lock:
            if not self.ready.is_set() or self.ended.is_set() or self.stop_event.is_set():
                raise RuntimeError("Heartbeat precisa estar ativo e confirmado; nenhuma nova conexão será aberta")
            self.purchase_commands.put((dict(request), future, cancel))
        while True:
            if cancel.is_set() and future.cancel():
                return {"status": "cancelled", "diagnostic": "Compra cancelada antes do envio", "request": request}
            try:
                return future.result(timeout=0.1)
            except FutureTimeout:
                if future.done():
                    raise
                continue

    def start(self, config, emit):
        with self._lock:
            if self.worker and self.worker.is_alive():
                return
            self.stop_event.clear()
            self.ready.clear()
            self.ended.clear()
            self.confirmations = 0
            self.error = ""
            def observe(record):
                if record.get("record_type") == "heartbeat" and record.get("status") == "confirmed":
                    self.confirmations += 1
                    if self.confirmations >= 3:
                        self.ready.set()
                    emit({"record_type": "heartbeat_progress", "completed": min(3, self.confirmations),
                          "total": 3, "status": "confirmed", "operation": "heartbeat"})
                emit(dict(record, operation="heartbeat"))
            def maintain():
                try:
                    heartbeat_config = mode_config(config, "heartbeat")
                    heartbeat_config["_purchase_commands"] = self.purchase_commands
                    result = self.runner(heartbeat_config, observe,
                                         stop_event=self.stop_event, on_collected=lambda result: None)
                    self.error = result.get("diagnostic") or result.get("connection", {}).get("reason") or "conexão encerrada"
                except Exception as exc:
                    self.error = str(exc)
                finally:
                    with self._lock:
                        self.ready.clear()
                        self.confirmations = 0
                        self.ended.set()
                        while not self.purchase_commands.empty():
                            _, future, _ = self.purchase_commands.get_nowait()
                            if future.set_running_or_notify_cancel():
                                future.set_exception(RuntimeError("Heartbeat encerrou antes da compra; nada reenviado"))
                    emit({"record_type": "operation_state", "operation": "heartbeat",
                          "status": "stopped" if self.stop_event.is_set() else "failed", "message": self.error})
            self.worker = threading.Thread(target=maintain, name="heartbeat", daemon=True)
            self.worker.start()

    def wait_ready(self, stop_event, timeout):
        deadline = time.monotonic() + timeout
        while not stop_event.is_set():
            if self.stop_event.is_set():
                raise RuntimeError("Heartbeat parado pelo usuario")
            if self.ended.is_set():
                raise RuntimeError("Heartbeat interrompido: " + self.error)
            if self.ready.wait(.05):
                return True
            if time.monotonic() >= deadline:
                raise TimeoutError("Heartbeat: três confirmações não recebidas no prazo")
        return False

    def stop(self):
        self.stop_event.set()


def wait_interval(interval, stop_event, emit, operation):
    deadline = time.monotonic() + interval
    while not stop_event.is_set():
        remaining = max(0, deadline - time.monotonic())
        emit({"record_type": "countdown", "operation": operation,
              "remaining_seconds": math.ceil(remaining)})
        if remaining <= 0:
            return
        stop_event.wait(min(1, remaining))


def run(config, emit, stop_event, continuous=False, interval=300, runner=None, submit=None,
        mode="complete", heartbeat=None):
    if mode not in ("market", "rankings", "complete"):
        raise ValueError("Modo de consulta inválido")
    if not math.isfinite(interval) or interval <= 0:
        raise ValueError("Intervalo deve ser positivo e finito")
    runner, submit = runner or session.run, submit or upload.submit_result
    owns_heartbeat = heartbeat is None and mode == "complete"
    if owns_heartbeat:
        heartbeat = HeartbeatWorker(runner)
    result = None
    try:
        while not stop_event.is_set():
            try:
                emit({"record_type": "operation_state", "operation": mode, "status": "running"})
                if mode in ("rankings", "complete"):
                    if mode == "complete":
                        heartbeat.start(config, emit)
                    if heartbeat is None or heartbeat.worker is None:
                        raise RuntimeError("Inicie o heartbeat antes de consultar rankings")
                    if not heartbeat.wait_ready(stop_event, max(15, config.get("game", {}).get("timeout", 10) * 4)):
                        break
                snapshots = {}
                for step in (("rankings", "market") if mode == "complete" else (mode,)):
                    emit({"record_type": "cycle", "operation": mode, "stage": step, "status": "running"})
                    result = runner(mode_config(config, step), emit, stop_event=stop_event)
                    if step == "rankings":
                        snapshots = result.get("rankings", {})
                    if stop_event.is_set():
                        break
                if result is not None:
                    if mode == "complete":
                        result["rankings"] = snapshots
                        missing = [name for name, *_ in session.rankings.REQUESTS
                                   if snapshots.get(name, {}).get("status") != "completed"]
                        if missing:
                            if result.get("status") == "completed":
                                result["status"] = "incomplete"
                            result["diagnostic"] = "; ".join(filter(None, (
                                result.get("diagnostic"), "Rankings pendentes: " + ", ".join(missing))))
                    result["upload"] = submit(result, mode_config(config, "market"), emit=emit, stop_event=stop_event)
                    emit({"record_type": "cycle", "operation": mode, "stage": "done",
                          "status": result.get("status"), "result": result})
            except Exception as exc:
                emit({"record_type": "cycle", "operation": mode, "stage": "error",
                      "status": "failed", "diagnostic": str(exc), "message": str(exc)})
                if not continuous:
                    raise
            if not continuous or stop_event.is_set():
                break
            wait_interval(interval, stop_event, emit, mode)
        return result
    finally:
        if owns_heartbeat:
            heartbeat.stop()
            if heartbeat.worker:
                heartbeat.worker.join()
        emit({"record_type": "operation_state", "operation": mode, "status": "stopped"})
