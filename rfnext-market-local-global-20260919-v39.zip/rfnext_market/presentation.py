"""Read-only table projections. Large identifiers remain decimal text."""
from . import purchase, report, rankings


def status_text(value):
    return {"completed": "Concluída", "incomplete": "Parcial", "failed": "Falhou", "cancelled": "Cancelada",
            "prepared": "Preparada", "attempted": "Tentativa realizada", "confirmed": "Confirmada",
            "unconfirmed": "Sem confirmação", "blocked": "Bloqueada", "rejected": "Rejeitada", "com_ofertas": "Com ofertas", "sem_ofertas": "Sem ofertas", "ausente": "Ausente", "erro": "Erro"}.get(value, value)


def _seller_labels(result):
    candidates = {}
    for name, snapshot in result.get("rankings", {}).items():
        if name not in ("exp", "accretia", "bellato", "cora") or snapshot.get("status") != "completed":
            continue
        try:
            rankings.validate(snapshot, name)
        except (ValueError, KeyError, TypeError):
            continue
        for entry in snapshot["records"]:
            uid, character = entry.get("character_uid"), entry.get("character_name")
            if type(uid) is int and 0 < uid < 2**64 and isinstance(character, str) and character.strip() and len(character) <= 96:
                candidates.setdefault(str(uid), {}).setdefault(character, set()).add(name)
    return {uid: (next(iter(names)), "Ranking: " + ", ".join(sorted(next(iter(names.values())))))
            if len(names) == 1 else ("Vendedor não informado", "Nomes conflitantes nos rankings")
            for uid, names in candidates.items()}


def market_tree(result, market=0, rankings_result=None):
    """Product/refinement/offer projection; only validated raw integers form a purchase."""
    sellers = _seller_labels(result if rankings_result is None else rankings_result)
    products = {}
    for item in result.get("items", []):
        index = item.get("item_index")
        if item.get("exchange_server_type") != market or type(index) is not int:
            continue
        product = products.setdefault(index, {"key": f"product:{market}:{index}", "item_index": index,
            "name": item.get("produto") or str(index), "refinements": []})
        for offer in item.get("offers", []):
            if not isinstance(offer, dict):
                continue
            info = offer.get("item_info")
            info = info if isinstance(info, dict) else {}
            safe_info = dict(info)
            safe_info["talic_indices"] = info.get("talic_indices") if isinstance(info.get("talic_indices"), list) else []
            safe_info["item_options"] = [o for o in (info.get("item_options") or []) if isinstance(o, dict)] if isinstance(info.get("item_options"), list) else []
            row = report.offer_rows([{**item, "produto": product["name"], "offers": [{**offer, "item_info": safe_info}]}])[0]
            row["seller"], row["seller_source"] = sellers.get(row["pc_id"], ("Vendedor não informado", "Sem correspondência exata em ranking concluído"))
            quantity = info.get("count")
            row["quantity"] = quantity if type(quantity) is int and quantity > 0 else None
            request = {"exchange_server_type": market, "exchange_index": offer.get("exchange_index"),
                       "pc_id": offer.get("pc_id"), "selling_price": offer.get("selling_price"),
                       "item_index": info.get("index"), "enchant_level": info.get("enchant_level")}
            try:
                purchase.build(request)
                if request["item_index"] != index or row["quantity"] is None:
                    raise ValueError("Oferta divergente ou quantidade ausente")
            except ValueError:
                request = None
            row["request"] = request
            refine = info.get("enchant_level")
            refine = refine if type(refine) is int and 0 <= refine < 2**16 else None
            group = next((g for g in product["refinements"] if g["enchant_level"] == refine), None)
            if group is None:
                group = {"key": f"{product['key']}:refine:{refine}", "enchant_level": refine, "offers": []}
                product["refinements"].append(group)
            row["key"] = f"{group['key']}:offer:{row['exchange_index']}:{row['pc_id']}"
            group["offers"].append(row)
    return list(products.values())


def market_rows(result, market=0, query="", refine="Todos", rankings_result=None):
    query = query.strip().casefold()
    return [row for product in market_tree(result, market, rankings_result)
            for group in product["refinements"] for row in group["offers"]
            if (not query or query in (str(row["produto"]) + " " + str(row["item_index"])).casefold())
            and (refine == "Todos" or str(row["enchant_level"]) == refine.strip())]


def market_summary(result, market):
    rows = report.summary_rows([i for i in result.get("items", []) if i.get("exchange_server_type") == market])
    if not rows:
        return "Sem produtos recebidos para este mercado"
    return f"{len(rows)} produtos · {sum(r['ofertas'] for r in rows)} ofertas · {status_text(result.get('status', 'Sem dados'))}"


def ranking_rows(result, exp_only=False):
    rows = []
    for name, snapshot in result.get("rankings", {}).items():
        if exp_only and name != "exp":
            continue
        for entry in snapshot.get("records", []):
            rows.append((name, entry.get("rank", ""), entry.get("character_name", ""),
                         entry.get("guild_name", ""), str(entry.get("character_uid", "")),
                         entry.get("total_exp", entry.get("contribution", "")), status_text(snapshot.get("status", ""))))
    return rows
