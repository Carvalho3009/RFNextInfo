"""One Tk window; each profile owns a controller, view and workers for its lifetime."""
from __future__ import annotations

import json
import hashlib
import queue
import sqlite3
import threading
import time
from pathlib import Path
from tkinter import ttk, filedialog, messagebox, simpledialog
import tkinter as tk

from .accounts import AccountStore, AccountRegistry


class AccountWindow:
    def __init__(self, root, base=None):
        self.root = root
        self.base = Path(base or Path(__file__).resolve().parent.parent)
        self.store = AccountStore(self.base)
        self.registry = AccountRegistry()
        self.apps = {}
        self.selected = None
        self.closing = False
        self.import_worker = None
        self.import_queue = queue.SimpleQueue()
        self.root.title("RF Next Companion · v39")
        self.root.geometry("1280x860")
        self.root.minsize(1050, 700)
        self.root.configure(background="#202326")
        bar = ttk.Frame(root, padding=(18, 10))
        bar.pack(fill="x")
        ttk.Label(bar, text="Conta").grid(row=0, column=0, sticky="w")
        self.choice = tk.StringVar()
        self.selector = ttk.Combobox(bar, textvariable=self.choice, width=18)
        self.selector.grid(row=0, column=1, sticky="ew", padx=10)
        self.selector.bind("<<ComboboxSelected>>", self._selected)
        self.selector.bind("<Return>", self._selected)
        self.selector.bind("<KeyRelease>", self._filter)
        self.selector.configure(postcommand=self._open_choices)
        actions = ttk.Frame(bar)
        actions.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        ttk.Button(actions, text="Adicionar", command=self.add).pack(side="left", padx=4)
        ttk.Button(actions, text="Importar PCAP", command=self.import_capture).pack(side="left", padx=4)
        ttk.Button(actions, text="Renomear", command=self.rename).pack(side="left", padx=4)
        self.context = tk.StringVar(value="Nenhuma conexão aberta")
        context_label = ttk.Label(bar, textvariable=self.context, wraplength=950)
        context_label.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        context_label.bind("<Configure>", lambda event: context_label.configure(wraplength=max(80, event.width)))
        bar.columnconfigure(1, weight=1)
        self.body = ttk.Frame(root)
        self.body.pack(fill="both", expand=True)
        self.body.rowconfigure(0, weight=1)
        self.body.columnconfigure(0, weight=1)
        self.store.migrate_legacy(self.base)
        profiles = self.store.list()
        if not profiles:
            profiles = [self.store.create("Conta 1")]
        self.refresh()
        self.select(profiles[0]["id"])
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(200, self.tick)

    def refresh(self):
        self.profiles = self.store.list()
        self.labels = {}
        for profile in self.profiles:
            app = self.apps.get(profile["id"])
            character = (getattr(app, "dashboard_snapshot", {}).get("character_name") or {}).get("value")
            suffix = f" · {character}" if character else ""
            suffix += f" · {app.mode_status['heartbeat'].get()}" if app else " · Parada"
            self.labels[f"{profile['name']} · {profile['id'][:8]}{suffix}"] = profile["id"]
        self.selector.configure(values=list(self.labels))
        if self.selected:
            self.choice.set(next((label for label, pid in self.labels.items() if pid == self.selected), ""))

    def _filter(self, event=None):
        term = self.choice.get().casefold()
        self.selector.configure(values=[label for label in self.labels if term in label.casefold()])

    def _open_choices(self):
        typed = self.choice.get()
        searching = typed not in self.labels
        self.refresh()
        if searching:
            self.choice.set(typed)
            self._filter()

    def _selected(self, event=None):
        pid = self.labels.get(self.choice.get())
        if pid:
            self.select(pid)

    def select(self, pid):
        if self.closing:
            return
        if pid not in self.apps:
            from .desktop import DesktopApp
            profile = self.store.load(pid)
            frame = ttk.Frame(self.body)
            frame.grid(row=0, column=0, sticky="nsew")
            app = DesktopApp(self.root, container=frame, profile=profile, manager=self)
            self.apps[pid] = app
            self.load_profile(app)
        self.selected = pid
        self.apps[pid].container.tkraise()
        self.refresh()
        self.update_context()

    def load_profile(self, app):
        profile = self.store.load(app.profile_id)
        app.profile = profile
        app.profile_label = profile["name"]
        config_path = Path(profile["config_file"])
        if config_path.exists():
            try:
                config = json.loads(config_path.read_text(encoding="utf-8"))
                app._load_values(config, config_path.parent)
                app.config_document = config
                app.config_path.set(str(config_path))
            except (ValueError, OSError, TypeError) as exc:
                app.status.set(f"Configuração do perfil incompleta: {exc}")
        app.session_path.set(profile["session_file"])
        snapshot_path = Path(profile["path"]) / "dashboard.json"
        if snapshot_path.exists():
            try:
                app.dashboard_snapshot = json.loads(snapshot_path.read_text(encoding="utf-8"))
                self.render_dashboard(app)
            except (ValueError, OSError):
                app.status.set("Snapshot do dashboard inválido; importe novamente a captura.")

    def add(self):
        if self.closing:
            return
        name = simpledialog.askstring("Adicionar conta", "Apelido da conta:", parent=self.root)
        if name and name.strip():
            profile = self.store.create(name.strip())
            self.select(profile["id"])

    def rename(self):
        if self.closing or not self.selected:
            return
        name = simpledialog.askstring("Renomear conta", "Novo apelido:", parent=self.root)
        if name and name.strip():
            self.store.update(self.selected, name=name.strip())
            self.apps[self.selected].profile_label = name.strip()
            self.apps[self.selected].profile_label_var.set(name.strip())
            self.refresh()

    def authorize(self, app, config):
        identity = (config.get("credentials") or {}).get("account_id") or getattr(app, "runtime_account_id", None)
        if not identity:
            raise ValueError("A sessão precisa identificar a conta antes da conexão")
        saved_path = Path(self.store.load(app.profile_id)["session_file"])
        saved_id = None
        if saved_path.is_file():
            saved_id = json.loads(saved_path.read_text(encoding="utf-8")).get("account_id")
            if saved_id and str(saved_id).casefold() != str(identity).casefold():
                raise ValueError("Esta sessão pertence a outra conta. Adicione um perfil para ela")
        signature = hashlib.sha256(json.dumps({k: config.get(k) for k in ("credentials", "auth", "game", "world_id")}, sort_keys=True).encode()).hexdigest() if config else getattr(app, "session_signature", None)
        if app.is_busy() and getattr(app, "session_signature", signature) != signature:
            raise ValueError("A sessão ou os servidores foram alterados. Pare as operações desta conta antes de usar os novos dados")
        for pid, other in self.apps.items():
            if not other.is_busy():
                self.registry.release(pid)
        if not self.registry.acquire(str(identity), app.profile_id):
            raise ValueError("Esta conta já está em execução em outro perfil")
        if not saved_id:
            if not config.get("credentials"):
                raise ValueError("Salve a sessão deste perfil antes de iniciar o heartbeat")
            persisted = {key: value for key, value in config.items() if key != "credentials"}
            self.store.update(app.profile_id, config=persisted, session=config["credentials"])
            self.load_profile(app)
        app.runtime_account_id = str(identity)
        app.session_signature = signature

    def claim_site(self, app):
        config = app._companion_config().get("companion")
        if not config:
            raise ValueError("Configure o vínculo Companion antes de executar a lista recebida")
        path = Path(config["state_dir"]) / "market-upload.sqlite3"
        if not path.is_file():
            raise ValueError("Vínculo Companion não encontrado")
        from .protected_state import unprotect
        with sqlite3.connect(path.as_uri() + "?mode=ro", uri=True) as db:
            row = db.execute("SELECT secret FROM identity WHERE id=1").fetchone()
        if not row:
            raise ValueError("Identidade Companion não encontrada")
        installation = json.loads(unprotect(bytes(row[0])))["installation_id"]
        shopping_ids = [item["shopping_id"] for item in (app.shopping_snapshot or {}).get("items", [])]
        if not self.store.claim_site_executor(app.profile_id, config["state_dir"], installation, shopping_ids=shopping_ids):
            raise ValueError("A lista deste vínculo tem outro perfil executor; isso evita repetir compras entre contas")

    def save_config(self, app, config):
        source = Path(config["session_file"])
        session = json.loads(source.read_text(encoding="utf-8"))
        self.store.update(app.profile_id, config=config, session=session)
        self.load_profile(app)

    def apply_font_size(self, size):
        from .desktop_shell import apply_font_size
        for app in self.apps.values():
            apply_font_size(app, size)

    def import_capture(self):
        if self.closing:
            return
        if self.import_worker and self.import_worker.is_alive():
            messagebox.showinfo("Importação", "Uma captura já está sendo analisada.")
            return
        path = filedialog.askopenfilename(parent=self.root, filetypes=(("Captura ou dump", "*.pcap *.json *.jsonl"), ("Todos", "*.*")))
        if not path:
            return
        self.context.set("Analisando captura; as contas em execução continuam ativas...")
        def work():
            try:
                from .capture_import import inspect_capture
                self.import_queue.put((inspect_capture(path), None))
            except Exception as exc:
                self.import_queue.put((None, str(exc)))
        self.import_worker = threading.Thread(target=work, name="capture-import", daemon=True)
        self.import_worker.start()

    def choose_candidate(self, result):
        candidates = result.get("candidates", [])
        if not candidates:
            messagebox.showerror("Captura", "Nenhuma sessão identificada.\n" + "\n".join(map(str, result.get("diagnostics", []))))
            return
        window = tk.Toplevel(self.root)
        window.title("Selecionar sessão da captura")
        window.geometry("950x560")
        window.transient(self.root)
        window.columnconfigure(0, weight=1)
        window.rowconfigure(0, weight=1)
        table = ttk.Treeview(window, columns=("account", "auth", "game", "world"), show="headings", selectmode="browse")
        for col, title in zip(table["columns"], ("Conta", "Login host", "Game host", "World ID")):
            table.heading(col, text=title)
            table.column(col, width=170, stretch=True)
        table.grid(row=0, column=0, sticky="nsew", padx=12, pady=12)
        scroll = ttk.Scrollbar(window, orient="vertical", command=table.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        table.configure(yscrollcommand=scroll.set)
        details = tk.Text(window, height=8, wrap="word")
        details.grid(row=1, column=0, columnspan=2, sticky="ew", padx=12)
        for i, candidate in enumerate(candidates):
            table.insert("", "end", iid=str(i), values=tuple(candidate.get(key) for key in ("account_id", "auth_host", "game_host", "world_id")))
        def show(event=None):
            if table.selection():
                candidate = candidates[int(table.selection()[0])]
                details.configure(state="normal")
                details.delete("1.0", "end")
                details.insert("1.0", json.dumps({k: candidate.get(k) for k in ("candidate_id", "account_id", "diagnostics", "provenance")}, ensure_ascii=False, indent=2, default=str))
                details.configure(state="disabled")
        table.bind("<<TreeviewSelect>>", show)
        def accept():
            if not table.selection():
                return
            candidate = candidates[int(table.selection()[0])]
            overrides = {}
            for key, label in (("auth_host", "IP do login host"), ("game_host", "IP do game host"), ("world_id", "World ID")):
                if candidate.get(key) is None or candidate.get(key) == "":
                    value = simpledialog.askstring("Campo não encontrado", f"{label} não observado. Informe o valor para revisão manual:", parent=window)
                    if value is None:
                        return
                    if key == "world_id":
                        try:
                            value = int(value)
                        except ValueError:
                            messagebox.showerror("World ID", "Informe um número inteiro.", parent=window)
                            return
                    overrides[key] = value
            try:
                from .capture_import import prepare_candidate
                prepared = prepare_candidate(candidate, overrides)
                self.install_candidate(candidate, prepared)
            except (ValueError, TypeError, OSError) as exc:
                messagebox.showerror("Não foi possível importar", str(exc), parent=window)
                return
            window.destroy()
        ttk.Button(window, text="Salvar sessão no perfil", command=accept).grid(row=2, column=0, sticky="e", padx=12, pady=12)
        table.selection_set("0")
        show()

    def install_candidate(self, candidate, prepared):
        if self.closing:
            raise ValueError("O programa está encerrando")
        identity = prepared["session"].get("account_id")
        if not identity:
            raise ValueError("Captura sem identidade da conta")
        matching = []
        for profile in self.store.list():
            path = Path(profile["session_file"])
            if path.exists():
                saved = json.loads(path.read_text(encoding="utf-8"))
                if saved.get("account_id") == identity:
                    matching.append(profile)
        if len(matching) > 1:
            raise ValueError("Há vários perfis desta conta; resolva a duplicidade antes de importar")
        if matching:
            profile = matching[0]
            app = self.apps.get(profile["id"])
            if app and app.is_busy():
                raise ValueError("Encerre as operações desta conta antes de atualizar a sessão")
            if not messagebox.askyesno("Atualizar sessão", f"Atualizar a captura da conta {profile['name']}? Histórico e vínculo serão preservados.", parent=self.root):
                return
            existing = json.loads(Path(profile["config_file"]).read_text(encoding="utf-8"))
            for key in ("companion",):
                if key in existing:
                    prepared["config"][key] = existing[key]
            self.store.update(profile["id"], config=prepared["config"], session=prepared["session"])
        else:
            name = simpledialog.askstring("Nova conta", "Apelido da conta:", initialvalue=str(identity), parent=self.root)
            if not name:
                return
            selected = self.apps.get(self.selected)
            if selected:
                prepared["config"].update(selected._companion_config())
            profile = self.store.create(name, config=prepared["config"], session=prepared["session"])
        folder = Path(profile["path"])
        for name, value in (("capture-provenance.json", prepared.get("provenance", {})), ("dashboard.json", prepared.get("dashboard", {}))):
            temporary = folder / (name + ".tmp")
            temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
            temporary.replace(folder / name)
        if profile["id"] in self.apps:
            previous = self.apps.pop(profile["id"])
            previous.closed = True
            previous.container.destroy()
        self.select(profile["id"])

    def observe(self, app, event):
        # Called only by the owning DesktopApp's Tk event drain, never its worker.
        record = event[1] if len(event) > 1 and isinstance(event[1], dict) else None
        if record and record.get("record_type") == "frame":
            self.observe_dashboard(app, record)

    def observe_dashboard(self, app, record):
        from . import dashboard
        state = getattr(app, "dashboard_snapshot", None)
        if not isinstance(state, dict) or any(k not in state for k in dashboard.KEYS):
            state = dashboard.empty()
        before = dict(state)
        app.dashboard_snapshot = dashboard.consume(state, record)
        if before != state:
            app.dashboard_dirty = True
            self.render_dashboard(app)

    def render_dashboard(self, app):
        from .dashboard import display_value
        values = getattr(app, "dashboard_values", {})
        snapshot = getattr(app, "dashboard_snapshot", {})
        fields = snapshot.get("fields", snapshot)
        for key, variable in values.items():
            field = fields.get(key)
            value = field.get("value") if isinstance(field, dict) else None
            if value is None:
                variable.set("Não observado")
            else:
                stamp = field.get("timestamp") or "Horário não observado"
                variable.set(f"{display_value(key, value)}\n{field.get('source') or 'Captura'} · {stamp}")
        if hasattr(app, "dashboard_meta"):
            app.dashboard_meta.set("Últimos valores observados · cada campo informa sua origem e horário; heartbeat não atualiza todos os dados")

    def update_context(self):
        app = self.apps.get(self.selected)
        if app:
            active = sum(other.is_busy() for other in self.apps.values())
            self.context.set(f"{app.profile_label} · {app.mode_status['heartbeat'].get()} · {active} conta(s) em execução")

    def tick(self):
        while not self.import_queue.empty():
            result, error = self.import_queue.get()
            if not self.closing:
                if error:
                    messagebox.showerror("Importação", error)
                else:
                    self.choose_candidate(result)
        for app in self.apps.values():
            if getattr(app, "dashboard_dirty", False) and not getattr(app, "dashboard_save_blocked", False) and time.monotonic() - getattr(app, "dashboard_saved_at", 0) >= 2:
                try:
                    folder = Path(app.profile["path"])
                    temp = folder / "dashboard.json.tmp"
                    temp.write_text(json.dumps(app.dashboard_snapshot, ensure_ascii=False, indent=2), encoding="utf-8")
                    temp.replace(folder / "dashboard.json")
                    app.dashboard_dirty = False
                    app.dashboard_saved_at = time.monotonic()
                except OSError as exc:
                    app.dashboard_saved_at = time.monotonic()
                    app.status.set(f"Falha ao salvar dashboard: {exc}")
                    if self.closing:
                        discard = messagebox.askyesno("Falha ao salvar dashboard", f"Conta: {app.profile_label}\n{exc}\n\nEncerrar sem salvar a última atualização do dashboard?\nNão mantém a janela aberta; feche novamente para tentar salvar outra vez.", parent=self.root)
                        if discard:
                            app.dashboard_dirty = False
                        else:
                            app.dashboard_save_blocked = True
        if self.closing and all(app.closed for app in self.apps.values()) and not (self.import_worker and self.import_worker.is_alive()):
            if any(getattr(app, "dashboard_dirty", False) for app in self.apps.values()):
                for app in self.apps.values():
                    if not getattr(app, "dashboard_save_blocked", False):
                        app.dashboard_saved_at = 0
            else:
                self.root.destroy()
                return
        self.update_context()
        self.root.after(200, self.tick)

    def close(self):
        if self.closing:
            for app in self.apps.values():
                app.dashboard_save_blocked = False
                app.dashboard_saved_at = 0
            return
        self.closing = True
        for app in self.apps.values():
            app._close()
