"""Perfis locais isolados e reservas de identidade; não abre conexões."""
import copy
import json
import os
from pathlib import Path
from contextlib import closing
import sqlite3
import tempfile
import threading
import uuid


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


class AccountStore:
    def __init__(self, base):
        self.base = Path(base).resolve()
        self.directory = self.base / "accounts"
        self.directory.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def _folder(self, profile_id):
        try:
            canonical = str(uuid.UUID(profile_id))
        except (ValueError, TypeError, AttributeError) as exc:
            raise ValueError("Identificador de perfil inválido") from exc
        return self.directory / canonical

    def load(self, profile_id):
        folder = self._folder(profile_id)
        data = json.loads((folder / "profile.json").read_text(encoding="utf-8"))
        if data.get("id") != folder.name or not isinstance(data.get("name"), str):
            raise ValueError("Perfil inválido")
        generation = data.get("generation")
        current = folder
        if generation is not None:
            try:
                current = folder / "generations" / str(uuid.UUID(generation))
            except (ValueError, TypeError, AttributeError) as exc:
                raise ValueError("Geração do perfil inválida") from exc
        return dict(data, path=str(folder), config_file=str(current / "config.json"),
                    session_file=str(current / "session.json"))

    def list(self):
        return [self.load(path.parent.name) for path in sorted(self.directory.glob("*/profile.json"))]

    def _config(self, folder, config, origin):
        if not isinstance(config, dict):
            raise ValueError("Configuração deve ser um objeto")
        value = copy.deepcopy(config)
        value["session_file"] = str(folder / "session.json")
        companion = value.get("companion")
        if companion is not None:
            if not isinstance(companion, dict):
                raise ValueError("Companion deve ser um objeto")
            raw = companion.get("state_dir")
            state = Path(raw) if raw else folder / "companion-state"
            if not state.is_absolute():
                state = origin / state
            companion["state_dir"] = str(state.resolve())
        market = value.get("market")
        if isinstance(market, dict) and market.get("item_database"):
            path = Path(market["item_database"])
            market["item_database"] = str((origin / path).resolve())
        return value

    def create(self, name, config=None, session=None):
        with self._lock:
            return self._create(str(uuid.uuid4()), name, config, session, self.base)

    def _create(self, profile_id, name, config, session, origin):
        if not isinstance(name, str) or not name.strip():
            raise ValueError("Nome do perfil obrigatório")
        if session is not None and not isinstance(session, dict):
            raise ValueError("Sessão deve ser um objeto")
        folder = self._folder(profile_id)
        document = self._config(folder, {} if config is None else config, origin)
        return self._commit(folder, {"id": profile_id, "name": name.strip()}, document, session)

    def _commit(self, folder, metadata, config, session):
        # One pointer publishes both files; interrupted writes never mix credentials.
        configured = (config.get("credentials") or {}).get("account_id")
        observed = (session or {}).get("account_id")
        if configured is not None and (observed is None or str(configured).strip().casefold() != str(observed).strip().casefold()):
            raise ValueError("Identidade da configuração difere da sessão")
        generation = str(uuid.uuid4())
        current = folder / "generations" / generation
        config["session_file"] = str(current / "session.json")
        _write(current / "config.json", config)
        if session is not None:
            _write(current / "session.json", session)
        _write(folder / "profile.json", dict(metadata, generation=generation))
        return self.load(metadata["id"])

    def update(self, profile_id, name=None, config=None, session=None):
        with self._lock:
            profile = self.load(profile_id)
            if name is not None and (not isinstance(name, str) or not name.strip()):
                raise ValueError("Nome do perfil obrigatório")
            if session is not None and not isinstance(session, dict):
                raise ValueError("Sessão deve ser um objeto")
            folder = self._folder(profile_id)
            metadata = json.loads((folder / "profile.json").read_text(encoding="utf-8"))
            if name is not None:
                metadata["name"] = name.strip()
            if config is None and session is None:
                _write(folder / "profile.json", metadata)
                return self.load(profile_id)
            old_path = Path(profile["session_file"])
            old_session = json.loads(old_path.read_text(encoding="utf-8")) if old_path.exists() else None
            if session is not None and old_session and old_session.get("account_id"):
                old_identity = str(old_session["account_id"]).strip().casefold()
                new_identity = str(session.get("account_id", "")).strip().casefold()
                if old_identity != new_identity:
                    raise ValueError("Sessão pertence a outra conta; crie outro perfil")
            if config is None:
                config = json.loads(Path(profile["config_file"]).read_text(encoding="utf-8"))
            document = self._config(folder, config, folder)
            return self._commit(folder, metadata, document, session if session is not None else old_session)

    def migrate_legacy(self, legacy_dir=None):
        """Importação idempotente; preserva arquivos e identidade Companion originais."""
        origin = Path(legacy_dir or self.base).resolve()
        profile_id = str(uuid.uuid5(uuid.NAMESPACE_URL, "rfnext-legacy:" + os.path.normcase(str(origin))))
        with self._lock:
            folder = self._folder(profile_id)
            if (folder / "profile.json").exists():
                profile = self.load(profile_id)
                self._reserve_legacy_executor(profile, origin)
                return profile
            source = origin / "config.json"
            if not source.exists() and not (origin / "purchase-list.json").exists() and not (origin / "session.json").exists():
                return None
            config = json.loads(source.read_text(encoding="utf-8-sig")) if source.exists() else {}
            if not isinstance(config, dict):
                raise ValueError("Configuração legada inválida")
            session_path = origin / config.get("session_file", "session.json")
            session = json.loads(session_path.read_text(encoding="utf-8-sig")) if session_path.exists() else None
            if "companion" not in config and (origin / "companion-state").is_dir():
                config["companion"] = {"base_url": "https://apirf.karvalho.dev.br"}
            if isinstance(config.get("companion"), dict):
                config["companion"].setdefault("state_dir", str(origin / "companion-state"))
            purchase = origin / "purchase-list.json"
            if purchase.exists():
                # Parse first so invalid state is surfaced instead of silently discarded.
                purchases = json.loads(purchase.read_text(encoding="utf-8-sig"))
                if not isinstance(purchases, list):
                    raise ValueError("Lista de compras legada inválida")
                _write(folder / "purchase-list.json", purchases)
            profile = self._create(profile_id, "Conta existente", config, session, origin)
            self._reserve_legacy_executor(profile, origin)
            return profile

    def _reserve_legacy_executor(self, profile, origin):
        purchase = Path(profile["path"]) / "purchase-list.json"
        if not purchase.exists():
            return
        entries = json.loads(purchase.read_text(encoding="utf-8"))
        if not any(entry.get("source") == "site" and entry.get("status") in
                   {"sending", "confirmed", "unconfirmed"} for entry in entries):
            return
        config = json.loads(Path(profile["config_file"]).read_text(encoding="utf-8"))
        state = Path((config.get("companion") or {}).get("state_dir", origin / "companion-state"))
        installation = None
        database = state / "market-upload.sqlite3"
        if database.exists():
            with closing(sqlite3.connect(database.resolve().as_uri() + "?mode=ro", uri=True)) as db:
                row = db.execute("SELECT secret FROM identity WHERE id=1").fetchone()
            if row:
                from .protected_state import unprotect
                installation = json.loads(unprotect(bytes(row[0])))["installation_id"]
        shopping_ids = [entry["shopping_id"] for entry in entries if entry.get("source") == "site"
                        and entry.get("status") in {"sending", "confirmed", "unconfirmed"}
                        and entry.get("shopping_id") is not None]
        if not self.claim_site_executor(profile["id"], state, installation, shopping_ids):
            raise ValueError("Histórico legado conflita com outro executor da lista do site")

    def claim_site_executor(self, profile_id, state_dir, installation_id=None, shopping_ids=()):
        """Dono permanente por diretório/instalação, inclusive entre processos."""
        profile_id = self.load(profile_id)["id"]
        if not state_dir:
            raise ValueError("Diretório Companion obrigatório")
        keys = ["state:" + os.path.normcase(str(Path(state_dir).resolve()))]
        if installation_id:
            keys.append("installation:" + str(uuid.UUID(installation_id)))
        for identity in shopping_ids:
            if not isinstance(identity, str) or not identity.isascii() or not identity.isdecimal() or int(identity) <= 0:
                raise ValueError("shopping_id deve ser um decimal positivo")
            keys.append("shopping:" + str(int(identity)))
        with closing(sqlite3.connect(self.base / "site-executors.sqlite3", timeout=10)) as db, db:
            db.execute("CREATE TABLE IF NOT EXISTS owners (identity TEXT PRIMARY KEY, profile TEXT NOT NULL)")
            db.execute("BEGIN IMMEDIATE")
            for key in keys:
                row = db.execute("SELECT profile FROM owners WHERE identity=?", (key,)).fetchone()
                if row and row[0] != profile_id:
                    return False
            db.executemany("INSERT OR IGNORE INTO owners VALUES (?, ?)", [(key, profile_id) for key in keys])
        return True


class AccountRegistry:
    """Uma identidade autenticada por perfil ativo nesta instância do aplicativo."""
    def __init__(self):
        self._owners = {}
        self._lock = threading.Lock()

    @staticmethod
    def _identity(account_id):
        if account_id is None or not str(account_id).strip():
            raise ValueError("Identidade da conta não observada")
        return str(account_id).strip().casefold()

    def acquire(self, account_id, profile_id):
        key = self._identity(account_id)
        if not profile_id:
            raise ValueError("Perfil obrigatório")
        with self._lock:
            if key in self._owners and self._owners[key] != profile_id:
                return False
            self._owners[key] = profile_id
            return True

    def release(self, profile_id):
        with self._lock:
            for key in [key for key, owner in self._owners.items() if owner == profile_id]:
                del self._owners[key]

    def owner(self, account_id):
        with self._lock:
            return self._owners.get(self._identity(account_id))
