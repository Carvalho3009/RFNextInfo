"""Lista do Companion e propostas locais; preparar nunca envia ao jogo."""
import hashlib
import secrets
import uuid
from datetime import datetime, timezone

from . import purchase, report, upload

SCHEMA = "rf-qol.shopping-sync/v1"
PATH = "/api/qol/v1/agent/shopping/sync"


def validate(snapshot):
    if not isinstance(snapshot, dict) or snapshot.get("schema") != SCHEMA:
        raise ValueError("Formato da lista de compras incompatível")
    if not isinstance(snapshot.get("server_time"), str):
        raise ValueError("Lista sem horário de leitura")
    items = snapshot.get("items")
    if not isinstance(items, list) or len(items) > 10000:
        raise ValueError("Lista de compras inválida ou muito grande")
    seen = set()
    for item in items:
        if not isinstance(item, dict):
            raise ValueError("Item da lista inválido")
        identity = item.get("shopping_id")
        if not isinstance(identity, str) or not identity.isascii() or not identity.isdecimal() or int(identity) <= 0 or identity in seen:
            raise ValueError("Identificador da lista inválido ou repetido")
        seen.add(identity)
        for field, maximum, minimum in (("item_index", 2**32-1, 1), ("enchant_level", 65535, 0),
                                         ("remaining_quantity", 2**63-1, 1)):
            upload._integer(item.get(field), maximum, field, minimum)
        if not isinstance(item.get("name"), str):
            raise ValueError("Nome do produto inválido")
        if item.get("reference_unit_price") is not None:
            upload._integer(item["reference_unit_price"], 2**64-1, "reference_unit_price")
        if item.get("updated_at") is not None and not isinstance(item["updated_at"], str):
            raise ValueError("Horário do item inválido")
    return snapshot


def fetch(config_companion, stop_event=None):
    options = upload.validate_config({"companion": config_companion})
    if options is None:
        raise ValueError("Configure o vínculo com o Companion")
    # A mesma identidade protegida do envio; nunca criar um segundo vínculo.
    with upload._UPLOAD_LOCK:
        with upload._database(options) as db:
            registration, key = upload._identity(db, options)
    body = upload._json({"schema": SCHEMA})
    request_id, timestamp, nonce = str(uuid.uuid4()), upload._now(), secrets.token_hex(16)
    digest = hashlib.sha256(body).hexdigest()
    signed = "\n".join(("POST", PATH, request_id, timestamp, nonce, digest)).encode()
    headers = {
        "Idempotency-Key": request_id, "X-RFQOL-Installation-ID": registration["installation_id"],
        "X-RFQOL-Key-ID": registration["key_id"], "X-RFQOL-Timestamp": timestamp,
        "X-RFQOL-Nonce": nonce, "X-RFQOL-Body-SHA256": digest,
        "X-RFQOL-Signature": upload._b64(key.sign(b"RFQOL-INGEST-V1\0" + signed)),
    }
    snapshot = upload._post(options, PATH, body, headers, stop_event=stop_event)
    validate(snapshot)
    if snapshot.get("installation_id") != registration["installation_id"]:
        raise ValueError("Lista recebida pertence a outra instalação")
    return snapshot


def prepare(snapshot, result, capture_ref, market=0):
    validate(snapshot)
    if not isinstance(capture_ref, str) or not capture_ref.strip():
        raise ValueError("Selecione uma captura identificada")
    if type(market) is not int or market not in (0, 1):
        raise ValueError("Selecione Mercado Local ou Global")
    candidates, duplicates = {}, set()
    now = datetime.now(timezone.utc)
    for row in report.offer_rows(result.get("items", [])):
        if type(row["exchange_server_type"]) is not int or row["exchange_server_type"] != market:
            continue
        try:
            request = {"exchange_server_type": market, "item_index": row["item_index"],
                       "enchant_level": row["enchant_level"], "selling_price": row["selling_price"]}
            for field in ("exchange_index", "pc_id"):
                raw = row[field]
                if not isinstance(raw, str) or not raw.isascii() or not raw.isdecimal():
                    raise ValueError("ID inválido")
                request[field] = int(raw)
            payload = purchase.build(request)
            quantity = upload._integer(row["quantidade"], 2**64-1, "quantidade", 1)
            if row["lock"] or row["broken"]:
                continue
            if row["expired_time"] and datetime.fromisoformat(row["expired_time"]) <= now:
                continue
        except (ValueError, TypeError, KeyError):
            continue
        identity = request["exchange_index"]
        candidate = (request, quantity, payload.hex())
        if identity in candidates and candidates[identity] != candidate:
            duplicates.add(identity)
        candidates[identity] = candidate
    ordered = sorted((c for key, c in candidates.items() if key not in duplicates),
                     key=lambda c: (c[0]["selling_price"], c[0]["exchange_index"]))
    proposals, unresolved, used = [], [], set()
    for item in snapshot["items"]:
        remaining = item["remaining_quantity"]
        for request, quantity, payload in ordered:
            if (request["exchange_index"] in used or request["item_index"] != item["item_index"]
                    or request["enchant_level"] != item["enchant_level"] or quantity > remaining):
                continue
            proposals.append({"shopping_id": item["shopping_id"], "name": item["name"],
                              "quantity": quantity, "reference_unit_price": item.get("reference_unit_price"),
                              "capture_ref": capture_ref, "request": dict(request),
                              "payload_hex": payload, "status": "prepared"})
            used.add(request["exchange_index"])
            remaining -= quantity
            if not remaining:
                break
        if remaining:
            unresolved.append({"shopping_id": item["shopping_id"], "name": item["name"],
                               "remaining_quantity": remaining,
                               "reason": "Sem oferta detalhada compatível para lote inteiro nesta captura/mercado"})
    return {"proposals": proposals, "unresolved": unresolved}
