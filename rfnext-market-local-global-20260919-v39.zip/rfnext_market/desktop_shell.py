"""Desktop presentation only; network operations remain in DesktopApp callbacks."""
from types import SimpleNamespace
import tkinter as tk
from tkinter import ttk, font

BG = "#202326"
SIDEBAR = "#181B1E"
CARD = "#2B3035"
TEXT = "#F4F6F7"
MUTED = "#BFC6CB"
BORDER = "#3A4148"
ACCENT = "#44C8B0"
PAGES = ("Dashboard", "Captura", "Ranking", "Mercado", "Compras", "Configuração")


def apply_font_size(app, value):
    """Named fonts update every ttk widget without rebuilding or dropping state."""
    size = max(8, min(20, int(float(value))))
    for name, offset in (("body", 0), ("heading", 1), ("title", 10)):
        app.ui_fonts[name].configure(size=size + offset)
    app.ui_style.configure("Treeview", rowheight=size * 2 + 12)
    if getattr(app, "sidebar", None) is not None:
        app.sidebar.configure(width=max(220, size * 13 + 40))
    app.font_size.set(str(size))
    return size


def _card(parent, title):
    border = ttk.Frame(parent, padding=1, style="Border.TFrame")
    border.pack(fill="x", pady=(0, 14))
    surface = ttk.Frame(border, padding=16, style="Card.TFrame")
    surface.pack(fill="both", expand=True)
    ttk.Label(surface, text=title, style="CardHeading.TLabel").pack(anchor="w", pady=(0, 14))
    panel = ttk.Frame(surface, style="Card.TFrame")
    panel.pack(fill="both", expand=True)
    return panel


def _card_surfaces(widget, in_card=False):
    kind = widget.winfo_class()
    in_card = in_card or (kind == "TFrame" and widget.cget("style") == "Card.TFrame")
    if in_card and kind in ("TLabel", "TFrame", "TCheckbutton"):
        muted = kind == "TLabel" and widget.cget("style") in ("Muted.TLabel", "CardMuted.TLabel")
        if widget.cget("style") not in ("CardHeading.TLabel", "CardValue.TLabel"):
            widget.configure(style="CardMuted.TLabel" if muted else "Card." + kind)
    for child in widget.winfo_children() or ():
        _card_surfaces(child, in_card)


def _scroll_page(parent):
    canvas = tk.Canvas(parent, background=BG, highlightthickness=1,
                       highlightbackground=BG, highlightcolor=ACCENT, takefocus=True)
    scroll = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scroll.set)
    scroll.pack(side="right", fill="y")
    canvas.pack(side="left", fill="both", expand=True)
    content = ttk.Frame(canvas, padding=(0, 0, 12, 0))
    window = canvas.create_window((0, 0), window=content, anchor="nw")
    content.bind("<Configure>", lambda event: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda event: canvas.itemconfigure(window, width=event.width))
    def scroll_pages(amount):
        canvas.yview_scroll(amount, "pages")
        return "break"
    canvas.bind("<Prior>", lambda _: scroll_pages(-1))
    canvas.bind("<Next>", lambda _: scroll_pages(1))
    return content


def _dashboard(app):
    page = _scroll_page(app.pages["Dashboard"])
    values = app.dashboard_values = getattr(app, "dashboard_values", {})
    fields = (("character_name", "Personagem"), ("character_uid", "Character UID"),
              ("diamonds", "Diamantes"), ("level", "Nível"), ("cp", "CP"),
              ("class", "Classe"), ("biosuit", "Biosuit"), ("rover", "Rover"),
              ("daily_missions", "Missões realizadas / 10"), ("location", "Localização"),
              ("android_junkyard", "Android Junkyard"), ("secret_nemesis_base", "Secret Nemesis Base"),
              ("public_mining_field", "Public Mining Field"),
              ("exclusive_mining_field", "Exclusive Mining Field"))
    for key, _ in fields:
        if key not in values:
            values[key] = tk.StringVar(value="Não observado")
    if not hasattr(app, "dashboard_meta"):
        app.dashboard_meta = tk.StringVar(value="Nenhum dado da conta foi observado nesta sessão.")
    meta = ttk.Label(page, textvariable=app.dashboard_meta, style="Muted.TLabel", wraplength=640)
    meta.pack(fill="x", pady=(0, 18))
    meta.bind("<Configure>", lambda event: meta.configure(wraplength=max(80, event.width)))

    def rows(panel, keys):
        panel.columnconfigure(0, weight=1)
        panel.columnconfigure(1, weight=2)
        for row, (key, label) in enumerate(keys):
            title = ttk.Label(panel, text=label, style="CardMuted.TLabel", wraplength=220)
            title.grid(row=row, column=0, sticky="nw", padx=(0, 16), pady=7)
            value = ttk.Label(panel, textvariable=values[key], style="Card.TLabel", wraplength=380)
            value.grid(row=row, column=1, sticky="new", pady=7)
            for widget in (title, value):
                widget.bind("<Configure>", lambda event, target=widget: target.configure(wraplength=max(80, event.width)))

    identity = _card(page, "Personagem e localização")
    rows(identity, (fields[0], fields[1], fields[9]))
    metrics = ttk.Frame(page)
    metrics.pack(fill="x", pady=(0, 14))
    for column, (key, label) in enumerate(fields[2:5]):
        metrics.columnconfigure(column, weight=1, uniform="account_metrics")
        border = ttk.Frame(metrics, padding=1, style="Border.TFrame")
        border.grid(row=0, column=column, sticky="nsew", padx=(0, 8 if column < 2 else 0))
        panel = ttk.Frame(border, padding=16, style="Card.TFrame")
        panel.pack(fill="both", expand=True)
        ttk.Label(panel, text=label, style="CardMuted.TLabel").pack(anchor="w", pady=(0, 10))
        value = ttk.Label(panel, textvariable=values[key], style="CardValue.TLabel", wraplength=170)
        value.pack(fill="x", anchor="w")
        panel.bind("<Configure>", lambda event, target=value: target.configure(wraplength=max(80, event.width - 32)))
    rows(_card(page, "Desenvolvimento"), fields[5:8])
    rows(_card(page, "Missões diárias"), (fields[8],))
    rows(_card(page, "Dungeons limitadas · tempo restante"), fields[10:])


def build(app):
    mount = getattr(app, "container", app.root)
    style = app.ui_style = ttk.Style(app.root)
    style.theme_use("clam")
    installed = set(font.families(app.root))
    family = "Arial Rounded MT Bold" if "Arial Rounded MT Bold" in installed else "Segoe UI"
    app.ui_fonts = {name: font.Font(root=app.root, family=family, size=size)
                    for name, size in (("body", 11), ("heading", 12), ("title", 21))}
    style.configure(".", font=app.ui_fonts["body"], background=BG, foreground=TEXT,
                    bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER)
    style.configure("TFrame", background=BG)
    style.configure("TLabel", background=BG, foreground=TEXT)
    style.configure("TLabelframe", background=BG, bordercolor=BORDER)
    style.configure("TLabelframe.Label", font=app.ui_fonts["heading"], foreground=TEXT)
    for widget in ("TLabelframe", "TLabelframe.Label", "TLabel", "TFrame", "TCheckbutton"):
        style.configure("Card." + widget, background=CARD)
    style.configure("CardMuted.TLabel", background=CARD, foreground=MUTED)
    style.configure("CardHeading.TLabel", background=CARD, foreground=TEXT, font=app.ui_fonts["heading"])
    style.configure("CardValue.TLabel", background=CARD, foreground=TEXT, font=app.ui_fonts["title"])
    style.configure("Border.TFrame", background=BORDER)
    style.configure("Title.TLabel", font=app.ui_fonts["title"])
    style.configure("Muted.TLabel", foreground=MUTED)
    style.configure("TButton", padding=(14, 9), background=CARD, foreground=TEXT, borderwidth=1)
    style.map("TButton", background=[("active", "#3A434B"), ("disabled", BG)], foreground=[("disabled", "#7D868E")])
    style.configure("Primary.TButton", background="#DAEB3C", foreground="#101411")
    style.map("Primary.TButton", background=[("active", "#EAF66A"), ("disabled", CARD)], foreground=[("disabled", MUTED)])
    style.configure("Sidebar.TFrame", background=SIDEBAR)
    style.configure("Sidebar.TLabel", background=SIDEBAR)
    style.configure("Nav.TButton", background=SIDEBAR, anchor="w", padding=(18, 14), borderwidth=0)
    style.configure("Selected.Nav.TButton", background=CARD, foreground=ACCENT)
    style.configure("TEntry", fieldbackground=CARD, foreground=TEXT, insertcolor=TEXT, padding=7)
    style.map("TEntry", fieldbackground=[("readonly", CARD)], foreground=[("readonly", TEXT)])
    style.configure("TCombobox", fieldbackground=CARD, background=CARD, foreground=TEXT, arrowcolor=TEXT, padding=6)
    style.map("TCombobox", fieldbackground=[("readonly", CARD)], foreground=[("readonly", TEXT)])
    style.configure("TCheckbutton", background=BG, foreground=TEXT, padding=6)
    style.map("TCheckbutton", background=[("active", CARD)])
    style.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=TEXT, rowheight=34, borderwidth=0)
    style.configure("Treeview.Heading", background=SIDEBAR, foreground=MUTED, font=app.ui_fonts["heading"], padding=10)
    style.map("Treeview", background=[("selected", "#285F58")], foreground=[("selected", TEXT)])
    style.configure("TNotebook", background=BG, borderwidth=0)
    style.configure("TNotebook.Tab", background=SIDEBAR, foreground=MUTED, padding=(18, 12))
    style.map("TNotebook.Tab", background=[("selected", CARD)], foreground=[("selected", TEXT)])
    style.configure("Horizontal.TProgressbar", background=ACCENT, troughcolor=SIDEBAR, borderwidth=0, thickness=8)
    app.root.configure(background=BG)
    app.root.option_add("*Font", app.ui_fonts["body"])
    app.root.option_add("*Text.background", CARD)
    app.root.option_add("*Text.foreground", TEXT)
    app.root.option_add("*Text.insertBackground", TEXT)
    app.root.option_add("*TCombobox*Listbox.background", CARD)
    app.root.option_add("*TCombobox*Listbox.foreground", TEXT)
    app.font_size = tk.StringVar(value=str(getattr(app, "ui_font_size", 11)))
    apply_font_size(app, app.font_size.get())

    sidebar = app.sidebar = ttk.Frame(mount, style="Sidebar.TFrame",
                                     width=max(220, int(app.font_size.get()) * 13 + 40), padding=(12, 22))
    sidebar.pack(side="left", fill="y")
    sidebar.pack_propagate(False)
    ttk.Label(sidebar, text="RF NEXT\nCompanion", style="Sidebar.TLabel", font=app.ui_fonts["heading"]).pack(anchor="w", padx=16, pady=(0, 34))
    body = ttk.Frame(mount, padding=(24, 20))
    body.pack(side="left", fill="both", expand=True)
    header = ttk.Frame(body)
    header.pack(fill="x", pady=(0, 22))
    header.columnconfigure(0, weight=1)
    app.page_title = tk.StringVar(value="Dashboard")
    ttk.Label(header, textvariable=app.page_title, style="Title.TLabel").grid(row=0, column=0, sticky="w")
    profile = getattr(app, "profile_label", "Conta atual")
    app.profile_label_var = tk.StringVar(value=profile)
    label = ttk.Label(header, textvariable=app.profile_label_var, style="Muted.TLabel", wraplength=640)
    label.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(10, 0))
    label.bind("<Configure>", lambda event, target=label: target.configure(wraplength=max(80, event.width)))
    app.stop_button = ttk.Button(header, text="Parar esta conta", command=app._stop)
    app.stop_button.grid(row=0, column=1, sticky="e", padx=(12, 0))
    heartbeat_state = ttk.Label(header, textvariable=app.mode_status["heartbeat"], style="Muted.TLabel", wraplength=640)
    heartbeat_state.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(8, 0))
    heartbeat_state.bind("<Configure>", lambda event: heartbeat_state.configure(wraplength=max(80, event.width)))
    container = ttk.Frame(body)
    container.pack(fill="both", expand=True)
    container.rowconfigure(0, weight=1)
    container.columnconfigure(0, weight=1)
    app.pages = {name: ttk.Frame(container) for name in PAGES}
    buttons = {}
    def show_page(name):
        if name not in app.pages:
            name = next(key for key, page in app.pages.items() if page is name)
        app.pages[name].tkraise()
        app.page_title.set(name)
        for key, button in buttons.items():
            button.configure(style="Selected.Nav.TButton" if key == name else "Nav.TButton")
    app.show_page = show_page
    app.navigation = SimpleNamespace(select=show_page)
    for name, page in app.pages.items():
        page.grid(row=0, column=0, sticky="nsew")
        buttons[name] = ttk.Button(sidebar, text=name, style="Nav.TButton", command=lambda n=name: show_page(n))
        buttons[name].pack(fill="x", pady=4)
    ttk.Label(sidebar, text="CLIENTE · v39", style="Sidebar.TLabel").pack(side="bottom", anchor="w", padx=16)
    app.status = tk.StringVar(value="Pronto. Nenhuma conexão foi aberta.")
    ttk.Label(body, textvariable=app.status, style="Muted.TLabel", wraplength=900).pack(fill="x", pady=(14, 0))

    _dashboard(app)
    capture = _scroll_page(app.pages["Captura"])
    overview = ttk.Frame(capture)
    overview.pack(fill="x", pady=(0, 18))
    app.upload_status = tk.StringVar(value="Aguardando envio")
    for column, (title, variable) in enumerate((("Mercado", app.mode_status["market"]),
            ("Ranking", app.mode_status["rankings"]), ("Heartbeat", app.mode_status["heartbeat"]),
            ("Envio", app.upload_status))):
        overview.columnconfigure(column, weight=1, uniform="status")
        border = ttk.Frame(overview, padding=1, style="Border.TFrame")
        border.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 5, 0 if column == 3 else 5))
        card = ttk.Frame(border, padding=14, style="Card.TFrame")
        card.pack(fill="both", expand=True)
        ttk.Label(card, text=title, style="CardHeading.TLabel").pack(anchor="w", pady=(0, 12))
        value = ttk.Label(card, textvariable=variable, style="CardMuted.TLabel", wraplength=135)
        value.pack(anchor="w", fill="x")
        card.bind("<Configure>", lambda event, label=value: label.configure(wraplength=max(60, event.width - 28)))
    controls = _card(capture, "Coletas e consultas")
    app.mode_buttons = {}
    for row, (mode, label, command) in enumerate((("market", "Consultar mercado", app._start),
            ("rankings", "Consultar ranking", app._start_rankings), ("complete", "Consulta completa", app._start_complete))):
        button = ttk.Button(controls, text=label, command=command, style="Primary.TButton" if mode == "complete" else "TButton")
        base = row * 3
        button.grid(row=base, column=0, columnspan=4, sticky="w", pady=5)
        app.mode_buttons[mode] = button
        ttk.Checkbutton(controls, text="Contínua", variable=app.mode_continuous[mode]).grid(row=base + 1, column=0, sticky="w")
        ttk.Label(controls, text="Intervalo (min)").grid(row=base + 1, column=1, padx=8)
        ttk.Entry(controls, textvariable=app.mode_intervals[mode], width=4).grid(row=base + 1, column=2, padx=8)
        ttk.Button(controls, text="Parar", command=lambda m=mode: app._stop_mode(m)).grid(row=base + 1, column=3, sticky="w")
        label = ttk.Label(controls, textvariable=app.mode_status[mode], style="Muted.TLabel", wraplength=620)
        label.grid(row=base + 2, column=0, columnspan=4, sticky="ew", pady=(0, 14))
        label.bind("<Configure>", lambda event, widget=label: widget.configure(wraplength=max(80, event.width)))
    ttk.Label(controls, text="O intervalo começa após o encerramento da consulta.", style="Muted.TLabel", wraplength=620).grid(row=9, column=0, columnspan=4, sticky="w")
    app.start_button, app.rankings_button, app.complete_button = (app.mode_buttons[m] for m in ("market", "rankings", "complete"))
    heartbeat = _card(capture, "Heartbeat")
    app.heartbeat_button = ttk.Button(heartbeat, text="Iniciar heartbeat", command=app._start_heartbeat)
    app.heartbeat_button.grid(row=0, column=0, sticky="w")
    ttk.Button(heartbeat, text="Parar", command=lambda: app._stop_mode("heartbeat")).grid(row=0, column=1, padx=10)
    ttk.Label(heartbeat, textvariable=app.mode_status["heartbeat"], style="Muted.TLabel", wraplength=620).grid(row=1, column=0, columnspan=2, sticky="w", pady=(8, 0))
    reads = _card(capture, "Leitura das consultas")
    sends = _card(capture, "Envio")
    ttk.Checkbutton(sends, text="Enviar ao Companion", variable=app.companion_enabled).pack(anchor="w")
    app.retry_button = ttk.Button(sends, text="Reenviar pendentes", command=app._retry_upload)
    app.retry_button.pack(anchor="w", pady=(0, 10))
    app.progress_bars, app.progress_labels = {}, {}
    for key, title in (("read", "Consulta completa"), ("market:read", "Mercado"), ("rankings:read", "Ranking"),
                       ("upload", "Consulta completa"), ("market:upload", "Mercado"), ("rankings:upload", "Ranking")):
        target = sends if "upload" in key else reads
        label = tk.StringVar(value=f"{title}: aguardando")
        ttk.Label(target, textvariable=label, style="Muted.TLabel").pack(anchor="w", pady=(4, 5))
        bar = ttk.Progressbar(target, maximum=100, mode="determinate")
        bar.pack(fill="x", pady=(0, 10))
        app.progress_labels[key], app.progress_bars[key] = label, bar

    app.ranking_status = tk.StringVar(value="Nenhuma consulta de ranking EXP disponível.")
    ttk.Label(app.pages["Ranking"], textvariable=app.ranking_status).pack(anchor="w", pady=8)
    app.ranking_table = app._table(app.pages["Ranking"], (("kind", "Ranking", 90), ("rank", "Posição", 75),
        ("name", "Personagem", 220), ("guild", "Guilda", 140), ("uid", "Character UID", 180), ("value", "EXP", 180), ("status", "Estado", 100)))

    market = app.pages["Mercado"]
    filters = ttk.Frame(market)
    filters.pack(fill="x", pady=(0, 12))
    app.market_scope = tk.StringVar(value="Local")
    app.market_search = tk.StringVar()
    app.market_refine = tk.StringVar(value="Todos")
    filters.columnconfigure(1, weight=1)
    ttk.Label(filters, text="Mercado").grid(row=0, column=0, sticky="w")
    ttk.Label(filters, text="Buscar produto ou ID").grid(row=0, column=1, sticky="w", padx=(12, 0))
    ttk.Combobox(filters, textvariable=app.market_scope, values=("Local", "Global"), state="readonly", width=8).grid(row=1, column=0, sticky="w")
    ttk.Entry(filters, textvariable=app.market_search, width=12).grid(row=1, column=1, sticky="ew", padx=(12, 0))
    ttk.Button(filters, text="Adicionar à lista de compra", command=app._add_market_selection, style="Primary.TButton").grid(row=2, column=0, columnspan=2, sticky="w", pady=(10, 0))
    app.capture_status = tk.StringVar(value="Nenhuma captura disponível. Consulte o mercado na aba Captura.")
    ttk.Label(market, textvariable=app.capture_status, style="Muted.TLabel", wraplength=1000).pack(anchor="w")
    panes = ttk.Panedwindow(market, orient="horizontal")
    panes.pack(fill="both", expand=True, pady=12)
    products = ttk.Frame(panes, padding=(0, 0, 12, 0))
    offers = ttk.Frame(panes)
    panes.add(products, weight=1)
    panes.add(offers, weight=3)
    ttk.Label(products, text="Produtos consultados", font=app.ui_fonts["heading"]).pack(anchor="w", pady=(0, 8))
    app.product_tree = ttk.Treeview(products, columns=("item_index",), show="tree", selectmode="browse")
    product_scroll = ttk.Scrollbar(products, orient="vertical", command=app.product_tree.yview)
    app.product_tree.configure(yscrollcommand=product_scroll.set)
    product_scroll.pack(side="right", fill="y")
    app.product_tree.pack(fill="both", expand=True)
    app.product_tree.bind("<<TreeviewSelect>>", app._select_product)
    ttk.Label(offers, text="Ofertas detalhadas", font=app.ui_fonts["heading"]).pack(anchor="w")
    app.market_table = app._table(offers, (("produto", "Produto", 220), ("enchant_level", "Refino", 70),
        ("quantidade", "Qtd. lote", 90), ("selling_price", "Preço informado", 135), ("seller", "Personagem", 170),
        ("pc_id", "PCID", 170), ("exchange_index", "Oferta", 170), ("registered_time", "Postagem UTC", 180), ("expired_time", "Expiração UTC", 180)))
    for variable in (app.market_scope, app.market_search, app.market_refine):
        variable.trace_add("write", lambda *_: app._render_market())

    tabs = app.shopping_tabs = ttk.Notebook(app.pages["Compras"])
    tabs.pack(fill="both", expand=True)
    local, received, execute = (ttk.Frame(tabs, padding=14) for _ in range(3))
    for page, label in ((local, "Lista de compra"), (received, "Lista recebida do site"), (execute, "Executar lista")):
        tabs.add(page, text=label)
    execute = _scroll_page(execute)
    app.purchase_list_status = tk.StringVar(value="Adicione ofertas na aba Mercado.")
    ttk.Label(local, textvariable=app.purchase_list_status).pack(anchor="w")
    ttk.Button(local, text="Remover selecionada", command=app._remove_purchase_selection).pack(anchor="w", pady=8)
    list_columns = (("name", "Produto", 220), ("refine", "Refino", 70), ("quantity", "Qtd. lote", 90),
                    ("price", "Preço informado", 135), ("market", "Mercado", 90), ("seller", "Personagem", 160), ("offer", "Oferta", 170), ("state", "Estado", 140))
    app.local_purchase_table = app._table(local, list_columns)
    actions = ttk.Frame(received)
    actions.pack(fill="x")
    ttk.Button(actions, text="Receber lista do site", command=app._fetch_shopping).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
    app.shopping_market = tk.StringVar(value="Local")
    ttk.Combobox(actions, textvariable=app.shopping_market, values=("Local", "Global"), state="readonly", width=8).grid(row=1, column=0, sticky="w")
    ttk.Button(actions, text="Preparar ofertas", command=app._prepare_shopping).grid(row=1, column=1, sticky="w", padx=8)
    app.shopping_status = tk.StringVar(value="Integração conforme contrato salvo; depende da disponibilidade da rota no site.")
    ttk.Label(received, textvariable=app.shopping_status, wraplength=900, style="Muted.TLabel").pack(anchor="w", pady=10)
    app.shopping_list_table = app._table(received, (("name", "Produto", 250), ("refine", "Refino", 80),
        ("remaining", "Pendente no site", 150), ("reference", "Referência / un.", 130), ("updated", "Atualizado em", 190)))
    actions = ttk.Frame(execute)
    actions.pack(fill="x")
    app.execution_mode = tk.StringVar(value="Heartbeat ativo")
    ttk.Combobox(actions, textvariable=app.execution_mode, values=("Heartbeat ativo", "Nova conexão"), state="readonly", width=16).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
    ttk.Button(actions, text="Executar lista", command=app._execute_purchase_list, style="Primary.TButton").grid(row=1, column=0, sticky="w")
    ttk.Button(actions, text="Parar lista", command=app._stop_purchase_list).grid(row=1, column=1, sticky="w", padx=8)
    app.list_execution_status = tk.StringVar(value="Revise os lotes e os preços antes de executar.")
    ttk.Label(execute, textvariable=app.list_execution_status, style="Muted.TLabel", wraplength=900).pack(anchor="w", pady=8)
    app.execution_table = app._table(execute, list_columns)
    ttk.Button(execute, text="Remover selecionada da execução", command=lambda: app._remove_purchase_selection(True)).pack(anchor="w", pady=(0, 12))
    ttk.Label(execute, text="Ofertas preparadas da lista do site").pack(anchor="w")
    app.proposal_table = app._table(execute, (("name", "Produto", 220), ("quantity", "Qtd. lote", 95),
        ("price", "Preço informado", 135), ("reference", "Referência / un.", 115), ("market", "Mercado", 80), ("pcid", "PCID", 170), ("offer", "Oferta", 170), ("state", "Estado", 110)))
    actions = ttk.Frame(execute)
    actions.pack(fill="x")
    ttk.Button(actions, text="Adicionar propostas à execução", command=app._add_site_proposals).pack(anchor="w", pady=4)
    ttk.Button(actions, text="Oferta do site: nova conexão", command=lambda: app._buy_proposal(False)).pack(anchor="w", pady=4)
    ttk.Button(actions, text="Oferta do site: heartbeat ativo", command=lambda: app._buy_proposal(True)).pack(anchor="w", pady=4)

    settings_tabs = ttk.Notebook(app.pages["Configuração"])
    settings_tabs.pack(fill="both", expand=True)
    settings_outer, diagnostics = ttk.Frame(settings_tabs), ttk.Frame(settings_tabs, padding=12)
    settings_tabs.add(settings_outer, text="Configuração")
    settings_tabs.add(diagnostics, text="Diagnóstico")
    settings = _scroll_page(settings_outer)
    appearance = _card(settings, "Aparência")
    ttk.Label(appearance, text=f"Fonte: {family}" + (" (alternativa; Arial Rounded MT Bold não está instalada)" if family != "Arial Rounded MT Bold" else "")).pack(anchor="w")
    ttk.Label(appearance, text="Tamanho da fonte (8–20)").pack(side="left", pady=10)
    size_control = ttk.Combobox(appearance, textvariable=app.font_size, values=tuple(map(str, range(8, 21))), state="readonly", width=5)
    size_control.pack(side="left", padx=12)
    size_control.bind("<<ComboboxSelected>>", lambda _: app._change_font_size(app.font_size.get()))
    files = _card(settings, "Arquivos")
    for row, label, variable, command, readonly in ((0, "Configuração", app.config_path, app._choose_config, False),
            (1, "Sessão", app.session_path, app._choose_session, True), (2, "Base de itens", app.item_database, app._choose_items, True)):
        app._file_row(files, row, label, variable, command, readonly)
    for child in files.winfo_children() or ():
        if child.winfo_class() == "TEntry":
            child.configure(width=12)
    connection = _card(settings, "Conexão")
    fields = (("auth_host", "Login host"), ("auth_port", "Login porta"), ("auth_timeout", "Login timeout"),
        ("game_host", "Jogo host"), ("game_port", "Jogo porta"), ("game_timeout", "Jogo timeout"), ("world_id", "World ID"), ("response_timeout", "Mercado timeout"))
    for index, (name, label) in enumerate(fields):
        row, column = divmod(index, 2)
        ttk.Label(connection, text=label).grid(row=row * 2, column=column, sticky="w", padx=8, pady=(8, 0))
        ttk.Entry(connection, textvariable=app.vars[name]).grid(row=row * 2 + 1, column=column, sticky="ew", padx=8)
        connection.columnconfigure(column, weight=1)
    actions = ttk.Frame(settings)
    actions.pack(fill="x", pady=(0, 14))
    app.open_button = ttk.Button(actions, text="Abrir configuração", command=app._choose_config)
    app.open_button.pack(side="left")
    ttk.Button(actions, text="Salvar configuração", command=app._save_config).pack(side="left", padx=8)
    ttk.Button(actions, text="Validar", command=app._validate).pack(side="left")
    companion = _card(settings, "Companion")
    ttk.Label(companion, text="Servidor HTTPS").pack(anchor="w")
    ttk.Entry(companion, textvariable=app.companion_url, state="readonly").pack(fill="x", pady=8)
    ttk.Label(companion, text="Pasta da fila de envio").pack(anchor="w")
    ttk.Entry(companion, textvariable=app.companion_state_dir).pack(fill="x", pady=8)
    manual = _card(settings, "Compra manual por identificadores")
    app.purchase_button = ttk.Button(manual, text="Comprar: nova conexão", command=app._start_purchase)
    app.purchase_button.pack(anchor="w", pady=4)
    app.purchase_heartbeat_button = ttk.Button(manual, text="Comprar: heartbeat ativo", command=lambda: app._start_purchase(True))
    app.purchase_heartbeat_button.pack(anchor="w", pady=4)
    actions = ttk.Frame(diagnostics)
    actions.pack(fill="x", pady=(0, 12))
    ttk.Button(actions, text="Inspecionar selecionada", command=app._inspect_selected).pack(side="left")
    ttk.Button(actions, text="Exportar log completo", command=app._export).pack(side="left", padx=8)
    logs = ttk.Notebook(diagnostics)
    logs.pack(fill="both", expand=True)
    app.tx, app.rx = app._log_pane(logs, "Mensagens enviadas"), app._log_pane(logs, "Mensagens recebidas / eventos")
    logs.add(app.tx[0], text="TX · Envio")
    logs.add(app.rx[0], text="RX · Recebimento")
    _card_surfaces(mount)
    show_page("Dashboard")
