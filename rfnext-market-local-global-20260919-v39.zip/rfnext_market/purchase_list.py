"""Lista persistente de ofertas; cada tentativa exige seleção e confirmação externas."""
import copy
import json
import os
from pathlib import Path
import tempfile
import threading
import uuid

from .purchase import build

_STATUSES = {"prepared", "sending", "confirmed", "unconfirmed", "rejected", "blocked", "cancelled"}


class PurchaseList:
    def __init__(self, path):
        self.path = Path(path)
        self._lock = threading.RLock()
        self._running = False
        self._items = []
        if self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if not isinstance(data, list):
                raise ValueError("Lista de compras inválida")
            ids, offers = set(), set()
            required = {"entry_id", "request", "quantity", "name", "capture_ref", "source",
                        "shopping_id", "status", "diagnostic"}
            for entry in data:
                if not isinstance(entry, dict) or set(entry) != required:
                    raise ValueError("Entrada de compra possui campos inválidos ou ausentes")
                build(entry["request"])
                self._validate_metadata(entry["quantity"], entry["name"], entry["capture_ref"],
                                        entry["source"], entry["shopping_id"])
                identity = self._identity(entry["request"])
                if (not isinstance(entry["entry_id"], str) or not entry["entry_id"]
                        or entry["entry_id"] in ids or identity in offers
                        or not isinstance(entry["status"], str) or entry["status"] not in _STATUSES or not isinstance(entry["diagnostic"], str)):
                    raise ValueError("Entrada de compra inválida ou duplicada")
                ids.add(entry["entry_id"])
                offers.add(identity)
            self._items = data
            changed = False
            for entry in self._items:
                if entry["status"] == "sending":
                    entry.update(status="unconfirmed", diagnostic="Execução interrompida; resultado desconhecido. Não reenviar.")
                    changed = True
            if changed:
                self._save()

    @staticmethod
    def _identity(request):
        return request["exchange_server_type"], request["exchange_index"]

    @staticmethod
    def _validate_metadata(quantity, name, capture_ref, source, shopping_id):
        if type(quantity) is not int or quantity <= 0:
            raise ValueError("Quantidade deve ser um inteiro positivo")
        if not isinstance(name, str) or not isinstance(capture_ref, str):
            raise ValueError("Nome e referência da captura devem ser textos")
        if source not in ("local", "site") or (shopping_id is not None and not isinstance(shopping_id, str)):
            raise ValueError("Origem ou identificador da lista inválido")
        if source == "local" and shopping_id is not None:
            raise ValueError("Compra local não pode ter shopping_id")
        if source == "site" and not shopping_id:
            raise ValueError("Compra do site exige shopping_id")

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(self._items, stream, ensure_ascii=False, indent=2)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, self.path)
        finally:
            if os.path.exists(name):
                os.unlink(name)

    def items(self):
        with self._lock:
            return copy.deepcopy(self._items)

    def add(self, request, quantity, name, capture_ref, source="local", shopping_id=None):
        request = copy.deepcopy(request)
        build(request)
        self._validate_metadata(quantity, name, capture_ref, source, shopping_id)
        with self._lock:
            if self._running:
                raise RuntimeError("Lista em execução")
            for entry in self._items:
                if self._identity(entry["request"]) == self._identity(request):
                    if entry["request"] != request or entry["quantity"] != quantity:
                        raise ValueError("Oferta já registrada com dados diferentes")
                    if entry["source"] != source or entry["shopping_id"] != shopping_id:
                        raise ValueError("Oferta já associada a outra origem ou lista de compras")
                    if entry["status"] == "prepared":
                        previous = dict(entry)
                        entry.update(capture_ref=capture_ref, name=name)
                        try:
                            self._save()
                        except Exception:
                            entry.clear()
                            entry.update(previous)
                            raise
                    return copy.deepcopy(entry)
            entry = dict(entry_id=str(uuid.uuid4()), request=request, quantity=quantity, name=name,
                         capture_ref=capture_ref, source=source, shopping_id=shopping_id,
                         status="prepared", diagnostic="")
            self._items.append(entry)
            try:
                self._save()
            except Exception:
                self._items.pop()
                raise
            return copy.deepcopy(entry)

    def remove(self, entry_id):
        with self._lock:
            if self._running:
                raise RuntimeError("Lista em execução")
            index = next((i for i, entry in enumerate(self._items) if entry["entry_id"] == entry_id), None)
            if index is None:
                raise ValueError("Oferta não encontrada")
            if self._items[index]["status"] != "prepared":
                raise ValueError("O histórico de uma tentativa não pode ser removido")
            entry = self._items.pop(index)
            try:
                self._save()
            except Exception:
                self._items.insert(index, entry)
                raise

    def reserved_quantities(self):
        with self._lock:
            result = {}
            for entry in self._items:
                key = entry["shopping_id"]
                if entry["source"] == "site" and key and entry["status"] in ("sending", "confirmed", "unconfirmed"):
                    result[key] = result.get(key, 0) + entry["quantity"]
            return result

    def run(self, entry_ids, execute_one, cancel, emit):
        ids = tuple(entry_ids)
        with self._lock:
            if self._running:
                raise RuntimeError("Lista em execução")
            if not ids or len(set(ids)) != len(ids):
                raise ValueError("Selecione ofertas únicas para executar")
            lookup = {entry["entry_id"]: entry for entry in self._items}
            selected = []
            for key in ids:
                entry = lookup.get(key)
                if entry is None or entry["status"] != "prepared":
                    raise ValueError("A seleção contém oferta ausente ou já tentada")
                build(entry["request"])
                selected.append(entry)
            self._running = True
        results = []
        try:
            for entry in selected:
                if cancel.is_set():
                    return dict(status="cancelled", items=results, diagnostic="Cancelado antes do próximo envio")
                with self._lock:
                    entry["status"] = "sending"
                    try:
                        self._save()
                    except Exception:
                        entry["status"] = "prepared"
                        raise
                try:
                    answer = execute_one(copy.deepcopy(entry["request"]), cancel)
                    status = answer.get("status")
                    if status not in _STATUSES - {"prepared", "sending"}:
                        raise ValueError("Resultado da compra inválido")
                    diagnostic = str(answer.get("diagnostic", ""))
                    if status == "cancelled" and diagnostic not in (
                            "Cancelado antes do envio", "Compra cancelada antes do envio"):
                        status = "unconfirmed"
                        diagnostic = f"Cancelamento sem confirmação de pré-envio: {diagnostic}; não reenviar"
                except Exception as exc:
                    status, diagnostic = "unconfirmed", f"Resultado desconhecido: {exc}; não reenviar"
                with self._lock:
                    entry.update(status=status, diagnostic=diagnostic)
                    try:
                        self._save()
                    except Exception:
                        entry.update(status="unconfirmed", diagnostic="Falha ao salvar resultado; não reenviar")
                        raise
                result = dict(entry_id=entry["entry_id"], status=status, diagnostic=diagnostic)
                results.append(result)
                emit(dict(record_type="purchase_list_progress", completed=len(results), total=len(selected), **result))
                if status != "confirmed":
                    return dict(status=status, items=results, diagnostic=diagnostic)
            return dict(status="completed", items=results, diagnostic="Compras confirmadas pelo servidor")
        finally:
            with self._lock:
                self._running = False
