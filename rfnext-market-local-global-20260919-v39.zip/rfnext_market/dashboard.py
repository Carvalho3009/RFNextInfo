"""Bounded account observations using verified prefixes, never ranking guesses."""
import struct
import json
from pathlib import Path
from functools import lru_cache

@lru_cache(maxsize=1)
def _biosuits():
    return json.loads(Path(__file__).with_name("biosuits.json").read_text(encoding="utf-8"))["biosuits"]

DUNGEONS = {"android_junkyard": (20,19), "secret_nemesis_base": (22,21), "exclusive_mining_field": (54,53)}

def _times(balances):
    output = {}
    for name,(basic,charged) in DUNGEONS.items():
        b,c=balances.get(basic),balances.get(charged)
        if b is not None or c is not None:
            output[name]={"default_seconds":b,"charged_seconds":c,"remaining_seconds":b+c if b is not None and c is not None else None}
    if any(i in balances for i in (58,55,56,57)):
        b=balances.get(58)
        output["public_mining_field"]={"default_seconds":b,"charged_by_faction":{f:balances.get(i) for f,i in (("accretia",55),("bellato",56),("cora",57))},"remaining_seconds":None}
    return output

KEYS = ('character_name', 'character_uid', 'diamonds', 'class', 'biosuit', 'rover', 'level', 'cp',
        'daily_missions', 'android_junkyard', 'secret_nemesis_base', 'public_mining_field',
        'exclusive_mining_field', 'location')


def empty():
    return {key: {'value': None, 'status': 'not_observed', 'source': None, 'timestamp': None} for key in KEYS}


def consume(state, record):
    """Mutate and return a bounded snapshot; caller scopes records to one account."""
    if record.get('direction') not in ('server_to_client', 's2c') :
        return state
    try:
        frame = bytes.fromhex(record.get('decoded_hex', ''))
        if len(frame) < 6: return state
        port = record.get('service_port', record.get('port'))
        if port not in (12020,12010,12040): return state
        opcode = int.from_bytes(frame[4:6], 'little'); raw = frame[6:]
        values = {}
        if port in (12010,12040):
            # Only callers with verified realtime-flow ownership may set this flag.
            if record.get('account_scoped') is not True or not state['character_uid']['value']: return state
            if opcode == 0x0401 and len(raw)==786: values={'cp':struct.unpack_from('<Q',raw,772)[0]}
            elif port==12010 and opcode==0x0423 and len(raw)==762: values={'cp':struct.unpack_from('<Q',raw,752)[0]}
            else: return state
        elif opcode == 0x0202:
            ret, uid = struct.unpack_from('<HQ', raw)
            if ret == 0: values = {'character_uid': str(uid)}
        elif opcode == 0x0305:
            uid, units = struct.unpack_from('<QH', raw)
            # Other visible players must never overwrite this account.
            if state['character_uid']['value'] != str(uid): return state
            end = 10 + units * 2
            if len(raw) < end + 46: return state
            values = {'character_name': raw[10:end].decode('utf-16le'),
                      'level': struct.unpack_from('<H', raw, end)[0],
                      'diamonds': struct.unpack_from('<Q', raw, end + 38)[0]}
            if len(raw)-end in (1057,1065):
                balances={i:struct.unpack_from('<q',raw,end+22+(i-1)*8)[0] for i in (19,20,21,22,53,54,55,56,57,58)}
                instant=struct.unpack_from('<q',raw,end+102)[0]
                values['daily_missions']={'completed':None,'remaining':None,'limit':10,'instant_completed':instant if instant>=0 else None}
                values.update(_times({i:v if v>=0 else None for i,v in balances.items()}))
            if len(raw)-end-46 in (988,996,1004,1012):
                values['biosuit']=struct.unpack_from('<I',raw,end+829)[0]
                values['rover']=struct.unpack_from('<I',raw,end+834)[0]
        elif opcode in (0x1304,0x1403) and len(raw)==(15 if opcode==0x1304 else 7):
            if not state['character_uid']['value'] or int.from_bytes(raw[:2],'little')!=0: return state
            values['biosuit' if opcode==0x1304 else 'rover']=struct.unpack_from('<I',raw,2)[0]
        elif opcode==0x0325 and len(raw)==43:
            if not state['character_uid']['value'] or int.from_bytes(raw[:2],'little')!=0: return state
            values['location']={'map_index':struct.unpack_from('<I',raw,22)[0]}
            if struct.unpack_from('<I',raw,2)[0]==7: values['location']['position']=list(struct.unpack_from('<fff',raw,27))
        elif opcode==0x0407 and len(raw)==14:
            if not state['character_uid']['value']: return state
            _,kind,balance=struct.unpack('<HIq',raw)
            balances={}
            for name,(basic,charged) in DUNGEONS.items():
                previous=state[name]['value'] or {}
                balances[basic]=previous.get('default_seconds');balances[charged]=previous.get('charged_seconds')
            previous=state['public_mining_field']['value'] or {}
            balances[58]=previous.get('default_seconds')
            for f,i in (('accretia',55),('bellato',56),('cora',57)): balances[i]=previous.get('charged_by_faction',{}).get(f)
            if kind in balances:
                balances[kind]=balance if balance>=0 else None
                times=_times(balances)
                values={name:value for name,value in times.items() if (kind in DUNGEONS.get(name,()) or name=='public_mining_field' and kind in (58,55,56,57))}
            elif kind==11 and balance>=0 and struct.unpack_from('<H',raw)[0]==3412:
                values['daily_missions']={'completed':None,'remaining':None,'limit':10,'instant_completed':balance}
            elif kind==3 and balance>=0: values['diamonds']=balance
        else: return state
        if 'biosuit' in values:
            item=_biosuits().get(str(values['biosuit']),{})
            values['class']=item.get('class_name') or None
        timestamp = record.get('timestamp', record.get('pcap_time_ns'))
        if 'character_uid' in values and state['character_uid']['value'] not in (None, values['character_uid']):
            state.clear(); state.update(empty())
        for key, value in values.items():
            old = state[key]['timestamp']
            if old is not None and timestamp is not None and type(old) is type(timestamp) and timestamp < old: continue
            state[key] = {'value': value, 'status': 'observed' if value is not None else 'not_observed', 'source': f'{port}/0x{opcode:04X}', 'timestamp': timestamp}
    except (ValueError, TypeError, struct.error, UnicodeError):
        pass  # Partial capture does not erase the last complete observation.
    return state


def snapshot(records, character_uid=None):
    state = empty()
    if character_uid is not None:
        state['character_uid'] = {'value': str(character_uid), 'status': 'observed', 'source': 'selected_character', 'timestamp': None}
    for record in records: consume(state, record)
    return state


def _duration(value):
    if value is None: return 'Não observado'
    hours, remainder = divmod(value, 3600)
    minutes, seconds = divmod(remainder, 60)
    return f'{hours:02d}:{minutes:02d}:{seconds:02d}'


def display_value(key, value):
    if value is None: return 'Não observado'
    if key=='daily_missions':
        instant=value.get('instant_completed')
        return f"Total: não observado / {value['limit']} · instantâneas: {instant if instant is not None else 'Não observado'}"
    if key in DUNGEONS:
        total=value.get('remaining_seconds')
        return _duration(total) if total is not None else f"Básico: {_duration(value.get('default_seconds'))} · recarga: {_duration(value.get('charged_seconds'))}"
    if key=='public_mining_field':
        charged=value.get('charged_by_faction', {})
        return ' · '.join([f"Básico: {_duration(value.get('default_seconds'))}"]+[f"{label}: {_duration(charged.get(faction))}" for faction,label in (('accretia','Accretia'),('bellato','Bellato'),('cora','Cora'))])
    if key=='location':
        text=f"Mapa {value.get('map_index', 'Não observado')}"
        position=value.get('position')
        return text + (' · '+', '.join(f'{axis} {number:.1f}' for axis,number in zip(('X','Y','Z'),position)) if position else '')
    if key=='biosuit':
        item=_biosuits().get(str(value),{})
        return f"{item.get('name', 'Biosuit')} ({value})"
    return str(value)
