"""Passive capture import. Never opens a network connection."""
import json
import socket
import struct
from datetime import datetime, timezone
from pathlib import Path

from . import auth, character, selection, transport


def _pcap(path):
    from rfnext_dump_portable import decode, frame_len
    raw = path.read_bytes()
    magics = {b'\xd4\xc3\xb2\xa1': ('<', 1000), b'\xa1\xb2\xc3\xd4': ('>', 1000),
              b'\x4d\x3c\xb2\xa1': ('<', 1), b'\xa1\xb2\x3c\x4d': ('>', 1)}
    if len(raw) < 24 or raw[:4] not in magics:
        raise ValueError('PCAP clássico inválido; PCAPNG não suportado')
    endian, scale = magics[raw[:4]]
    link = struct.unpack_from(endian + 'I', raw, 20)[0]
    if link not in (0, 1, 101, 108):
        raise ValueError(f'Link PCAP não suportado: {link}')
    flows, generations, diagnostics = {}, {}, []
    pos = 24
    while pos < len(raw):
        if pos + 16 > len(raw):
            raise ValueError('Cabeçalho de pacote PCAP truncado')
        sec, fraction, size, original = struct.unpack_from(endian + 'IIII', raw, pos)
        pos += 16
        if pos + size > len(raw):
            raise ValueError('Pacote PCAP truncado')
        packet = raw[pos:pos + size]; pos += size
        offset = 14 if link == 1 else 4 if link in (0, 108) else 0
        net = packet[offset:]
        if len(net) < 20 or net[0] >> 4 != 4 or net[9] != 6:
            continue
        ihl = (net[0] & 15) * 4
        total = int.from_bytes(net[2:4], 'big')
        if ihl < 20 or total > len(net) or total < ihl + 20 or int.from_bytes(net[6:8], 'big') & 0x3fff:
            diagnostics.append('Pacote IPv4 truncado/fragmentado ignorado'); continue
        tcp = net[ihl:total]
        sp, dp, seq = struct.unpack_from('!HHI', tcp)
        if not {sp, dp} & {12000, 12020}:
            continue
        hlen = (tcp[12] >> 4) * 4
        if hlen < 20 or hlen > len(tcp):
            diagnostics.append('Cabeçalho TCP inválido'); continue
        a, b = socket.inet_ntoa(net[12:16]), socket.inet_ntoa(net[16:20])
        pair = tuple(sorted(((a, sp), (b, dp))))
        if tcp[13] & 2 and not tcp[13] & 16:
            marker = generations.get(pair)
            if marker is None or marker[1] != seq:
                generations[pair] = ((marker[0] + 1) if marker else 1, seq)
        generation = generations.get(pair, (0, None))[0]
        key = (a, sp, b, dp, generation)
        if tcp[hlen:]:
            flows.setdefault(key, []).append((seq + bool(tcp[13] & 2), tcp[hlen:], sec * 10**9 + fraction * scale))
    records = []
    for key, segments in flows.items():
        a, sp, b, dp, generation = key
        port = dp if dp in (12000, 12020) else sp
        connection = repr((tuple(sorted(((a, sp), (b, dp)))), generation))
        buf, spans, end, broken = bytearray(), [], None, False
        for seq, data, timestamp in sorted(segments):
            if end is None: end = seq
            if seq > end:
                diagnostics.append(f'Lacuna TCP: {connection}'); broken = True; break
            overlap = end - seq
            if overlap:
                start = len(buf) - overlap
                if start < 0 or bytes(buf[start:start + min(overlap, len(data))]) != data[:overlap]:
                    diagnostics.append(f'Retransmissão conflitante: {connection}'); broken = True; break
                data = data[overlap:]
            if data:
                buf.extend(data); end += len(data); spans.append((len(buf), timestamp))
        if broken: continue
        cursor = 0
        while cursor < len(buf):
            if len(buf) - cursor < 6: diagnostics.append(f'Frame incompleto: {connection}'); break
            length = frame_len(buf[cursor:cursor+3])
            if length < 6 or cursor + length > len(buf): diagnostics.append(f'Frame inválido/truncado: {connection}'); break
            try: frame = decode(bytes(buf[cursor:cursor+length]))
            except (ValueError, IndexError, struct.error) as exc:
                diagnostics.append(f'Falha de decode: {type(exc).__name__}'); break
            timestamp = next(ts for stop, ts in spans if stop >= cursor + length)
            records.append({'connection_id': connection, 'port': port,
                            'direction': 'client_to_server' if dp == port else 'server_to_client',
                            'remote_endpoint': f'{b}:{dp}' if dp == port else f'{a}:{sp}',
                            'local_endpoint': f'{a}:{sp}' if dp == port else f'{b}:{dp}',
                            'pcap_time_ns': timestamp, 'opcode': f'0x{int.from_bytes(frame[4:6], "little"):04X}',
                            'decoded_hex': frame.hex()})
            cursor += length
    return sorted(records, key=lambda r: r['pcap_time_ns']), diagnostics


def _endpoint(row):
    if row.get('remote_endpoint'): return str(row['remote_endpoint'])
    flow = row.get('flow', '').split(' -> ')
    if len(flow) == 2: return flow[1] if _out(row) else flow[0]
    return ''


def _out(row):
    return row.get('direction') in ('client_to_server', transport.DIRECTION_C2S, 'c2s')


def _parse(row):
    frame = bytes.fromhex(row['decoded_hex'])
    opcode = int(str(row['opcode']), 16)
    if len(frame) < 6 or int.from_bytes(frame[4:6], 'little') != opcode:
        raise ValueError('Cabeçalho/opcode divergente')
    return auth.parse_message(int(row['port']), transport.DIRECTION_C2S if _out(row) else transport.DIRECTION_S2C, opcode, frame[6:])



def _capture_times(rows):
    times = []
    for row in rows:
        try:
            if row.get('pcap_time_ns') is not None:
                timestamp = datetime.fromtimestamp(int(row['pcap_time_ns']) / 1_000_000_000, timezone.utc)
            elif row.get('timestamp'):
                timestamp = datetime.fromisoformat(str(row['timestamp']).replace('Z', '+00:00'))
                if timestamp.tzinfo is None: continue
                timestamp = timestamp.astimezone(timezone.utc)
            else: continue
            times.append(timestamp)
        except (ValueError, TypeError, OverflowError, OSError): continue
    return {'started_at': min(times).isoformat() if times else None,
            'ended_at': max(times).isoformat() if times else None}


def inspect_capture(path):
    path = Path(path)
    if path.suffix.lower() in ('.pcap', '.cap'): records, diagnostics = _pcap(path)
    else:
        text = path.read_text(encoding='utf-8-sig')
        try: data = json.loads(text)
        except json.JSONDecodeError: data = [json.loads(line) for line in text.splitlines() if line.strip()]
        records = data.get('records', []) if isinstance(data, dict) else data
        if not isinstance(records, list): raise ValueError('records precisa ser uma lista')
        diagnostics = []
    groups = {}
    for row in records:
        if not isinstance(row, dict) or not row.get('decoded_hex'): continue
        row = dict(row)
        row['port'] = row.get('port', row.get('service_port', 0))
        if int(row['port']) not in (12000, 12020): continue
        if isinstance(row.get('opcode'), int): row['opcode'] = f"0x{row['opcode']:04X}"
        identity = row.get('connection_id')
        if not identity:
            flow = row.get('flow', '').split(' -> ')
            identity = repr(sorted(flow)) if len(flow) == 2 else None
        if not identity:
            diagnostics.append('Frame sem identidade de conexão ignorado'); continue
        groups.setdefault((str(identity), int(row.get('port', 0))), []).append(row)
    logins, games = [], []
    for (connection, port), rows in groups.items():
        target = '0x0101' if port == 12000 else '0x0103'
        starts = [i for i, r in enumerate(rows) if _out(r) and str(r.get('opcode')).lower() == target]
        for number, start in enumerate(starts):
            segment = rows[start:starts[number+1] if number+1 < len(starts) else len(rows)]
            # The short game preamble precedes authentication, but belongs to this connection.
            if port == 12020:
                previous = starts[number-1] + 1 if number else 0
                segment = rows[previous:start] + segment
            try: fields = _parse(rows[start])['fields']
            except (ValueError, KeyError, TypeError) as exc:
                diagnostics.append(f'Autenticação incompleta: {exc}'); continue
            item = {'connection': connection, 'records': segment, 'fields': fields}
            (logins if port == 12000 else games).append(item)
    candidates = []
    for login in logins:
        matches = [g for g in games if all(g['fields'].get(k) == login['fields'].get(k) and login['fields'].get(k) for k in ('account_id', 'session_key'))]
        for game in matches or [None]:
            rows = login['records'] + (game['records'] if game else [])
            worlds = set()
            for row in login['records']:
                if str(row.get('opcode')).lower() == '0x0107' and _out(row):
                    try: worlds.add(_parse(row)['fields']['world_id'])
                    except ValueError: pass
            responses=[]
            for row in login['records']:
                if str(row.get('opcode')).lower()=='0x0108' and not _out(row):
                    try: responses.append(_parse(row)['fields'])
                    except ValueError: pass
            successful={r['world_id'] for r in responses if r['result_code']==0}
            world_conflict=bool(successful and successful != worlds)
            issue = []
            if world_conflict: issue.append('World ID da resposta diverge do pedido; não preparar esta sessão')
            if responses and not successful: issue.append('Entrada de mundo não confirmada nesta captura')
            if len(matches) > 1: issue.append('Múltiplas conexões de jogo para mesma credencial; selecione a conexão correta')
            if not game: issue.append('Autenticação de jogo não observada')
            if len(worlds) != 1: issue.append('World ID ausente ou ambíguo; informar manualmente')
            ambiguous_auth = sum(all(other['fields'].get(k) == login['fields'].get(k) for k in ('account_id', 'session_key')) for other in logins) > 1
            if ambiguous_auth: issue.append('Credencial repetida em logins diferentes; recorte uma sessão antes de importar')
            timing = _capture_times(rows)
            candidates.append({**timing, 'world_conflict': world_conflict, 'ambiguous_auth': ambiguous_auth, 'candidate_id': str(len(candidates)+1), 'account_id': login['fields']['account_id'],
                               'auth_host': _endpoint(login['records'][0]).rsplit(':', 1)[0] or None,
                               'game_host': _endpoint(game['records'][-1]).rsplit(':', 1)[0] if game else None,
                               'world_id': next(iter(worlds)) if len(worlds) == 1 else None,
                               'records': rows, 'diagnostics': issue,
                               'provenance': {**timing, 'capture': str(path.resolve()), 'auth_connection': login['connection'],
                                              'game_connection': game['connection'] if game else None}})
    if not candidates: diagnostics.append('Nenhum login completo identificado nas conexões suportadas')
    return {'candidates': candidates, 'diagnostics': diagnostics}


def prepare_candidate(candidate, overrides=None):
    from .dashboard import snapshot
    if candidate.get('world_conflict'): raise ValueError('World ID divergente entre pedido e resposta')
    if candidate.get('ambiguous_auth'): raise ValueError('Associação login/jogo ambígua: credencial repetida')
    overrides = overrides or {}
    selected = {key: overrides.get(key, candidate.get(key)) for key in ('auth_host', 'game_host', 'world_id')}
    if any(not isinstance(selected[k], str) or not selected[k].strip() for k in ('auth_host', 'game_host')):
        raise ValueError('Login host e game host obrigatórios')
    if type(selected['world_id']) is not int or not 0 <= selected['world_id'] <= 65535:
        raise ValueError('World ID ausente/inválido; não existe valor padrão')
    session = {}
    rows = candidate['records']
    for port, opcode in ((12000, '0x0101'), (12020, '0x0103'), (12020, '0x0101')):
        matches = [r for r in rows if int(r['port']) == port and str(r['opcode']).lower() == opcode and _out(r)]
        if len(matches) != 1: raise ValueError(f'Autenticação {port}/{opcode} ausente ou ambígua')
        parsed = _parse(matches[0])
        session.update(parsed['fields'])
        session.update({v['name'] + '_hex': v['hex'] for v in parsed['unknown_fields']})
    session.pop('u64@2688', None)
    entries = [r for r in rows if int(r['port']) == 12020 and str(r['opcode']).lower() == '0x0201' and _out(r)]
    initialize = bool(overrides.get('initialize_character', bool(entries)))
    if initialize:
        if len(entries) != 1: raise ValueError('Template 0x0201 ausente ou ambíguo')
        session['character_enter_payload_hex'] = bytes.fromhex(entries[0]['decoded_hex'])[6:].hex()
        character.template(session)
    config = {'rankings': True, 'initialize_character': initialize,
              'heartbeat': {'enabled': False, 'constant': -371988797, 'flag': 0},
              'auth': {'host': selected['auth_host'], 'port': 12000, 'timeout': 10.0},
              'game': {'host': selected['game_host'], 'port': 12020, 'timeout': 10.0},
              'world_id': selected['world_id'], 'session_file': 'session.json',
              'market': {'list_requests': [{'payload_hex': '0000'}], 'detail_requests': [], 'trailing_u8': 0,
                         'both_markets': True, 'detail_all_items': True, 'products': dict(selection.PRODUCTS), 'response_timeout': 10.0}}
    supplied = {key: overrides[key] for key in ('auth_host', 'game_host', 'world_id', 'initialize_character') if key in overrides}
    sources = {'auth_host': '12000/TCP remote_endpoint', 'game_host': '12020/TCP remote_endpoint', 'world_id': '12000/client_to_server/0x0107 payload[0:2] u16le'}
    sources.update({key: 'manual_override' for key in supplied if key in sources})
    return {'config': config, 'session': session, 'provenance': dict(candidate['provenance'], overrides=supplied, resolved=selected, sources=sources),
            'dashboard': snapshot(rows)}
