"""Compra manual de uma oferta: layout documentado em purchase-latest-verify.md."""
import struct
from . import market

FIELDS = ("exchange_server_type", "exchange_index", "pc_id", "selling_price", "item_index", "enchant_level")


def build(request):
    if not isinstance(request, dict) or set(request) != set(FIELDS):
        raise ValueError("Informe exatamente mercado, oferta, vendedor, preço, item e refino")
    for key, bits in zip(FIELDS, (8, 64, 64, 64, 32, 16)):
        value = request[key]
        if type(value) is not int or not 0 <= value < 2**bits:
            raise ValueError(f"{key}: inteiro sem sinal de {bits} bits esperado")
    if request["exchange_server_type"] not in (0, 1):
        raise ValueError("Mercado deve ser 0 (local) ou 1 (global)")
    if any(request[key] == 0 for key in ("exchange_index", "pc_id", "item_index")):
        raise ValueError("IDs da oferta, vendedor e item devem ser positivos")
    return struct.pack("<BHQQQIH", request["exchange_server_type"], 1,
                       *(request[key] for key in FIELDS[1:]))


def parse(opcode, payload):
    if opcode == 0x0215:
        if payload:
            raise ValueError("0x0215 exige payload vazio")
        fields = {}
    elif opcode == 0x0216:
        if len(payload) != 3:
            raise ValueError("0x0216 exige 3 bytes")
        ret, verification = struct.unpack("<HB", payload)
        fields = {"ret": ret, "verification": verification}
    elif opcode == 0x1D12:
        if len(payload) != 33:
            raise ValueError("Compra manual exige uma oferta (33 bytes)")
        server, count, *values = struct.unpack("<BHQQQIH", payload)
        if count != 1:
            raise ValueError("Compra manual exige uma oferta")
        fields = dict(zip(FIELDS, (server, *values)))
    else:
        (ret, server, count), cursor = market._read(payload, 0, "<HBH", "purchase response")
        entries = []
        for _ in range(count):
            (entry_ret,), cursor = market._read(payload, cursor, "<H", "purchase result")
            offer, cursor = market._offer(payload, cursor)
            entries.append({"ret": entry_ret, "exchange_info": offer})
        market._end(opcode, payload, cursor)
        fields = {"ret": ret, "exchange_server_type": server, "purchase_results": entries}
    return {"status": "confirmed", "fields": fields, "unknown_fields": []}


def execute(link, request, wait, emit, stop_event, timeout):
    payload = build(request)
    if stop_event is not None and stop_event.is_set():
        return {"status": "cancelled", "request": dict(request), "diagnostic": "Cancelado antes do envio"}
    try:
        link.send(0x0215, b"")
        frame, _ = wait(link, 0x0216, timeout, "12020:0x0215", stop_event=stop_event)
        verification = parse(0x0216, frame["payload"])["fields"]
        emit({"record_type": "purchase_verification", **verification})
        if verification != {"ret": 0, "verification": 1}:
            raise ValueError(f"Verificação do dispositivo recusada: {verification}")
    except Exception as exc:
        result = {"status": "blocked", "stage": "purchase:verification", "request": dict(request),
                  "diagnostic": f"Compra não enviada: {exc}"}
        emit({"record_type": "purchase_result", **result})
        return result
    result = {"status": "unconfirmed", "stage": "purchase", "request": dict(request),
              "diagnostic": "Resultado da compra não confirmado; não reenviar automaticamente"}
    if stop_event is not None and stop_event.is_set():
        return dict(result, status="cancelled", diagnostic="Cancelado antes do envio")
    try:
        link.send(0x1D12, payload)
        emit({"record_type": "purchase", "status": "sent", "request": dict(request)})
        frame, _ = wait(link, 0x1D13, timeout, "12020:0x1D12", stop_event=stop_event)
        fields = parse(0x1D13, frame["payload"])["fields"]
        result["response"] = fields
        if fields["exchange_server_type"] != request["exchange_server_type"]:
            raise ValueError("Resposta pertence a outro mercado")
        if fields["ret"] != 0:
            result.update(status="rejected", diagnostic=f"Compra rejeitada: código {fields['ret']}")
        elif len(fields["purchase_results"]) == 1:
            entry = fields["purchase_results"][0]
            offer = entry["exchange_info"]
            if (offer["exchange_index"] != request["exchange_index"] or offer["pc_id"] != request["pc_id"]
                    or offer["selling_price"] != request["selling_price"]
                    or offer["item_info"]["index"] != request["item_index"]
                    or offer["item_info"]["enchant_level"] != request["enchant_level"]):
                raise ValueError("Resposta não corresponde à oferta solicitada")
            result.update(status="confirmed" if entry["ret"] == 0 else "rejected",
                          diagnostic="Compra confirmada pelo servidor" if entry["ret"] == 0 else
                          f"Oferta rejeitada: código {entry['ret']}")
    except Exception as exc:
        result["diagnostic"] += f"; {exc}"
    emit({"record_type": "purchase_result", **result})
    return result
