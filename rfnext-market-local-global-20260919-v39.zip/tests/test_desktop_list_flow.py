"""Controller integration without a window or external requests."""
import copy
import queue
import tempfile
import threading
import unittest
from collections import deque
from pathlib import Path
from unittest.mock import Mock, MagicMock, patch
from rfnext_market import desktop
from rfnext_market.purchase_list import PurchaseList
from tests.test_shopping import capture


class DesktopListFlowTest(unittest.TestCase):
    def test_product_click_expands_and_refinement_displays_offers(self):
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.product_tree=Mock();app.market_table=MagicMock()
        app.market_table.__getitem__.return_value=('produto','pc_id')
        app._product_nodes={'refine:6':[{'produto':'Rifle','pc_id':'6150242608290003288'}]}
        app.product_tree.selection.return_value=('product',)
        app._select_product()
        app.product_tree.item.assert_called_once_with('product',open=True)
        app.market_table.insert.assert_not_called()
        app.product_tree.selection.return_value=('refine:6',)
        app._select_product()
        app.market_table.insert.assert_called_once_with('', 'end', iid='0', values=('Rifle','6150242608290003288'))

    def app(self):
        folder=tempfile.TemporaryDirectory();self.addCleanup(folder.cleanup)
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.purchase_store=PurchaseList(Path(folder.name)/'list.json')
        app.market_result=capture();app.rankings_result=None;app.capture_ref='capture'
        app.shopping_snapshot=None;app.proposals=[];app.shopping_reservations={}
        app._closing=False;app.purchase_running=False;app.mode_threads={};app.mode_results={};app.worker=None
        app.execution_mode=Mock();app.execution_mode.get.return_value='Heartbeat ativo'
        app.heartbeat_service=Mock();app.heartbeat_service.ready.is_set.return_value=True
        app.heartbeat_service.ended.is_set.return_value=False;app.heartbeat_service.stop_event.is_set.return_value=False
        app.heartbeat_service.purchase.return_value={'status':'confirmed'}
        app._control_queue=queue.Queue();app.operation_events=deque()
        app._render_purchase_list=Mock();app._sync_proposal_results=Mock()
        app.list_execution_status=Mock();app.shopping_status=Mock();app._observe=Mock()
        app._current_config=Mock(return_value={});app._validate_config=Mock(return_value={})
        rows=desktop.presentation.market_rows(app.market_result,0)
        app.entries=[app.purchase_store.add(row['request'],row['quantity'],row['produto'],'capture') for row in rows]
        return app

    def drain(self,app):
        app.worker.join(2);self.assertFalse(app.worker.is_alive())
        while not app._control_queue.empty():app._handle_event(app._control_queue.get_nowait())

    def test_confirmed_list_uses_active_worker_only_and_cannot_repeat(self):
        app=self.app()
        with patch.object(desktop.messagebox,'askyesno',return_value=True), patch.object(desktop.session,'run') as run:
            app._execute_purchase_list();self.drain(app)
        self.assertEqual(app.heartbeat_service.purchase.call_count,2);run.assert_not_called()
        self.assertTrue(all(e['status']=='confirmed' for e in app.purchase_store.items()))
        self.assertFalse(app.purchase_running)
        with patch.object(desktop.messagebox,'showerror') as error:
            app._execute_purchase_list()
            error.assert_called_once()
        self.assertEqual(app.heartbeat_service.purchase.call_count,2)

    def test_new_connection_dispatch_and_stop_first_unconfirmed(self):
        app=self.app();app.heartbeat_service.worker=None
        app.execution_mode.get.return_value='Nova conexão'
        with patch.object(desktop.messagebox,'askyesno',return_value=True), patch.object(desktop.session,'run',return_value={'status':'unconfirmed'}) as run:
            app._execute_purchase_list();self.drain(app)
        self.assertEqual(run.call_count,1)
        cfg=run.call_args.args[0]
        self.assertTrue(cfg['initialize_character']);self.assertTrue(cfg['heartbeat']['enabled'])
        self.assertFalse(cfg['rankings']);app.heartbeat_service.purchase.assert_not_called()
        self.assertEqual([e['status'] for e in app.purchase_store.items()],['unconfirmed','prepared'])

    def test_cancel_confirmation_changed_capture_and_changed_offer_send_nothing(self):
        for mode in ('cancel','capture','offer'):
            app=self.app()
            def confirm(*args):
                if mode=='capture':app.capture_ref='new'
                return mode!='cancel'
            if mode=='offer':app.market_result['items'][0]['offers'][1]['selling_price']+=1
            with patch.object(desktop.messagebox,'askyesno',side_effect=confirm), patch.object(desktop.messagebox,'showinfo'), patch.object(desktop.messagebox,'showerror'):
                app._execute_purchase_list()
            self.assertIsNone(app.worker);app.heartbeat_service.purchase.assert_not_called()

    def test_site_balance_and_refresh_during_modal_are_checked(self):
        from tests.test_shopping import snapshot
        app=self.app()
        for entry in app.entries:app.purchase_store.remove(entry['entry_id'])
        row=desktop.presentation.market_rows(app.market_result,0)[0]
        app.purchase_store.add(row['request'],row['quantity'],'Rifle','capture',source='site',shopping_id='1')
        app.shopping_snapshot=snapshot(1)
        def confirm(*args):
            app.shopping_snapshot={'items':[]}
            return True
        with patch.object(desktop.messagebox,'askyesno',side_effect=confirm), patch.object(desktop.messagebox,'showerror'):
            app._execute_purchase_list()
        app.heartbeat_service.purchase.assert_not_called();self.assertIsNone(app.worker)
        app.shopping_snapshot=snapshot(1)
        app.shopping_snapshot['items'][0]['enchant_level']=7
        with patch.object(desktop.messagebox,'showerror'),patch.object(desktop.messagebox,'askyesno') as confirm:
            app._execute_purchase_list()
            confirm.assert_not_called()
        app.heartbeat_service.purchase.assert_not_called()

    def test_conflicting_and_expired_offers_block_whole_batch(self):
        for mode in ('conflict','expired'):
            app=self.app();offer=app.market_result['items'][0]['offers'][0]
            if mode=='conflict':app.market_result['items'][0]['offers'].append(dict(offer,selling_price=999))
            else:offer['expired_time']=1600000000
            with patch.object(desktop.messagebox,'showerror'),patch.object(desktop.messagebox,'askyesno') as confirm:
                app._execute_purchase_list()
                confirm.assert_not_called()
            app.heartbeat_service.purchase.assert_not_called()
