import unittest
from rfnext_market import presentation

UID = 6150242608290003288
OFFER = 6150242609210084203

def item(market=0, refine=6):
    return {'exchange_server_type': market, 'produto': 'Rifle', 'item_index': 1000078,
            'offers': [{'exchange_index': OFFER, 'pc_id': UID, 'account_id': 99, 'selling_price': 11,
                        'item_info': {'index': 1000078, 'count': 2, 'enchant_level': refine}}]}

def rank(name='Carlos', kind='exp', status='completed', uid=UID):
    return {'rankings': {kind: {'status': status, 'records': [{'rank': 1, 'character_uid': uid,
       'character_uid_repeat': uid, 'character_name': name, 'scope_id_raw': 1, 'ranking_cycle_raw': 2}]}}}

class MarketTreeTest(unittest.TestCase):
    def test_hierarchy_scope_empty_product_and_exact_request(self):
        result = {'items': [item(), item(0, 7), item(1),
                           {'exchange_server_type': 0, 'produto': 'Empty', 'item_index': 2, 'offers': []}]}
        tree = presentation.market_tree(result, 0)
        self.assertEqual(len(tree), 2)
        self.assertEqual([g['enchant_level'] for g in tree[0]['refinements']], [6, 7])
        self.assertEqual(tree[1]['refinements'], [])
        row = tree[0]['refinements'][0]['offers'][0]
        self.assertEqual(row['pc_id'], str(UID))
        self.assertEqual(row['exchange_index'], str(OFFER))
        self.assertEqual(row['quantity'], 2)
        self.assertEqual(row['request'], dict(exchange_server_type=0, exchange_index=OFFER, pc_id=UID,
                         selling_price=11, item_index=1000078, enchant_level=6))
        self.assertEqual(presentation.market_tree(result, 1)[0]['refinements'][0]['offers'][0]['request']['exchange_server_type'], 1)
        self.assertEqual(row['key'], presentation.market_rows(result)[0]['key'])

    def test_separate_rank_refresh_conflicts_and_incomplete(self):
        result = {'items': [item()]}
        self.assertEqual(presentation.market_rows(result)[0]['seller'], 'Vendedor não informado')
        separate = rank()
        self.assertEqual(presentation.market_rows(result, rankings_result=separate)[0]['seller'], 'Carlos')
        separate['rankings'].update(rank('Outro', 'cora')['rankings'])
        row = presentation.market_rows(result, rankings_result=separate)[0]
        self.assertEqual(row['seller'], 'Vendedor não informado')
        self.assertIn('conflitantes', row['seller_source'])
        for snapshot in (rank(status='incomplete'), rank(uid=UID+1), rank(uid=99)):
            self.assertEqual(presentation.market_rows(result, rankings_result=snapshot)[0]['seller'], 'Vendedor não informado')
        malformed = rank()
        malformed['rankings']['exp']['records'][0]['character_uid_repeat'] = UID+1
        self.assertEqual(presentation.market_rows(result, rankings_result=malformed)[0]['seller'], 'Vendedor não informado')

    def test_invalid_offer_is_visible_but_never_executable(self):
        for key, value in [('pc_id', str(UID)), ('pc_id', float(UID)), ('selling_price', -1), ('exchange_index', True)]:
            product = item()
            product['offers'][0][key] = value
            row = presentation.market_rows({'items': [product]})[0]
            self.assertIsNone(row['request'])
        for key, value in [('index', 2), ('count', '2'), ('enchant_level', None)]:
            product = item()
            product['offers'][0]['item_info'][key] = value
            self.assertIsNone(presentation.market_rows({'items': [product]})[0]['request'])
        product = item()
        product['offers'][0]['item_info'] = None
        self.assertIsNone(presentation.market_rows({'items': [product]})[0]['request'])

    def test_exp_filter_preserves_default(self):
        result = rank()
        result['rankings'].update(rank('Outro', 'cora')['rankings'])
        self.assertEqual(len(presentation.ranking_rows(result)), 2)
        self.assertEqual([r[0] for r in presentation.ranking_rows(result, exp_only=True)], ['exp'])

if __name__ == '__main__':
    unittest.main()
