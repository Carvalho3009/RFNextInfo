import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from rfnext_market import upload


class UploadHttpErrorsTest(unittest.TestCase):
    def test_error_body_is_preserved_for_json_text_and_empty_responses(self):
        response_body = [b'{"error":"invalid_payload","message":"Campo obrigatorio ausente"}']

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args):
                pass

            def do_POST(self):
                self.rfile.read(int(self.headers.get("Content-Length", "0")))
                self.send_response(422)
                self.send_header("Content-Length", str(len(response_body[0])))
                self.end_headers()
                self.wfile.write(response_body[0])

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            options = {"base_url": f"http://127.0.0.1:{server.server_port}", "timeout": 2}
            for body, expected in (
                (response_body[0], "Campo obrigatorio ausente"),
                (b"invalid request", "invalid request"),
                (b"", "resposta sem detalhes"),
            ):
                response_body[0] = body
                with self.subTest(body=body), self.assertRaises(ValueError) as caught:
                    upload._post(options, "/local", b"{}")
                self.assertIn("HTTP 422", str(caught.exception))
                self.assertIn(expected, str(caught.exception))
                self.assertIn("envio permanece pendente", str(caught.exception))
        finally:
            server.shutdown()
            server.server_close()
            thread.join(2)
