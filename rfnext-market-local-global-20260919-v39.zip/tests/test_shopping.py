import copy
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

from rfnext_market import shopping, upload


def snapshot(quantity=2):
    return {"schema": shopping.SCHEMA, "server_time": "2026-09-23T00:00:00Z", "items": [
        {"shopping_id":"1", "item_index":1000078,"name":"Rifle","enchant_level":6,
         "remaining_quantity":quantity,"reference_unit_price":11,"updated_at":None}]}


def capture():
    def offer(uid, price=11, count=1):
        return {"exchange_index":uid,"pc_id":6150242608290003288,"selling_price":price,
                "item_info":{"index":1000078,"count":count,"enchant_level":6}}
    return {"items":[{"produto":"Rifle","item_index":1000078,"exchange_server_type":0,
                      "offers":[offer(6150242609210084203),offer(6150242609210084204,20,3)]},
                     {"produto":"Rifle","item_index":1000078,"exchange_server_type":1,
                      "offers":[offer(6150242609210084205,1)]}]}


class ShoppingTest(unittest.TestCase):
    def test_prepare_exact_ids_whole_lots_one_market_no_network(self):
        original=snapshot(); result=capture(); saved=copy.deepcopy(result)
        with patch.object(upload,"_post") as network:
            plan=shopping.prepare(original,result,"capture-1",market=0)
        network.assert_not_called()
        self.assertEqual(len(plan["proposals"]),1)
        proposal=plan["proposals"][0]
        self.assertEqual(proposal["request"]["exchange_index"],6150242609210084203)
        self.assertEqual(proposal["capture_ref"],"capture-1")
        self.assertEqual(plan["unresolved"][0]["remaining_quantity"],1)
        self.assertEqual(result,saved)
        self.assertEqual(original,snapshot())
        global_plan=shopping.prepare(original,result,"capture-1",market=1)
        self.assertEqual(global_plan["proposals"][0]["request"]["exchange_server_type"],1)

    def test_duplicate_offer_not_allocated_twice_conflicts_blocked(self):
        data=snapshot(); data["items"].append(dict(data["items"][0],shopping_id="2"))
        result=capture(); result["items"][0]["offers"].append(result["items"][0]["offers"][0])
        self.assertEqual(len(shopping.prepare(data,result,"capture-1")["proposals"]),1)
        result["items"][0]["offers"].append(dict(result["items"][0]["offers"][0],selling_price=999))
        self.assertEqual(shopping.prepare(data,result,"capture-1")["proposals"],[])

    def test_reject_bad_list_and_ignore_expired_inexact_ids(self):
        for key,value in (("remaining_quantity",True),("item_index",1.5),("shopping_id",1),
                          ("reference_unit_price",-1),("enchant_level",65536)):
            bad=snapshot();bad["items"][0][key]=value
            with self.assertRaises(ValueError): shopping.validate(bad)
        result=capture(); result["items"][0]["offers"][0]["expired_time"]=1600000000
        self.assertEqual(shopping.prepare(snapshot(),result,"capture-1")["proposals"],[])
        result=capture();result["items"][0]["offers"][0]["exchange_index"]=1.5
        self.assertEqual(shopping.prepare(snapshot(),result,"capture-1")["proposals"],[])

    def test_fetch_reuses_identity_signs_path_and_rejects_other_installation(self):
        import base64, hashlib
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        with tempfile.TemporaryDirectory() as folder, patch(
                'rfnext_market.protected_state.protect_for_current_user',side_effect=lambda b:b), patch(
                'rfnext_market.protected_state.unprotect',side_effect=lambda b:b):
            options={"base_url":"https://apirf.karvalho.dev.br","state_dir":folder,"timeout":10}
            with upload._database(options) as db:
                registration,_=upload._identity(db,options)
            def post(opts,path,body,headers,**kwargs):
                self.assertEqual(path,shopping.PATH)
                digest=hashlib.sha256(body).hexdigest()
                self.assertEqual(headers["X-RFQOL-Body-SHA256"],digest)
                signed='\n'.join(('POST',path,headers['Idempotency-Key'],headers['X-RFQOL-Timestamp'],headers['X-RFQOL-Nonce'],digest)).encode()
                decode=lambda s:base64.urlsafe_b64decode(s+'='*(-len(s)%4))
                Ed25519PublicKey.from_public_bytes(decode(registration['public_key'])).verify(
                    decode(headers['X-RFQOL-Signature']),b'RFQOL-INGEST-V1\0'+signed)
                return dict(snapshot(),installation_id=registration['installation_id'])
            with patch.object(upload,'_post',side_effect=post):
                self.assertEqual(shopping.fetch(options)['installation_id'],registration['installation_id'])
            with patch.object(upload,'_post',return_value=dict(snapshot(),installation_id='other')):
                with self.assertRaises(ValueError):shopping.fetch(options)
