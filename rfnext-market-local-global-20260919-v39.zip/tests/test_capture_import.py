import json
import struct
import tempfile
import unittest
from pathlib import Path
from rfnext_market import auth, capture_import as ci, transport


def fields(port, opcode, account='a', key='key'):
    output = {}
    for name, kind in auth.LAYOUTS[(port, transport.DIRECTION_C2S, opcode)][2]:
        if isinstance(kind, tuple): output[name + '_hex'] = (b'\0' * (kind[1] or 1)).hex()
        elif kind == 'str': output[name] = {'account_id':account, 'session_key':key}.get(name, 'x')
        else: output[name] = 0
    return output


def row(port, opcode, values, conn):
    payload = auth.build_payload(port, opcode, values)
    frame = b'\0' + (len(payload)+6).to_bytes(2,'little') + b'\0' + opcode.to_bytes(2,'little') + payload
    return {'port':port, 'opcode':f'0x{opcode:04X}', 'direction':'client_to_server',
            'connection_id':conn, 'remote_endpoint':f'10.1.1.{1 if port==12000 else 2}:{port}', 'decoded_hex':frame.hex()}


def session(account='a', key='key', suffix=''):
    return [row(12000,0x0101,fields(12000,0x0101,account,key),'a'+suffix),
            row(12000,0x0107,{'world_id':12},'a'+suffix),
            row(12020,0x0101,fields(12020,0x0101),'g'+suffix),
            row(12020,0x0103,fields(12020,0x0103,account,key),'g'+suffix)]


class CaptureImportTests(unittest.TestCase):
    def inspect(self, rows):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'dump.json'; path.write_text(json.dumps({'records':rows}))
            return ci.inspect_capture(path)

    def test_isolated_accounts_and_actual_world(self):
        found=self.inspect(session()+session('b','second','2'))['candidates']
        self.assertEqual(len(found),2)
        prepared=ci.prepare_candidate(found[1])
        self.assertEqual(prepared['session']['account_id'],'b')
        self.assertEqual(prepared['config']['world_id'],12)
        self.assertEqual(prepared['config']['auth']['host'],'10.1.1.1')
        self.assertNotIn('u64@2688',prepared['session'])

    def test_missing_world_no_default_and_missing_game_blocked(self):
        found=self.inspect([r for r in session() if r['opcode']!='0x0107'])['candidates'][0]
        with self.assertRaisesRegex(ValueError,'World ID'): ci.prepare_candidate(found)
        self.assertEqual(ci.prepare_candidate(found,{'world_id':9})['config']['world_id'],9)
        found=self.inspect(session()[:2])['candidates'][0]
        with self.assertRaises(ValueError): ci.prepare_candidate(found,{'game_host':'example'})

    def test_same_credential_repeated_login_rejected(self):
        found=self.inspect(session()+session(suffix='2'))['candidates']
        with self.assertRaisesRegex(ValueError,'credencial repetida'): ci.prepare_candidate(found[0])

    def test_live_dump_shape(self):
        rows=session()
        for r in rows: r['service_port']=r.pop('port'); r['opcode']=int(r['opcode'],16)
        self.assertEqual(ci.prepare_candidate(self.inspect(rows)['candidates'][0])['config']['world_id'],12)

    def test_invalid_pcap(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'x.pcap'; path.write_bytes(b'garbage')
            with self.assertRaisesRegex(ValueError,'PCAP'): ci.inspect_capture(path)

    def test_pcap_reassembly_and_gap(self):
        def packet(seq,data):
            ip=bytearray(20); ip[0]=0x45; ip[9]=6; ip[2:4]=(40+len(data)).to_bytes(2,'big'); ip[12:16]=bytes([192,168,1,2]); ip[16:20]=bytes([10,1,1,1])
            tcp=bytearray(20); struct.pack_into('!HHI',tcp,0,5555,12000,seq); tcp[12]=0x50
            pkt=bytes(ip+tcp)+data
            return struct.pack('<IIII',1,2,len(pkt),len(pkt))+pkt
        header=struct.pack('<IHHIIII',0xa1b2c3d4,2,4,0,0,65535,101)
        frame=bytes.fromhex(session()[0]['decoded_hex'])
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'x.pcap'
            path.write_bytes(header+packet(100,frame[:20])+packet(120,frame[20:]))
            rows,diag=ci._pcap(path); self.assertEqual(len(rows),1); self.assertEqual(diag,[])
            path.write_bytes(header+packet(100,frame[:20])+packet(121,frame[20:]))
            rows,diag=ci._pcap(path); self.assertEqual(rows,[]); self.assertIn('Lacuna',diag[0])

    def test_world_response_conflict_blocks_preparation(self):
        rows=session()
        payload=struct.pack('<HHHQH',0,13,0,0,0)+struct.pack('<H',1)+'x'.encode('utf-16le')+struct.pack('<H',12020)
        frame=b'\0'+(6+len(payload)).to_bytes(2,'little')+b'\0'+(0x0108).to_bytes(2,'little')+payload
        response=dict(rows[0],opcode='0x0108',direction='server_to_client',decoded_hex=frame.hex())
        rows.insert(2,response)
        candidate=self.inspect(rows)['candidates'][0]
        with self.assertRaisesRegex(ValueError,'divergente'): ci.prepare_candidate(candidate)

    def test_times_and_manual_provenance(self):
        rows=session()
        rows[0]['pcap_time_ns']=1_000_000_000
        rows[-1]['timestamp']='1970-01-01T00:00:03+00:00'
        candidate=self.inspect(rows)['candidates'][0]
        self.assertEqual(candidate['started_at'],'1970-01-01T00:00:01+00:00')
        self.assertEqual(candidate['ended_at'],'1970-01-01T00:00:03+00:00')
        automatic=ci.prepare_candidate(candidate)['provenance']
        self.assertEqual(automatic['overrides'],{})
        self.assertIn('0x0107',automatic['sources']['world_id'])
        manual=ci.prepare_candidate(candidate,{'world_id':99})['provenance']
        self.assertEqual(manual['overrides'],{'world_id':99})
        self.assertEqual(manual['resolved']['world_id'],99)
        self.assertEqual(manual['sources']['world_id'],'manual_override')
        self.assertEqual(manual['started_at'],candidate['started_at'])

if __name__=='__main__': unittest.main()
