import struct
import unittest
from rfnext_market import rankings
from tests import test_session as ts


def exp(count=300):
    return struct.pack("<H", count) + b"".join(
        struct.pack("<QQIIIIQ", n, n * 100, n, n, 1, 2, n) + ts.s16("Player")
        + struct.pack("<QI", 0, 0) + ts.s16("Guild") + bytes(4)
        for n in range(1, count + 1))


def faction(fid):
    def row(n):
        return (struct.pack("<Q", n) + ts.s16("Player") + struct.pack("<IQ", 1, 0)
                + ts.s16("") + struct.pack("<IId", 0, n, float(n)))
    return bytes([fid, 0]) + row(1) + struct.pack("<H", 100) + b"".join(row(n) for n in range(1, 101))


class RankingsTest(unittest.TestCase):
    run_session = ts.SessionTest.run_session
    sent_ops = ts.SessionTest.sent_ops

    def test_collection_and_correlation(self):
        cfg = ts.config(); cfg["rankings"] = True
        script = ts.game_script({0x1A03: [[(0x1A04, struct.pack("<IIIIQ", 1, 1, 1, 2, 0))]], 0x1A01: [[(0x1A02, exp())]],
            0x240A: [[(0x240B, faction(3)), (0x240B, faction(1))],
                     [(0x240B, faction(2))], [(0x240B, faction(3))]]})
        result = self.run_session(game_s=script, cfg=cfg)
        self.assertEqual(result["status"], "completed")
        self.assertEqual(list(result["rankings"]), ["exp", "accretia", "bellato", "cora"])
        self.assertTrue(all(v["status"] == "completed" for v in result["rankings"].values()))
        self.assertEqual(self.sent_ops(12020)[-6:], [0x1A03, 0x1A01, 0x2408, 0x240A, 0x240A, 0x240A])
        self.assertEqual([f["payload"].hex() for f in self.conns[12020].sent[-3:]], ["0101", "0201", "0301"])
        self.assertEqual(self.conns[12020].sent[-5]["payload"].hex(), "000000002c010000")
        self.assertEqual(len(result["rankings"]["exp"]["records"]), 300)

    def test_exp_timeout_preserves_market_and_continues_factions(self):
        cfg = ts.config(); cfg["rankings"] = True
        result = self.run_session(cfg=cfg, game_s=ts.game_script({0x240A: [[(0x240B, faction(n))] for n in (1, 2, 3)]}))
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["rankings"]["exp"]["status"], "failed")
        self.assertEqual(self.sent_ops(12020).count(0x240A), 3)
        self.assertEqual(result["rankings"]["cora"]["status"], "completed")
        self.assertTrue(result["market"]["queries"])

    def test_strict_decode_and_partial_results(self):
        for opcode, raw in ((0x1A02, exp()), (0x240B, faction(1))):
            rankings.parse_message(opcode, raw)
            for bad in (raw[:-1], raw + b"x"):
                with self.assertRaises(ValueError): rankings.parse_message(opcode, bad)
        fields = rankings.parse_message(0x1A02, exp(2))["fields"]
        self.assertFalse(rankings.validate(fields, "exp"))
        fields["records"][1]["rank"] = 1
        with self.assertRaises(ValueError): rankings.validate(fields, "exp")

    def test_ranking_mode_initializes_character_before_all_requests(self):
        from rfnext_market import complete
        cfg = complete.mode_config(ts.config(), "rankings")
        creds = cfg["credentials"]
        creds["character_enter_payload_hex"] = (ts.s16(creds["account_id"]) +
            struct.pack("<QQ14sQ", 99, 123, bytes(14), 88) + ts.s16(creds["auth_jwt"])).hex()
        script = ts.game_script({
            0x0201: [[(0x0202, struct.pack("<HQ", 0, 123))]],
            0x1A01: [[(0x1A02, exp())]],
            0x240A: [[(0x240B, faction(n))] for n in (1, 2, 3)]})
        answer = self.run_session(cfg=cfg, game_s=script)
        self.assertEqual(answer["status"], "completed", answer["diagnostic"])
        ops = self.sent_ops(12020)
        self.assertLess(ops.index(0x0201), ops.index(0x1A01))
        self.assertFalse(any(op >> 8 == 0x1D for op in ops))
        self.assertEqual(len(answer["rankings"]), 4)
        script[0x0201] = [[(0x0202, struct.pack("<HQ", 1, 123))]]
        answer = self.run_session(cfg=cfg, game_s=script)
        self.assertEqual(answer["status"], "failed")
        self.assertNotIn(0x1A01, self.sent_ops(12020))

    def test_no_ranking_responses_is_failed_and_partial_is_incomplete(self):
        for has_exp in (False, True):
            with self.subTest(has_exp=has_exp):
                cfg = ts.config(); cfg.update(rankings=True, rankings_only=True)
                script = ts.game_script({0x1A01: [[(0x1A02, exp())]]} if has_exp else {})
                answer = self.run_session(cfg=cfg, game_s=script)
                expected = "incomplete" if has_exp else "failed"
                self.assertEqual(answer["status"], expected)
                self.assertEqual(len(answer["errors"]), 3 if has_exp else 4)
                self.assertEqual(self.records[-1]["status"], expected)
