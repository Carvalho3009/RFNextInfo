import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from rfnext_market.accounts import AccountRegistry, AccountStore


class AccountsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.store = AccountStore(self.base)

    def test_hundreds_isolated_profiles(self):
        profiles = [self.store.create(f"Conta {i}", {"companion": {}}, {"id": i}) for i in range(210)]
        self.assertEqual(len(self.store.list()), 210)
        states = set()
        for profile in profiles:
            config = json.loads(Path(profile["config_file"]).read_text())
            self.assertEqual(config["session_file"], profile["session_file"])
            states.add(config["companion"]["state_dir"])
        self.assertEqual(len(states), 210)
        self.store.update(profiles[0]["id"], name="Renomeada", session={"id": "new"})
        self.assertEqual(self.store.load(profiles[0]["id"])["name"], "Renomeada")
        self.assertEqual(json.loads(Path(profiles[1]["session_file"]).read_text()), {"id": 1})

    def test_legacy_idempotent_preserves_original_and_companion(self):
        documents = {"config.json": {"session_file": "old-session.json", "companion": {"state_dir": "identity"}},
                     "old-session.json": {"secret": "kept"}, "purchase-list.json": [{"status": "confirmed"}]}
        for name, value in documents.items():
            (self.base / name).write_text(json.dumps(value))
        profile = self.store.migrate_legacy()
        self.assertEqual(profile, AccountStore(self.base).migrate_legacy())
        self.assertEqual(len(self.store.list()), 1)
        config = json.loads(Path(profile["config_file"]).read_text())
        self.assertEqual(config["companion"]["state_dir"], str(self.base / "identity"))
        self.assertEqual(json.loads((Path(profile["path"]) / "purchase-list.json").read_text()), documents["purchase-list.json"])
        for name, value in documents.items():
            self.assertEqual(json.loads((self.base / name).read_text()), value)

    def test_legacy_list_without_config_and_invalid_documents(self):
        self.assertIsNone(self.store.migrate_legacy())
        (self.base / "purchase-list.json").write_text('[{"status":"confirmed"}]')
        profile = self.store.migrate_legacy()
        self.assertTrue((Path(profile["path"]) / "purchase-list.json").exists())
        self.assertEqual(self.store.migrate_legacy(), profile)
        with self.assertRaises(ValueError):
            self.store.create("Invalid", config=[])
        self.assertEqual(len(self.store.list()), 1)

    def test_invalid_and_failed_update_preserve_valid_data(self):
        profile = self.store.create("One")
        original = Path(profile["config_file"]).read_bytes()
        with self.assertRaises(ValueError):
            self.store.update(profile["id"], config={"companion": []})
        with self.assertRaises(ValueError):
            self.store.load("../escape")
        with patch("rfnext_market.accounts.os.replace", side_effect=OSError("disk")):
            with self.assertRaises(OSError):
                self.store.update(profile["id"], config={"world_id": 3})
        self.assertEqual(Path(profile["config_file"]).read_bytes(), original)
        self.assertEqual(list(Path(profile["path"]).glob("*.tmp")), [])

    def test_pair_commit_failure_keeps_old_generation_and_identity(self):
        from rfnext_market import accounts
        profile = self.store.create("One", {"world_id": 1}, {"account_id": "abc", "token": "old"})
        write = accounts._write
        for fail_at in (1, 2, 3):
            calls = []
            def failing(path, value):
                calls.append(path)
                if len(calls) == fail_at:
                    raise OSError("simulated failure")
                return write(path, value)
            with patch.object(accounts, "_write", side_effect=failing):
                with self.assertRaises(OSError):
                    self.store.update(profile["id"], config={"world_id": 2}, session={"account_id": "abc", "token": "new"})
            self.assertEqual(self.store.load(profile["id"]), profile)
            self.assertEqual(json.loads(Path(profile["session_file"]).read_text())["token"], "old")
        with self.assertRaises(ValueError):
            self.store.update(profile["id"], session={"account_id": "other"})
        with self.assertRaises(ValueError):
            self.store.update(profile["id"], config={"credentials": {"account_id": "other"}})
        latest = self.store.update(profile["id"], config={"world_id": 2}, session={"account_id": "ABC", "token": "new"})
        self.assertNotEqual(latest["session_file"], profile["session_file"])
        self.assertEqual(json.loads(Path(latest["config_file"]).read_text())["world_id"], 2)
        self.assertEqual(json.loads(Path(latest["session_file"]).read_text())["token"], "new")

    def test_missing_legacy_config_reuses_existing_companion_directory(self):
        (self.base / "companion-state").mkdir()
        (self.base / "purchase-list.json").write_text("[]")
        profile = self.store.migrate_legacy()
        config = json.loads(Path(profile["config_file"]).read_text())
        self.assertEqual(config["companion"]["state_dir"], str(self.base / "companion-state"))

    def test_identity_registry_blocks_duplicates_and_releases_only_owner(self):
        registry = AccountRegistry()
        self.assertTrue(registry.acquire("ABC", "one"))
        self.assertTrue(registry.acquire("abc", "one"))
        self.assertFalse(registry.acquire("abc", "two"))
        registry.release("two")
        self.assertEqual(registry.owner("abc"), "one")
        registry.release("one")
        self.assertTrue(registry.acquire("abc", "two"))
        with self.assertRaises(ValueError):
            registry.acquire(None, "one")

    def test_legacy_site_attempt_claimed_before_other_profile(self):
        import sqlite3
        from contextlib import closing
        install = "8e2d5ab1-2adc-449e-87e0-4511fd2aab2f"
        state = self.base / "companion-state"
        state.mkdir()
        with closing(sqlite3.connect(state / "market-upload.sqlite3")) as db, db:
            db.execute("CREATE TABLE identity (id INTEGER PRIMARY KEY, secret BLOB)")
            db.execute("INSERT INTO identity VALUES (1, ?)", (b"protected",))
        (self.base / "purchase-list.json").write_text('[{"source":"site","status":"unconfirmed","shopping_id":"321"}]')
        with patch("rfnext_market.protected_state.unprotect", return_value=json.dumps({"installation_id": install}).encode()):
            first = self.store.migrate_legacy()
            self.assertEqual(first, self.store.migrate_legacy())
        other = self.store.create("Other")
        self.assertFalse(self.store.claim_site_executor(other["id"], state))
        self.assertFalse(self.store.claim_site_executor(other["id"], self.base / "alias", install))
        self.assertTrue(self.store.claim_site_executor(first["id"], state, install))
        self.assertFalse(self.store.claim_site_executor(other["id"], self.base / "other", shopping_ids=["321"]))

    def test_shopping_identity_blocks_across_installations_after_restart(self):
        first, second = self.store.create("One"), self.store.create("Two")
        installation1 = "8e2d5ab1-2adc-449e-87e0-4511fd2aab2f"
        installation2 = "8e2d5ab1-2adc-449e-87e0-4511fd2aab20"
        self.assertTrue(self.store.claim_site_executor(first["id"], self.base / "one", installation1, ["123"]))
        restarted = AccountStore(self.base)
        self.assertFalse(restarted.claim_site_executor(second["id"], self.base / "two", installation2, ["00123"]))
        self.assertTrue(restarted.claim_site_executor(second["id"], self.base / "two", installation2, ["124"]))
        for invalid in ("0", "-1", "a", 123, "１２３"):
            with self.assertRaises(ValueError):
                restarted.claim_site_executor(first["id"], self.base / "one", shopping_ids=[invalid])

    def test_site_executor_sticky_and_installation_aliases(self):
        first, second = self.store.create("One"), self.store.create("Two")
        install = "8e2d5ab1-2adc-449e-87e0-4511fd2aab2f"
        self.assertTrue(self.store.claim_site_executor(first["id"], self.base / "shared", install))
        restarted = AccountStore(self.base)
        self.assertFalse(restarted.claim_site_executor(second["id"], self.base / "shared"))
        self.assertFalse(restarted.claim_site_executor(second["id"], self.base / "alias", install))
        self.assertTrue(restarted.claim_site_executor(first["id"], self.base / "alias", install))
        self.assertTrue(restarted.claim_site_executor(second["id"], self.base / "independent"))


if __name__ == "__main__":
    unittest.main()
