import struct
import unittest
from rfnext_market import dashboard


def record(op, payload, timestamp=1):
    return {'service_port':12020,'direction':'server_to_client','timestamp':timestamp,
            'decoded_hex':(b'\0'*4+op.to_bytes(2,'little')+payload).hex()}


def player(uid, name, diamonds=3):
    encoded=name.encode('utf-16le'); tail=bytearray(46); struct.pack_into('<H',tail,0,55);struct.pack_into('<Q',tail,38,diamonds)
    return record(0x0305,struct.pack('<QH',uid,len(encoded)//2)+encoded+tail)


class DashboardTests(unittest.TestCase):
    def test_own_identity_not_nearby_player(self):
        state=dashboard.snapshot([record(0x0202,struct.pack('<HQ',0,42)),player(99,'Other'),player(42,'Own',0)])
        self.assertEqual(state['character_name']['value'],'Own')
        self.assertEqual(state['diamonds']['value'],0)
        self.assertEqual(state['diamonds']['status'],'observed')
        self.assertIsNone(state['daily_missions']['value'])
        self.assertEqual(state['diamonds']['source'],'12020/0x0305')

    def test_unknown_uid_and_truncation(self):
        state=dashboard.snapshot([player(42,'Unknown'),record(0x0202,b'x')])
        self.assertIsNone(state['character_name']['value'])
        self.assertIsNone(state['diamonds']['value'])

    def test_changed_character_clears_previous_values(self):
        state=dashboard.snapshot([record(0x0202,struct.pack('<HQ',0,42)),player(42,'Own')])
        dashboard.consume(state,record(0x0202,struct.pack('<HQ',0,43),2))
        self.assertIsNone(state['diamonds']['value'])
        self.assertEqual(state['character_uid']['value'],'43')

    def test_failed_initialization_does_not_establish_identity(self):
        state=dashboard.snapshot([record(0x0202,struct.pack('<HQ',1,42)),player(42,'Own')])
        self.assertIsNone(state['character_uid']['value'])

    def test_currencies_partial_daily_and_absolute_update(self):
        name='Own'.encode('utf-16le'); tail=bytearray(1057)
        for kind,value in ((19,100),(20,200),(11,3),(58,40),(55,10),(56,20),(57,30)):
            struct.pack_into('<q',tail,22+(kind-1)*8,value)
        frame=record(0x0305,struct.pack('<QH',42,3)+name+tail)
        state=dashboard.snapshot([record(0x0202,struct.pack('<HQ',0,42)),frame])
        self.assertEqual(state['android_junkyard']['value']['remaining_seconds'],300)
        self.assertIsNone(state['daily_missions']['value']['completed'])
        self.assertEqual(state['daily_missions']['value']['instant_completed'],3)
        dashboard.consume(state,record(0x0407,struct.pack('<HIq',0,20,40),2))
        self.assertEqual(state['android_junkyard']['value']['remaining_seconds'],140)
        self.assertIsNone(state['public_mining_field']['value']['remaining_seconds'])

    def test_biosuit_rover_location_and_scoped_cp(self):
        state=dashboard.snapshot([record(0x0202,struct.pack('<HQ',0,42))])
        dashboard.consume(state,record(0x1304,struct.pack('<HIQB',0,2075041,0,0)))
        self.assertEqual(state['class']['value'],'Arbiter')
        dashboard.consume(state,record(0x1403,struct.pack('<HIB',0,4400011,0)))
        self.assertEqual(state['rover']['value'],4400011)
        teleport=bytearray(43);struct.pack_into('<I',teleport,22,101)
        dashboard.consume(state,record(0x0325,teleport))
        self.assertEqual(state['location']['value']['map_index'],101)
        cp=bytearray(786);struct.pack_into('<Q',cp,772,123456)
        event=record(0x0401,cp);event['service_port']=12010
        dashboard.consume(state,event);self.assertIsNone(state['cp']['value'])
        event['account_scoped']=True;dashboard.consume(state,event)
        self.assertEqual(state['cp']['value'],123456)

    def test_display_durations_and_unknowns(self):
        text=dashboard.display_value('public_mining_field',{'default_seconds':3661,'charged_by_faction':{'accretia':None,'cora':0}})
        self.assertIn('01:01:01',text);self.assertIn('Accretia: Não observado',text);self.assertIn('Cora: 00:00:00',text)
        self.assertNotIn('None',text);self.assertNotIn('{',text)
        self.assertIn('instantâneas: Não observado',dashboard.display_value('daily_missions',{'limit':10}))
        self.assertEqual(dashboard.display_value('location',{'map_index':5,'position':[1,2,3]}),'Mapa 5 · X 1.0, Y 2.0, Z 3.0')

if __name__=='__main__': unittest.main()
