"""Two real worker threads, fake transport, no Tk window or game connection."""
import copy
import json
import queue
import struct
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from rfnext_market.account_ui import AccountWindow
from rfnext_market.accounts import AccountStore, AccountRegistry
from rfnext_market.desktop import DesktopApp
from rfnext_market import desktop, dashboard


class MultiAccountTests(unittest.TestCase):
    def setUp(self):
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        self.host = AccountWindow.__new__(AccountWindow)
        self.host.store = AccountStore(self.folder.name)
        self.host.registry = AccountRegistry()
        self.host.apps = {}

    def app(self, account):
        profile = self.host.store.create(account, session={"account_id": account})
        app = DesktopApp.__new__(DesktopApp)
        app.manager = self.host; app.profile_id = profile["id"]; app.profile = profile
        app.profile_label = account; app.data_dir = Path(profile["path"])
        app._closing = False; app._finished = True; app.closed = False; app.purchase_running = False
        app.worker = None; app.mode_threads = {}; app.mode_stops = {}; app.mode_results = {}
        app.heartbeat_service = SimpleNamespace(worker=None, stop=Mock())
        app.mode_intervals = {mode: Mock(get=lambda: "5") for mode in ("market", "rankings", "complete")}
        app.mode_continuous = {mode: Mock(get=lambda: False) for mode in app.mode_intervals}
        app.mode_buttons = {mode: Mock() for mode in app.mode_intervals}
        app.mode_status = {mode: Mock() for mode in app.mode_intervals}
        app._current_config = lambda: {"credentials": {"account_id": account}, "world_id": 3}
        app._validate_config = copy.deepcopy
        app._reset_progress = Mock()
        app._queue = queue.Queue(); app._control_queue = queue.SimpleQueue(); app._dropped_records = 0
        self.host.apps[app.profile_id] = app
        return app

    def test_two_running_accounts_selection_and_stop_are_isolated(self):
        a, b = self.app("A"), self.app("B")
        entered = {name: threading.Event() for name in ("A", "B")}
        owners = {}
        def run(config, emit, stop, *args, **kwargs):
            account = config["credentials"]["account_id"]
            owners[account] = kwargs["heartbeat"]
            entered[account].set()
            stop.wait(3)
            emit({"record_type": "completion", "status": "cancelled", "account": account})
            return {"status": "cancelled"}
        with patch.object(desktop.complete, "run", side_effect=run):
            a._start_mode("market"); b._start_mode("rankings")
            try:
                self.assertTrue(entered["A"].wait(1)); self.assertTrue(entered["B"].wait(1))
                self.host.selected = b.profile_id
                a._stop_mode("market")
                a.mode_threads["market"].join(1)
                self.assertTrue(b.mode_threads["rankings"].is_alive())
                self.assertFalse(b.mode_stops["rankings"].is_set())
                event = a._control_queue.get()
                self.assertEqual(event[1]["profile_id"], a.profile_id)
                self.assertEqual(event[1]["account"], "A")
                self.assertIs(owners["A"], a.heartbeat_service)
                self.assertIs(owners["B"], b.heartbeat_service)
            finally:
                for app in (a, b):
                    for stop in app.mode_stops.values(): stop.set()
                    for worker in app.mode_threads.values(): worker.join(2)

    def test_duplicate_identity_and_mutated_live_config_are_rejected(self):
        a, b = self.app("A"), self.app("A")
        self.host.authorize(a, a._current_config())
        a.worker = Mock(is_alive=lambda: True)
        with self.assertRaisesRegex(ValueError, "outro perfil"):
            self.host.authorize(b, b._current_config())
        changed = a._current_config(); changed["world_id"] = 4
        with self.assertRaisesRegex(ValueError, "alterados"):
            self.host.authorize(a, changed)
        a.worker = None
        changed["credentials"]["account_id"] = "B"
        with self.assertRaisesRegex(ValueError, "outra conta"):
            self.host.authorize(a, changed)

    def test_purchase_files_and_dashboard_never_follow_selected_profile(self):
        a, b = self.app("A"), self.app("B")
        request = dict(exchange_server_type=0, exchange_index=5, pc_id=9, selling_price=11, item_index=1002, enchant_level=0)
        a._purchase_store().add(request, 1, "Item", "capture-A")
        self.assertEqual(b._purchase_store().items(), [])
        self.host.selected = b.profile_id
        self.host.render_dashboard = Mock()
        payload = struct.pack("<HQ", 0, 123)
        frame = bytes([0]) + (6 + len(payload)).to_bytes(2, "little") + bytes([0]) + bytes.fromhex("0202") + payload
        self.host.observe(a, ("record", {"record_type": "frame", "direction": "server_to_client", "service_port": 12020, "decoded_hex": frame.hex()}))
        self.assertEqual(a.dashboard_snapshot["character_uid"]["value"], "123")
        self.assertFalse(hasattr(b, "dashboard_snapshot"))
        self.host.render_dashboard.assert_called_once_with(a)

    def test_profile_close_does_not_destroy_shared_tk(self):
        a = self.app("A")
        a.root = Mock(); a._closing = True
        a._drain_queue()
        self.assertTrue(a.closed)
        a.root.destroy.assert_not_called()

    def test_pending_events_block_session_changes_and_shutdown_blocks_new_work(self):
        app = self.app("A")
        app._queue.put(("record", {"record_type": "frame"}))
        self.assertTrue(app.is_busy())
        with patch.object(desktop.messagebox, "showinfo"):
            self.assertFalse(app._allow_config_change())
        app._closing = True
        app._fetch_shopping()
        app._retry_upload()
        self.assertIsNone(app.worker)
        self.assertFalse(hasattr(app, "shopping_worker"))

    def test_state_paths_stay_on_latest_generation(self):
        app = self.app("A")
        session = self.host.store.load(app.profile_id)["session_file"]
        app.config_path = Mock(); app.session_path = Mock(); app._load_values = Mock()
        self.host.save_config(app, {"session_file": session, "world_id": 4})
        profile = self.host.store.load(app.profile_id)
        self.assertEqual(app.config_path.set.call_args.args[0], profile["config_file"])
        self.assertEqual(app.session_path.set.call_args.args[0], profile["session_file"])
        self.assertEqual(app.config_document["world_id"], 4)

    def test_failed_dashboard_save_can_close_or_wait_for_explicit_retry(self):
        for discard in (False, True):
            app = self.app("save-test")
            app.closed = True; app.dashboard_dirty = True; app.dashboard_snapshot = dashboard.empty()
            app.status = Mock()
            self.host.apps = {app.profile_id: app}
            self.host.root = Mock(); self.host.closing = True; self.host.import_worker = None
            self.host.import_queue = queue.SimpleQueue(); self.host.update_context = Mock()
            with patch.object(Path, "write_text", side_effect=OSError("disk unavailable")), patch.object(desktop.messagebox, "askyesno", return_value=discard) as confirm:
                self.host.tick()
                self.assertEqual(confirm.call_count, 1)
                if discard:
                    self.host.root.destroy.assert_called_once()
                else:
                    self.host.tick()
                    self.assertEqual(confirm.call_count, 1)
                    self.host.root.destroy.assert_not_called()
                    self.host.close()
                    self.assertFalse(app.dashboard_save_blocked)


if __name__ == "__main__":
    unittest.main()
