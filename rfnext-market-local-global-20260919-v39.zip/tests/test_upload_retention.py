import json
import tempfile
import unittest
from pathlib import Path

from rfnext_market import upload


class UploadRetentionTest(unittest.TestCase):
    def test_cleanup_preserves_pending_rejected_identity_counts_and_sequence(self):
        with tempfile.TemporaryDirectory() as folder:
            options = {"state_dir": folder}
            with upload._database(options) as db:
                with db:
                    db.execute("INSERT INTO identity VALUES(1,'origin',?)", (b'identity',))
                    for ref, queued in (("sent",1),("pending",1),("rejected",1),("unqueued",0)):
                        db.execute("INSERT INTO results VALUES(?,?,?, ?,NULL)", (ref,"now",b'x'*2000000,queued))
                    for seq, state, ref in ((1,"pending","pending"),(2,"rejected","rejected"),(3,"accepted","sent")):
                        body=json.dumps({"events":[{"session_ref":ref}]}).encode()
                        db.execute("INSERT INTO batches VALUES(?,?,?,?,?)",(seq,str(seq),body,state,b'{}'))
                size_before=Path(folder,"market-upload.sqlite3").stat().st_size
                original=db.execute("SELECT body FROM batches WHERE state!='accepted' ORDER BY sequence").fetchall()
            with upload._database(options) as db:
                self.assertEqual([r[0] for r in db.execute("SELECT result_ref FROM results ORDER BY result_ref")],["pending","rejected","unqueued"])
                self.assertEqual(original,db.execute("SELECT body FROM batches ORDER BY sequence").fetchall())
                self.assertEqual(tuple(db.execute("SELECT accepted,last_sequence FROM upload_totals").fetchone()),(1,3))
                self.assertEqual(db.execute("SELECT secret FROM identity").fetchone()[0],b'identity')
                self.assertLess(Path(folder,"market-upload.sqlite3").stat().st_size,size_before)
            with upload._database(options) as db:
                self.assertEqual(tuple(db.execute("SELECT accepted,last_sequence FROM upload_totals").fetchone()),(1,3))
