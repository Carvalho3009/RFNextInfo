import threading
import time
import unittest
from unittest.mock import patch, Mock
from rfnext_market import complete, desktop


class CompleteTest(unittest.TestCase):
    def test_three_real_confirmations_before_rank_and_heartbeat_survives(self):
        sent_two, release_third = threading.Event(), threading.Event()
        order, records = [], []
        def runner(config, emit, stop_event, on_collected=None):
            if config['heartbeat_only']:
                for _ in range(2): emit({'record_type':'heartbeat','status':'confirmed'})
                on_collected({})
                sent_two.set()
                release_third.wait(2)
                emit({'record_type':'heartbeat','status':'confirmed'})
                stop_event.wait(3)
                return {}
            order.append('rankings' if config['rankings_only'] else 'market')
            return {'status':'completed','rankings':{}}
        hb=complete.HeartbeatWorker(runner)
        stop=threading.Event()
        def submit(*a,**k): order.append('upload'); return {'status':'accepted'}
        worker=threading.Thread(target=lambda: complete.run({'market':{}}, records.append,stop,
            runner=runner,submit=submit,heartbeat=hb))
        worker.start()
        try:
            self.assertTrue(sent_two.wait(2))
            self.assertEqual(order,[])
            self.assertFalse(hb.ready.is_set())
            release_third.set(); worker.join(2)
            self.assertFalse(worker.is_alive())
            self.assertEqual(order,['rankings','market','upload'])
            self.assertTrue(hb.worker.is_alive())
            self.assertFalse(hb.stop_event.is_set())
        finally:
            release_third.set(); stop.set(); hb.stop(); worker.join(3); hb.worker.join(3)

    def test_modes_repeat_after_upload_and_errors_without_cross_trigger(self):
        for mode in ('market','rankings','complete'):
            with self.subTest(mode=mode):
                stop=threading.Event(); order=[]; waits=[]
                hb=Mock(); hb.wait_ready.return_value=True
                def runner(config,emit,stop_event):
                    step='rankings' if config['rankings_only'] else 'market'
                    order.append(step)
                    self.assertFalse(config['heartbeat']['enabled'])
                    self.assertEqual(config['initialize_character'], step == 'rankings')
                    if mode=='market':
                        self.assertTrue(config['market']['both_markets']); self.assertFalse(config['rankings'])
                    if step=='rankings': self.assertFalse(config['market']['both_markets']); self.assertEqual(config['market']['list_requests'],[])
                    if len(order)==1: raise RuntimeError('transient')
                    return {'status':'completed','rankings':{}}
                def submit(*args,**kwargs): order.append('upload'); stop.set(); return {'status':'accepted'}
                def wait(interval, event, emit, operation): waits.append(list(order))
                with patch.object(complete,'wait_interval',side_effect=wait):
                    complete.run({'market':{},'rankings':True,'heartbeat_only':True},lambda r:None,stop,
                        True,1,runner,submit,mode,hb)
                self.assertEqual(len(waits),1)
                self.assertEqual(order[-1],'upload')
                if mode=='market': self.assertNotIn('rankings',order); hb.start.assert_not_called(); hb.wait_ready.assert_not_called()
                if mode=='rankings': self.assertNotIn('market',order); hb.start.assert_not_called()
                hb.stop.assert_not_called()

    def test_timer_starts_after_upload_and_can_cancel(self):
        stop=threading.Event(); records=[]; uploaded=threading.Event()
        def submit(*a,**k): uploaded.set(); return {'status':'accepted'}
        def emit(r):
            if r.get('record_type')=='countdown':
                self.assertTrue(uploaded.is_set()); records.append(r); stop.set()
        complete.run({'market':{}},emit,stop,True,5,lambda *a,**k:{'status':'completed'},submit,mode='market')
        self.assertEqual(records[0]['remaining_seconds'],5)

    def test_complete_retries_failed_heartbeat_without_disabling_continuous(self):
        stop=threading.Event(); hb=Mock(); hb.wait_ready.side_effect=[RuntimeError('lost'),True]
        def submit(*a,**k): stop.set(); return {}
        with patch.object(complete,'wait_interval'):
            complete.run({'market':{}},lambda r:None,stop,True,1,
                         lambda *a,**k:{'rankings':{}},submit,heartbeat=hb)
        self.assertEqual(hb.start.call_count,2)

    def test_ui_buttons_dispatch_separately_and_stops_do_not_touch_heartbeat(self):
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app._start_mode=Mock()
        app._start(); app._start_rankings(); app._start_complete()
        self.assertEqual([c.args[0] for c in app._start_mode.call_args_list],['market','rankings','complete'])
        app.mode_stops={m:threading.Event() for m in ('market','rankings','complete')}
        app.mode_status={m:Mock() for m in (*app.mode_stops,'heartbeat')}
        app.heartbeat_service=Mock()
        app._stop_mode('market')
        self.assertTrue(app.mode_stops['market'].is_set()); self.assertFalse(app.mode_stops['rankings'].is_set())
        app.heartbeat_service.stop.assert_not_called()

    def test_market_and_rank_workers_run_independently(self):
        started={m:threading.Event() for m in ('market','rankings')}
        stops={m:threading.Event() for m in started}
        hb=Mock(); hb.wait_ready.return_value=True
        def runner(config,emit,stop_event):
            mode='rankings' if config['rankings_only'] else 'market'
            started[mode].set(); stop_event.wait(2); return {}
        workers=[threading.Thread(target=complete.run,args=({'market':{}},lambda r:None,stops[m]),
                    kwargs={'runner':runner,'submit':lambda *a,**k:{},'mode':m,'heartbeat':hb}) for m in started]
        for w in workers:w.start()
        try:
            self.assertTrue(all(e.wait(1) for e in started.values()))
            stops['market'].set(); workers[0].join(1)
            self.assertTrue(workers[1].is_alive())
        finally:
            for e in stops.values():e.set()
            for w in workers:w.join(2)

    def test_ranking_mode_never_sends_market_even_with_both_markets(self):
        from tests import test_session as ts
        case=ts.SessionTest(); config=ts.config(); config.update(rankings_only=True,rankings=True)
        config['market'].update(both_markets=True,detail_all_items=True)
        case.run_session(cfg=config)
        ops=case.sent_ops(12020)
        self.assertFalse(any(op>>8==0x1D for op in ops)); self.assertIn(0x1A01,ops)

    def test_actual_ui_wires_three_independent_controls(self):
        from rfnext_market import desktop_shell
        from tests.test_desktop_shell import Variable
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.root=Mock(); app.vars={name:Mock() for name in ("auth_host","auth_port","auth_timeout","game_host","game_port","game_timeout","world_id","response_timeout")}
        for name in ("config_path","session_path","item_database","companion_enabled","companion_url","companion_state_dir"):
            setattr(app,name,Mock())
        app.mode_continuous={m:Mock() for m in ("market","rankings","complete")}
        app.mode_intervals={m:Mock() for m in app.mode_continuous}
        app.mode_status={m:Mock() for m in (*app.mode_continuous,"heartbeat")}
        app._file_row=Mock(); app._log_pane=Mock(return_value=(Mock(),Mock()))
        app._table=Mock(return_value=Mock())
        app.root.winfo_children.return_value=[]
        with patch.object(desktop_shell,'ttk') as widgets, patch.object(desktop_shell.tk,'StringVar',Variable), patch.object(
                desktop_shell.tk,'Canvas'), patch.object(desktop_shell.font,'families',return_value=('Arial Rounded MT Bold',)), patch.object(desktop_shell.font,'Font'):
            app._build()
        buttons={c.kwargs.get('text'):c.kwargs.get('command') for c in widgets.Button.call_args_list}
        self.assertEqual(buttons['Consultar mercado'],app._start)
        self.assertEqual(buttons['Consultar ranking'],app._start_rankings)
        self.assertEqual(buttons['Consulta completa'],app._start_complete)
        self.assertEqual(buttons['Iniciar heartbeat'],app._start_heartbeat)
        toggles=[c.kwargs['variable'] for c in widgets.Checkbutton.call_args_list if c.kwargs.get('text')=='Contínua']
        self.assertEqual(toggles,list(app.mode_continuous.values()))
        entries=[c.kwargs.get('textvariable') for c in widgets.Entry.call_args_list]
        for variable in app.mode_intervals.values():self.assertIn(variable,entries)

    def test_complete_does_not_hide_failed_rankings_behind_market_success(self):
        stop=threading.Event(); hb=Mock(); hb.wait_ready.return_value=True
        def runner(config,emit,stop_event):
            if config["rankings_only"]:
                self.assertTrue(config["initialize_character"])
                return {"status":"failed", "rankings":{}}
            return {"status":"completed", "offers":[{"pc_id":42}]}
        answer=complete.run({"market":{}},lambda r:None,stop,runner=runner,
                            submit=lambda *a,**k:{"status":"accepted"},heartbeat=hb)
        self.assertEqual(answer["status"],"incomplete")
        self.assertIn("exp",answer["diagnostic"])
        self.assertEqual(answer["upload"]["status"],"accepted")

    def test_worker_end_state_is_retained_for_export(self):
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.mode_status={"heartbeat":Mock()}
        record={"record_type":"operation_state","operation":"heartbeat",
                "status":"failed","message":"connection closed by test server"}
        app._handle_event(("mode_state",record))
        self.assertEqual(app.operation_events[-1]["message"],record["message"])
        self.assertIn("timestamp",app.operation_events[-1])
