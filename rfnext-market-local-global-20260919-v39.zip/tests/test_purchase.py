import struct
import threading
import unittest
from unittest.mock import Mock, patch, call

from rfnext_market import purchase, session, desktop
from tests import test_session as helper

REQUEST = dict(exchange_server_type=0, exchange_index=0x555A0D11550A9143,
               pc_id=0x555A0D114A4D048D, selling_price=231, item_index=1002, enchant_level=0)
PAYLOAD = "00010043910a55110d5a558d044d4a110d5a55e700000000000000ea0300000000"


def response(ret=0, uid=None):
    offer = struct.pack("<QQQ", REQUEST["exchange_index"], 0, uid or REQUEST["pc_id"])
    offer += struct.pack("<QIQBHHHBQ", 1, 1002, 1, 0, 0, 0, 0, 0, 0)
    offer += struct.pack("<QQQQQB", 0, 0, 0, 231, 0, 0)
    return struct.pack("<HBHH", 0, 0, 1, ret) + offer


class PurchaseTest(unittest.TestCase):
    def test_capture_bytes_and_validation(self):
        self.assertEqual(purchase.build(REQUEST).hex(), PAYLOAD)
        self.assertEqual(purchase.parse(0x1D12,bytes.fromhex(PAYLOAD))["fields"],REQUEST)
        for key in purchase.FIELDS:
            for bad in (-1, True, 2**64):
                with self.subTest(key=key,bad=bad), self.assertRaises(ValueError):
                    purchase.build(dict(REQUEST, **{key:bad}))

    def test_confirm_reject_mismatch_and_timeout_send_once(self):
        for answer, expected in ((response(),"confirmed"),(response(7),"rejected"),
                                 (response(uid=123),"unconfirmed"),(b"bad","unconfirmed"),
                                 (TimeoutError("timeout"),"unconfirmed")):
            link, wait = Mock(), Mock()
            wait.side_effect=[({"payload":bytes.fromhex("000001")},None),
                              answer if isinstance(answer, Exception) else ({"payload":answer},None)]
            result=purchase.execute(link,REQUEST,wait,Mock(),threading.Event(),1)
            self.assertEqual(result["status"],expected)
            self.assertEqual(link.send.call_args_list,[call(0x0215,b""),call(0x1D12,bytes.fromhex(PAYLOAD))])
        stop=threading.Event();stop.set();link=Mock()
        self.assertEqual(purchase.execute(link,REQUEST,Mock(),Mock(),stop,1)["status"],"cancelled")
        link.send.assert_not_called()

    def test_authenticated_session_purchase_does_not_query_market_or_rank(self):
        runner=helper.SessionTest()
        cfg=helper.config();cfg["manual_purchase"]=REQUEST
        result=runner.run_session(cfg=cfg,game_s=helper.game_script({0x0215:[[(0x0216,bytes.fromhex("000001"))]],0x1D12:[[(0x1D13,response())]]}))
        self.assertEqual(result["status"],"confirmed",result)
        self.assertEqual(runner.sent_ops(12020),[0x0101,0x0103,0x0105,0x0215,0x1D12])
        self.assertTrue(all(c.closed for c in runner.conns.values()))

    def test_failed_verification_never_sends_purchase(self):
        for answer in (b"\x01\x00\x01", b"\x00\x00\x00", b"\x00\x00\x02", b"bad!", TimeoutError()):
            link, wait = Mock(), Mock()
            wait.side_effect = [answer if isinstance(answer, Exception) else ({"payload":answer}, None)]
            result = purchase.execute(link, REQUEST, wait, Mock(), threading.Event(), 1)
            self.assertEqual(result["status"], "blocked")
            link.send.assert_called_once_with(0x0215, b"")

    def test_heartbeat_queue_uses_existing_socket_and_resumes(self):
        import queue
        from concurrent.futures import Future
        cfg = helper.config()
        cfg.update(heartbeat_only=True, initialize_character=True, heartbeat={"enabled":True})
        creds = cfg["credentials"]
        creds["character_enter_payload_hex"] = (helper.s16(creds["account_id"]) +
            struct.pack("<QQ14sQ",99,123,bytes(14),88) + helper.s16(creds["auth_jwt"])).hex()
        cfg["_purchase_commands"] = queue.Queue()
        future = Future()
        clock, conns, records = helper.Clock(), {}, []
        clock.time = clock.monotonic
        stop = Mock(wraps=threading.Event())
        stop.wait = Mock(return_value=False)
        script = helper.game_script({
            0x0201:[[(0x0202,struct.pack("<HQ",0,123))]],
            0x0205:[[(0x0206,bytes(8))]]*12,
            0x0215:[["timeout"]*4+[(0x0216,b"\x00\x00\x01")]],
            0x1D12:[["timeout"]*4+[(0x1D13,response())]]})
        def factory(host, port, timeout, **kw):
            self.assertNotIn(port,conns)
            conns[port] = helper.FakeConn(port,helper.auth_script() if port==12000 else script,clock,[])
            return conns[port]
        def observe(record):
            records.append(record)
            if future.done() and record.get("record_type")=="heartbeat":
                stop.set()
        def ready(result):
            cfg["_purchase_commands"].put((REQUEST,future,threading.Event()))
        with patch.object(session,"Connection",factory), patch.object(session,"time",clock):
            session.run(cfg,observe,stop,on_collected=ready)
        self.assertEqual(future.result()["status"],"confirmed")
        ops=[f["opcode"] for f in conns[12020].sent]
        self.assertEqual(ops[:4],[0x0101,0x0103,0x0105,0x0201])
        self.assertEqual(ops.count(0x1D12),1)
        self.assertEqual(ops.count(0x0215),1)
        self.assertEqual(ops.count(0x0103),1)
        self.assertIn(0x0205,ops[ops.index(0x0215)+1:ops.index(0x1D12)])
        self.assertGreaterEqual(ops[ops.index(0x1D12)+1:].count(0x0205),2)
        self.assertFalse(set(ops)&{0x1D01,0x1D03,0x1A01,0x240A})

    def test_heartbeat_button_does_not_authenticate_or_upload(self):
        import queue
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app._closing=False;app.mode_threads={};app.worker=None
        service=Mock();service.ready.is_set.return_value=True
        service.ended.is_set.return_value=False;service.stop_event.is_set.return_value=False
        service.purchase.return_value={"status":"confirmed"}
        app.heartbeat_service=service;app.root=Mock();app.purchase_button=Mock();app.status=Mock()
        app._validate_config=Mock();app._control_queue=queue.Queue()
        with patch.object(desktop,"PurchaseDialog",return_value=Mock(result=REQUEST)), patch.object(
                desktop.messagebox,"askyesno",return_value=True), patch.object(session,"run") as run, patch.object(
                desktop.upload,"submit_result") as upload:
            app._start_purchase(True);app.worker.join(2)
            service.purchase.assert_called_once_with(REQUEST,app.stop_event)
            run.assert_not_called();upload.assert_not_called();app._validate_config.assert_not_called()

    def test_worker_rejects_inactive_and_resolves_cancelled_queue(self):
        from rfnext_market.complete import HeartbeatWorker
        worker=HeartbeatWorker()
        with self.assertRaises(RuntimeError):
            worker.purchase(REQUEST,threading.Event())
        worker.ready.set()
        cancel=threading.Event();cancel.set()
        self.assertEqual(worker.purchase(REQUEST,cancel)["status"],"cancelled")
        link=Mock()
        session._pending_purchase(link,{"_purchase_commands":worker.purchase_commands},Mock(),threading.Event())
        link.send.assert_not_called()

    def test_worker_shutdown_resolves_waiting_purchase(self):
        from concurrent.futures import Future
        from rfnext_market.complete import HeartbeatWorker
        def runner(cfg, emit, **kw):
            for _ in range(3):
                emit({"record_type":"heartbeat","status":"confirmed"})
            cfg["_purchase_commands"].put((REQUEST,future,threading.Event()))
            return {"diagnostic":"closed"}
        future=Future()
        worker=HeartbeatWorker(runner)
        worker.start(helper.config(),Mock());worker.worker.join(2)
        self.assertTrue(worker.ended.is_set())
        self.assertFalse(worker.ready.is_set())
        with self.assertRaises(RuntimeError):
            future.result(timeout=1)

    def test_cancelled_confirmation_does_not_start_session(self):
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app._closing=False;app.mode_threads={};app.worker=None;app.heartbeat_service=None
        app.root=Mock();app._validate_config=Mock(return_value={});app._current_config=Mock(return_value={})
        with patch.object(desktop,"PurchaseDialog",return_value=Mock(result=REQUEST)), patch.object(
                desktop.messagebox,"askyesno",return_value=False), patch.object(session,"run") as run:
            app._start_purchase()
            run.assert_not_called()

    def test_confirmed_button_uses_purchase_worker_without_upload(self):
        import queue
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app._closing=False;app.mode_threads={};app.worker=None;app.heartbeat_service=None
        app.root=Mock();app._validate_config=Mock(return_value={});app._current_config=Mock(return_value={})
        app._control_queue=queue.Queue();app._observe=Mock();app.purchase_button=Mock();app.status=Mock()
        app.mode_results={}
        with patch.object(desktop,"PurchaseDialog",return_value=Mock(result=REQUEST)), patch.object(
                desktop.messagebox,"askyesno",return_value=True), patch.object(session,"run",
                return_value={"status":"unconfirmed","diagnostic":"timeout"}) as run, patch.object(
                desktop.upload,"submit_result") as upload:
            app._start_purchase();app.worker.join(2)
            self.assertFalse(app.worker.is_alive())
            cfg=run.call_args.args[0]
            self.assertEqual(cfg["manual_purchase"],REQUEST)
            self.assertTrue(cfg["initialize_character"])
            self.assertTrue(cfg["heartbeat"]["enabled"])
            upload.assert_not_called()
            app._handle_event(app._control_queue.get_nowait())
            self.assertFalse(app.purchase_running)
            self.assertEqual(app.mode_results["purchase"]["status"],"unconfirmed")
