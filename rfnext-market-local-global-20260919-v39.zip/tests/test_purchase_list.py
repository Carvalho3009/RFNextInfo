import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from rfnext_market.purchase_list import PurchaseList

REQUEST = dict(exchange_server_type=0, exchange_index=6150242609210084203,
               pc_id=6150242608290003288, selling_price=11, item_index=1000078, enchant_level=6)


class PurchaseListTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'list.json'
        self.list = PurchaseList(self.path)
        self.cancel = threading.Event()
        self.emit = Mock()

    def add(self, offset=0, **kw):
        return self.list.add(dict(REQUEST, exchange_index=REQUEST['exchange_index'] + offset),
                             2, 'Rifle', 'capture1', **kw)

    def test_duplicate_snapshot_refresh_and_exact_ids(self):
        entry = self.add()
        repeat = self.list.add(REQUEST, 2, 'Rifle atualizado', 'capture2')
        self.assertEqual(entry['entry_id'], repeat['entry_id'])
        self.assertEqual(repeat['capture_ref'], 'capture2')
        entry['request']['pc_id'] = 1
        self.assertEqual(PurchaseList(self.path).items()[0]['request'], REQUEST)
        with self.assertRaises(ValueError):
            self.list.add(dict(REQUEST, selling_price=12), 2, 'Rifle', 'capture2')
        self.assertEqual(len(self.list.items()), 1)

    def test_success_one_execution_per_offer_and_durable_history(self):
        a = self.add(source='site', shopping_id='42')
        b = self.add(1)
        execute = Mock(return_value={'status':'confirmed', 'diagnostic':'ok', 'credentials':'not saved'})
        result = self.list.run([a['entry_id'], b['entry_id']], execute, self.cancel, self.emit)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(execute.call_count, 2)
        self.assertEqual(self.emit.call_args.kwargs, {})
        self.assertEqual(self.emit.call_args.args[0]['completed'], 2)
        loaded = PurchaseList(self.path)
        self.assertEqual(loaded.reserved_quantities(), {'42':2})
        self.assertNotIn('credentials', self.path.read_text())
        self.assertEqual(loaded.add(REQUEST, 2, 'Rifle', 'new', 'site', '42')['status'], 'confirmed')
        with self.assertRaises(ValueError):
            loaded.run([a['entry_id']], execute, self.cancel, self.emit)
        with self.assertRaises(ValueError):
            loaded.remove(a['entry_id'])
        self.assertEqual(execute.call_count, 2)

    def test_stop_on_failure_and_reserve_ambiguous_only(self):
        for status in ('rejected', 'blocked', 'cancelled', 'unconfirmed', 'invalid'):
            with self.subTest(status=status):
                queue = PurchaseList(Path(self.temp.name) / (status + '.json'))
                a = queue.add(REQUEST, 2, 'x', 'c', 'site', '42')
                b = queue.add(dict(REQUEST, exchange_index=1), 1, 'y', 'c')
                execute = Mock(return_value={'status':status, 'diagnostic':'Cancelado antes do envio' if status == 'cancelled' else ''})
                result = queue.run([a['entry_id'], b['entry_id']], execute, self.cancel, self.emit)
                self.assertEqual(execute.call_count, 1)
                self.assertEqual(queue.items()[1]['status'], 'prepared')
                self.assertEqual(result['status'], 'unconfirmed' if status == 'invalid' else status)
                self.assertEqual(queue.reserved_quantities(), {'42':2} if status in ('unconfirmed','invalid') else {})

    def test_callback_cancellation_only_releases_known_pre_send(self):
        for number, diagnostic in enumerate(("Cancelado antes do envio", "Compra cancelada antes do envio",
                                             "Cancelado", "", "socket fechado após enviar")):
            queue = PurchaseList(Path(self.temp.name) / f"cancel{number}.json")
            entry = queue.add(REQUEST, 2, "x", "c", "site", "42")
            execute = Mock(return_value={"status":"cancelled", "diagnostic":diagnostic})
            result = queue.run([entry["entry_id"]], execute, self.cancel, self.emit)
            expected = "cancelled" if number < 2 else "unconfirmed"
            self.assertEqual(result["status"], expected)
            loaded = PurchaseList(queue.path)
            self.assertEqual(loaded.items()[0]["status"], expected)
            self.assertEqual(loaded.reserved_quantities(), {} if number < 2 else {"42":2})
            execute.assert_called_once()
            with self.assertRaises(ValueError):
                loaded.run([entry["entry_id"]], execute, self.cancel, self.emit)
            execute.assert_called_once()

    def test_cancel_preflight_and_cancel_between_entries(self):
        a, b = self.add(), self.add(1)
        execute = Mock(return_value={'status':'confirmed'})
        with self.assertRaises(ValueError):
            self.list.run([a['entry_id'], 'missing'], execute, self.cancel, self.emit)
        execute.assert_not_called()
        self.cancel.set()
        self.assertEqual(self.list.run([a['entry_id']], execute, self.cancel, self.emit)['status'], 'cancelled')
        execute.assert_not_called()
        self.assertEqual(self.list.items()[0]['status'], 'prepared')
        self.cancel.clear()
        def first(request, cancel):
            cancel.set()
            return {'status':'confirmed'}
        result = self.list.run([a['entry_id'], b['entry_id']], first, self.cancel, self.emit)
        self.assertEqual(result['status'], 'cancelled')
        self.assertEqual(self.list.items()[1]['status'], 'prepared')

    def test_interruption_before_return_is_durable_unconfirmed(self):
        a = self.add(source='site', shopping_id='42')
        def crash(request, cancel):
            self.assertEqual(json.loads(self.path.read_text())[0]['status'], 'sending')
            raise KeyboardInterrupt()
        with self.assertRaises(KeyboardInterrupt):
            self.list.run([a['entry_id']], crash, self.cancel, self.emit)
        loaded = PurchaseList(self.path)
        self.assertEqual(loaded.items()[0]['status'], 'unconfirmed')
        self.assertEqual(loaded.reserved_quantities(), {'42':2})
        self.assertEqual(json.loads(self.path.read_text())[0]['status'], 'unconfirmed')

    def test_socket_exception_is_ambiguous_and_mutations_blocked(self):
        a = self.add()
        def execute(request, cancel):
            for operation in (lambda: self.add(1), lambda: self.list.remove(a['entry_id']),
                              lambda: self.list.run([a['entry_id']], Mock(), cancel, self.emit)):
                with self.assertRaises(RuntimeError):
                    operation()
            request['pc_id'] = 1
            raise BrokenPipeError('socket closed')
        result = self.list.run([a['entry_id']], execute, self.cancel, self.emit)
        self.assertEqual(result['status'], 'unconfirmed')
        self.assertEqual(self.list.items()[0]['request'], REQUEST)

    def test_invalid_entry_schema_is_value_error_and_file_is_preserved(self):
        entry = self.add()
        cases = [None, [], {}, {**entry, "status": []}, {**entry, "request": []},
                 {**entry, "entry_id": []}, {**entry, "quantity": True},
                 {**entry, "source": {}}, {**entry, "unexpected": "value"}]
        for invalid in cases:
            with self.subTest(invalid=invalid):
                content = json.dumps([invalid])
                self.path.write_text(content)
                with self.assertRaises(ValueError):
                    PurchaseList(self.path)
                self.assertEqual(self.path.read_text(), content)

    def test_conflicting_list_association_is_rejected(self):
        entry = self.add(source="site", shopping_id="42")
        for source, shopping_id in (("local", None), ("site", "43"), ("local", "42")):
            with self.subTest(source=source, shopping_id=shopping_id), self.assertRaises(ValueError):
                self.list.add(REQUEST, 2, "Rifle", "capture2", source, shopping_id)
        self.assertEqual(self.list.items(), [entry])
        with self.assertRaises(ValueError):
            self.add(1, source="local", shopping_id="42")
        self.assertEqual(PurchaseList(self.path).items(), [entry])

    def test_invalid_file_and_failed_atomic_replace_never_send(self):
        a = self.add()
        old = self.path.read_bytes()
        execute = Mock()
        with patch('rfnext_market.purchase_list.os.replace', side_effect=OSError('disk')):
            with self.assertRaises(OSError):
                self.list.run([a['entry_id']], execute, self.cancel, self.emit)
        execute.assert_not_called()
        self.assertEqual(self.path.read_bytes(), old)
        self.assertEqual(self.list.items()[0]['status'], 'prepared')
        self.path.write_text('{broken')
        with self.assertRaises(ValueError):
            PurchaseList(self.path)
        self.assertEqual(self.path.read_text(), '{broken')


if __name__ == '__main__':
    unittest.main()
