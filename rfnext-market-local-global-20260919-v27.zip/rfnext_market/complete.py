"""Consulta completa com heartbeat independente e ciclos sem sobreposição."""
import copy
import math
import threading

from . import session, rankings, upload

SERVER = "https://apirf.karvalho.dev.br"


class _CycleStop:
    """Cancela operações por parada externa ou perda do heartbeat, sem confundi-las."""
    def __init__(self, user_stop, heartbeat_ended):
        self.user_stop = user_stop
        self.heartbeat_ended = heartbeat_ended

    def is_set(self):
        return self.user_stop.is_set() or self.heartbeat_ended.is_set()

    def wait(self, timeout=None):
        import time
        deadline = None if timeout is None else time.monotonic() + timeout
        while not self.is_set():
            remaining = .1 if deadline is None else min(.1, deadline - time.monotonic())
            if remaining <= 0:
                return False
            self.heartbeat_ended.wait(remaining)
        return True


def run(config, emit, stop_event, continuous=False, interval=300, runner=None, submit=None):
    runner = runner or session.run
    submit = submit or upload.submit_result
    if not math.isfinite(interval) or interval <= 0:
        raise ValueError("Intervalo deve ser positivo e finito")
    base = copy.deepcopy(config)
    base["companion"] = dict(base.get("companion") or {}, base_url=SERVER)
    heartbeat = copy.deepcopy(base)
    heartbeat.update(heartbeat_only=True, rankings=False, initialize_character=True)
    heartbeat["heartbeat"] = dict({"constant": -371988797, "flag": 0}, **base.get("heartbeat", {}))
    heartbeat["heartbeat"]["enabled"] = True
    ready, ended = threading.Event(), threading.Event()
    heartbeat_stop = threading.Event()
    cycle_stop = _CycleStop(stop_event, ended)
    failure = []

    def check_heartbeat():
        if ended.is_set() and not stop_event.is_set():
            raise RuntimeError("Heartbeat interrompido: " + (failure[0] if failure else "conexão encerrada"))

    def observe(record):
        if record.get("status") == "cancelled" and ended.is_set() and not stop_event.is_set():
            record = dict(record, status="failed", message="Heartbeat interrompido: " + failure[0],
                          diagnostic="Heartbeat interrompido: " + failure[0])
        emit(record)

    def maintain():
        try:
            value = runner(heartbeat, emit, stop_event=heartbeat_stop,
                           on_collected=lambda result: ready.set())
            failure.append(value.get("diagnostic") or value.get("connection", {}).get("reason") or "Heartbeat encerrado")
        except Exception as exc:
            failure.append(str(exc))
        finally:
            ended.set()

    worker = threading.Thread(target=maintain, daemon=True)
    worker.start()
    result = None
    try:
        while not ready.wait(0.1):
            if ended.is_set() or stop_event.is_set():
                raise RuntimeError(failure[0] if failure else "Inicialização cancelada")
        while not stop_event.is_set():
            if ended.is_set():
                worker.join()
                ready.clear()
                ended.clear()
                failure.clear()
                heartbeat_stop.clear()
                worker = threading.Thread(target=maintain, daemon=True)
                worker.start()
                while not ready.wait(0.1):
                    if ended.is_set() or stop_event.is_set():
                        raise RuntimeError(failure[0] if failure else "Inicialização cancelada")
            cycle_error = None
            try:
                rank_config = copy.deepcopy(base)
                rank_config.update(rankings_only=True, heartbeat_only=False, rankings=True)
                rank_config["heartbeat"] = {"enabled": False}
                rank_config["market"].update(list_requests=[], detail_requests=[], both_markets=False, detail_all_items=False)
                emit({"record_type": "cycle", "stage": "rankings", "status": "running"})
                rank_result = runner(rank_config, observe, stop_event=cycle_stop)
                if stop_event.is_set():
                    break
                snapshots = rank_result.get("rankings", {})
                if any(snapshots.get(name, {}).get("status") != "completed" for name in ("exp", "accretia", "bellato", "cora")):
                    check_heartbeat()
                    emit({"record_type": "cycle", "stage": "rankings", "status": "incomplete",
                          "message": "Rankings incompletos; mercado e dados disponíveis continuarão para o envio."})
                emit({"record_type": "cycle", "stage": "rankings", "status": "completed",
                      "message": "Quatro rankings recebidos; mercado continuará mesmo se o heartbeat encerrar."})
                if stop_event.is_set():
                    break
                market_config = copy.deepcopy(base)
                market_config.update(rankings_only=False, heartbeat_only=False, rankings=False)
                market_config["heartbeat"] = {"enabled": False}
                market_config["market"].update(both_markets=True, detail_all_items=True, detail_requests=[])
                emit({"record_type": "cycle", "stage": "market", "status": "running"})
                result = runner(market_config, emit, stop_event=stop_event)
                if stop_event.is_set():
                    break
                result["rankings"] = snapshots
                if result.get("status") != "completed":
                    emit({"record_type": "cycle", "stage": "market", "status": "incomplete",
                          "message": "Mercado incompleto; dados disponíveis continuarão para o envio."})
                emit({"record_type": "cycle", "stage": "sellers", "status": "deferred",
                      "message": "Vínculo de pc_id com personagem será feito pelo site."})
                if stop_event.is_set():
                    break
                result["upload"] = submit(result, base, emit=emit, stop_event=stop_event)
                emit({"record_type": "cycle", "stage": "done", "status": result["upload"].get("status"), "result": result})
            except Exception as exc:
                cycle_error = exc
                emit({"record_type": "cycle", "stage": "error", "status": "failed",
                      "message": str(exc), "diagnostic": str(exc)})
                if not continuous:
                    raise
            if stop_event.is_set() or not continuous:
                break
            # O intervalo começa quando o ciclo termina, inclusive quando ele falha.
            if stop_event.wait(interval):
                break
        return result
    finally:
        heartbeat_stop.set()
        worker.join()
