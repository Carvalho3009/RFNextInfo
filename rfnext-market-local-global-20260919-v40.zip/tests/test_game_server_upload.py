import json
from contextlib import closing
from pathlib import Path
import sqlite3
import struct
import tempfile
import unittest
from unittest.mock import patch

from rfnext_market import upload
from tests import test_session as fixtures


class GameServerTest(unittest.TestCase):
    def collect(self, requested, returned, ret=0):
        runner = fixtures.SessionTest()
        cfg = fixtures.config()
        cfg['world_id'] = requested
        answer = bytearray(fixtures.ans_0108(ret))
        struct.pack_into('<H', answer, 2, returned)
        result = runner.run_session(cfg=cfg, auth_s=fixtures.auth_script({0x0107: [[(0x0108, bytes(answer))]]}))
        return result, runner

    def test_confirmed_server_and_unknown_name(self):
        for world, name in ((5024, 'Menkar 4'), (1, None)):
            result, _ = self.collect(world, world)
            self.assertEqual(result['status'], 'completed')
            self.assertEqual(result['game_server'], {'world_id': world, 'world_name': name})

    def test_mismatch_or_rejection_does_not_connect_game_or_label_result(self):
        for requested, returned, ret in ((5024, 1, 0), (5024, 5024, 1)):
            result, runner = self.collect(requested, returned, ret)
            self.assertEqual(result['status'], 'failed')
            self.assertNotIn('game_server', result)
            self.assertNotIn(12020, runner.conns)

    def test_invalid_metadata_remains_unqueued(self):
        invalid = [dict(world_id=0, world_name=None), dict(world_id=1, world_name=" x"),
                   dict(world_id=1, world_name="x\n"), dict(world_id=1, world_name=""),
                   dict(world_id=1, world_name="x" * 65),
                   dict(world_id=1, world_name="127.0.0.1"), dict(world_id=1, world_name="x\u200b")]
        with tempfile.TemporaryDirectory() as folder, \
             patch.object(upload, '_identity', return_value=({'installation_id': 'test'}, None)):
            config = {'companion': {'base_url': 'https://example.com', 'state_dir': folder}}
            for metadata in invalid:
                upload.submit_result({'game_server': metadata}, config)
            with closing(sqlite3.connect(Path(folder) / 'market-upload.sqlite3')) as db:
                self.assertEqual(db.execute('SELECT COUNT(*) FROM batches').fetchone()[0], 0)
                self.assertEqual(db.execute('SELECT COUNT(*) FROM results WHERE queued=0 AND error IS NOT NULL').fetchone()[0], len(invalid))

    def test_saved_document_drives_all_event_types_and_retries(self):
        payloads = [{'items': []}, {'offers': []}]
        ranks = [{'ranking_records': []}, {'faction_ranking_records': []}]
        with tempfile.TemporaryDirectory() as folder:
            config = {'world_id': 5024, 'companion': {'base_url': 'https://example.com', 'state_dir': folder}}
            source = {'game_server': {'world_id': 5024, 'world_name': 'Menkar 4'}}
            with patch.object(upload, '_identity', side_effect=ValueError('not linked')):
                upload.submit_result(source, config)
                upload.submit_result({}, config)  # historical document, no world metadata
            config['world_id'] = 9
            with patch.object(upload, '_identity', return_value=({'installation_id': 'test'}, None)), \
                 patch.object(upload, '_flush', return_value={'status': 'pending'}), \
                 patch.object(upload, 'market_payloads', side_effect=lambda *_: list(payloads)), \
                 patch('rfnext_market.rankings.upload_payloads', return_value=ranks):
                upload.retry_pending(config)
                with closing(sqlite3.connect(Path(folder) / 'market-upload.sqlite3')) as db:
                    before = db.execute('SELECT body FROM batches ORDER BY sequence').fetchall()
                    documents = {row[0]: json.loads(row[1]) for row in db.execute('SELECT result_ref,document FROM results')}
                upload.retry_pending(config)
                with closing(sqlite3.connect(Path(folder) / 'market-upload.sqlite3')) as db:
                    self.assertEqual(before, db.execute('SELECT body FROM batches ORDER BY sequence').fetchall())
            self.assertEqual(len(before), 8)
            types = set()
            for row in before:
                event = json.loads(row[0])['events'][0]
                types.add(event['type'])
                if 'game_server' in documents[event['session_ref']]:
                    self.assertEqual(event['game_server'], source['game_server'])
                else:
                    self.assertNotIn('game_server', event)
            self.assertEqual(len(types), 4)


if __name__ == '__main__':
    unittest.main()
