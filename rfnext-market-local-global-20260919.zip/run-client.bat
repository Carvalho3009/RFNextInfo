@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 goto use_py
where python >nul 2>&1
if not errorlevel 1 goto use_python
echo Python 3.10+ nao encontrado. Instale Python com Tkinter e tente novamente.
exit /b 2

:use_py
py -3 -m rfnext_market.desktop %*
exit /b %errorlevel%

:use_python
python -m rfnext_market.desktop %*
exit /b %errorlevel%
