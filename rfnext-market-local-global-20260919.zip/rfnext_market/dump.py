"""Escritor de dump JSON Lines: um registro por linha, flush+fsync a cada gravação.

record_type: "frame" | "error" | "completion" | "market_result" | "diagnostic".
Abre sempre em append (preserva registros anteriores de uma sessão anterior).
"""
from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime


class DumpWriter:
    def __init__(self, path):
        path = str(path)
        if not path.endswith(".jsonl"):
            raise ValueError(f"dump path must end in .jsonl: {path!r}")
        self._path = path
        self._file = open(path, "a", encoding="utf-8")

    def write(self, record: dict) -> None:
        if self._file.closed:
            raise ValueError("write on closed DumpWriter")
        line = json.dumps(record, ensure_ascii=False, default=_json_default)
        self._file.write(line + "\n")
        self._file.flush()
        os.fsync(self._file.fileno())

    def close(self) -> None:
        if not self._file.closed:
            self._file.close()


def _json_default(obj):
    if isinstance(obj, (bytes, bytearray)):
        return obj.hex()
    raise TypeError(f"not JSON serializable: {type(obj)!r}")


def make_frame_record(conn, direction: str, wire: bytes, frame: dict, parsed: dict | None) -> dict:
    """Monta um registro "frame" a partir de uma Connection, o wire cru e o
    resultado de protocol.decode_frame (frame) + auth/market parse_message (parsed)."""
    decoded = bytes.fromhex(frame["decoded_hex"])
    parsed = parsed or {}
    return {
        "record_type": "frame",
        "connection_id": conn.connection_id,
        "local_endpoint": conn.local_endpoint,
        "remote_endpoint": conn.remote_endpoint,
        "service_port": conn.service_port,
        "direction": direction,
        "timestamp": datetime.now().astimezone().isoformat(),
        "opcode": frame["opcode"],
        "sequence": frame["sequence"],
        "wire_length": frame["wire_length"],
        "decoded_length": frame["decoded_length"],
        "wire_hex": bytes(wire).hex(),
        "decoded_hex": frame["decoded_hex"],
        "wire_sha256": hashlib.sha256(bytes(wire)).hexdigest(),
        "decoded_sha256": hashlib.sha256(decoded).hexdigest(),
        "parsed_fields": parsed.get("fields", {}),
        "unknown_fields": parsed.get("unknown_fields", []),
    }
