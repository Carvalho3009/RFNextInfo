"""TCP transport for rfnext_market connections.

Thin wrapper around a blocking TCP socket: connects once, sends raw wire
frames, and hands back complete wire frames via protocol.FrameBuffer. No
reconnection, no retry — a lost connection is the caller's problem.
"""
from __future__ import annotations

import errno
import ipaddress
import itertools
import select
import socket
import threading
import time
import uuid

from rfnext_market.protocol import FrameBuffer

DIRECTION_C2S = "client_to_server"
DIRECTION_S2C = "server_to_client"

_RECV_CHUNK = 4096
_IO_POLL = 0.05
_id_counter = itertools.count(1)


class CancelledError(Exception):
    """A conexão foi cancelada antes de terminar de abrir ou receber."""


def _format_endpoint(addr) -> str:
    # addr is (host, port) for IPv4/IPv6-mapped sockets used here.
    host, port = addr[0], addr[1]
    return f"{host}:{port}"


def _resolve(host, port, deadline, stop_event):
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        result = []
        finished = threading.Event()

        def resolve():
            try:
                result.append(socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM))
            except BaseException as exc:
                result.append(exc)
            finally:
                finished.set()

        threading.Thread(target=resolve, name="rfnext-dns", daemon=True).start()
        while not finished.wait(min(_IO_POLL, max(0, deadline - time.monotonic()))):
            if stop_event.is_set():
                raise CancelledError()
            if time.monotonic() >= deadline:
                raise TimeoutError(f"timed out resolving {host}:{port}")
        if stop_event.is_set():
            raise CancelledError()
        resolved = result[0]
        if isinstance(resolved, BaseException):
            raise resolved
        return resolved

    if address.version == 6:
        sockaddr = (str(address), port, 0, 0)
        return [(socket.AF_INET6, socket.SOCK_STREAM, 0, "", sockaddr)]
    return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (str(address), port))]


def _connect(host, port, timeout, stop_event):
    if stop_event is None:
        return socket.create_connection((host, port), timeout=timeout)
    if stop_event.is_set():
        raise CancelledError()
    deadline = time.monotonic() + timeout
    last_error = None
    for family, socktype, proto, _, address in _resolve(host, port, deadline, stop_event):
        if stop_event.is_set():
            raise CancelledError()
        sock = socket.socket(family, socktype, proto)
        keep = False
        try:
            sock.setblocking(False)
            error = sock.connect_ex(address)
            if error not in (0, 10035, 10036, errno.EINPROGRESS, errno.EWOULDBLOCK, errno.EALREADY):
                last_error = OSError(error, "connect failed")
                continue
            while True:
                if stop_event.is_set():
                    raise CancelledError()
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise TimeoutError(f"timed out connecting to {host}:{port}")
                _, writable, exceptional = select.select([], [sock], [sock], min(0.05, remaining))
                if not writable and not exceptional:
                    continue
                error = sock.getsockopt(socket.SOL_SOCKET, socket.SO_ERROR)
                if error == 0:
                    sock.setblocking(True)
                    keep = True
                    return sock
                last_error = OSError(error, "connect failed")
                break
        except CancelledError:
            raise
        finally:
            if not keep:
                sock.close()
    if stop_event.is_set():
        raise CancelledError()
    if last_error:
        raise last_error
    raise ConnectionError(f"could not resolve {host}:{port}")


class Connection:
    def __init__(self, host: str, port: int, timeout: float, stop_event=None):
        sock = _connect(host, port, timeout, stop_event)
        try:
            sock.settimeout(timeout)
            self._sock = sock
            self.service_port = port
            self.local_endpoint = _format_endpoint(sock.getsockname())
            self.remote_endpoint = _format_endpoint(sock.getpeername())
            self.connection_id = f"{uuid.uuid4().hex[:8]}-{next(_id_counter)}"
            self._buffer = FrameBuffer()
            self._pending_frames: list[bytes] = []
            self._closed = False
        except BaseException:
            sock.close()
            raise

    def send(self, wire: bytes, stop_event=None) -> None:
        timeout = self._sock.gettimeout()
        deadline = None if timeout is None else time.monotonic() + timeout
        view = memoryview(wire)
        try:
            while view:
                if stop_event is not None and stop_event.is_set():
                    raise CancelledError()
                remaining = None if deadline is None else deadline - time.monotonic()
                if remaining is not None and remaining <= 0:
                    raise TimeoutError(f"timeout sending to {self.remote_endpoint}")
                self._sock.settimeout(_IO_POLL if remaining is None else min(_IO_POLL, remaining))
                try:
                    sent = self._sock.send(view)
                except socket.timeout as exc:
                    if stop_event is not None and stop_event.is_set():
                        raise CancelledError() from exc
                    if deadline is not None and time.monotonic() >= deadline:
                        raise TimeoutError(f"timeout sending to {self.remote_endpoint}") from exc
                    continue
                if not sent:
                    raise ConnectionError(f"connection closed by {self.remote_endpoint}")
                view = view[sent:]
        finally:
            self._sock.settimeout(timeout)

    def receive(self, stop_event=None) -> bytes:
        while not self._pending_frames:
            if stop_event is not None and stop_event.is_set():
                raise CancelledError()
            try:
                chunk = self._sock.recv(_RECV_CHUNK)
            except socket.timeout as exc:
                if stop_event is not None and stop_event.is_set():
                    raise CancelledError() from exc
                raise TimeoutError(
                    f"timeout waiting for frame on {self.remote_endpoint}"
                ) from exc
            if not chunk:
                if self._buffer.pending:
                    raise ConnectionError(
                        f"EOF mid-frame on {self.remote_endpoint} "
                        f"({self._buffer.pending} bytes pending)"
                    )
                raise ConnectionError(f"connection closed by {self.remote_endpoint}")
            self._pending_frames.extend(self._buffer.feed(chunk))
        return self._pending_frames.pop(0)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        self._sock.close()
