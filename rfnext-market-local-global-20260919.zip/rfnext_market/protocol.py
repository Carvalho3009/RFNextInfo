"""Framing RF Next: cabeçalho de 6 bytes, rolling XOR e LZ4 em bloco.

Lógica reescrita a partir do decoder canônico 1.28.5 (frame_length_from_wire,
remove_rolling_xor, apply_rolling_xor, lz4_block_decompress, decode_frame).

Cabeçalho decodificado: b0 (0x80 = XOR no wire, 0x40 = LZ4, 6 bits baixos = seed),
length u16 LE (quadro inteiro, com cabeçalho), sequence u8, opcode u16 LE.
"""

HEADER_SIZE = 6
MAX_FRAME = 0xFFFF


def frame_length_from_wire(header: bytes) -> int:
    """Comprimento total declarado; precisa dos 3 primeiros bytes do wire."""
    if len(header) < 3:
        raise ValueError("frame header: need 3 bytes to read length")
    if not header[0] & 0x80:
        return int.from_bytes(header[1:3], "little")
    lo = header[1] ^ (header[0] ^ 0xEF)
    hi = header[2] ^ (header[1] ^ 0xEF)
    return lo | (hi << 8)


def remove_rolling_xor(frame: bytes) -> bytes:
    data = bytearray(frame)
    if not data or not data[0] & 0x80:
        return bytes(data)
    state = data[0] ^ 0xEF
    for index in range(1, len(data)):
        cipher = data[index]
        data[index] = cipher ^ state
        state = cipher ^ ((-0x11 * index) & 0xFF)
    data[0] &= 0x7F
    return bytes(data)


def apply_rolling_xor(frame: bytes, seed: int) -> bytes:
    if not 0 <= seed <= 0x3F:
        raise ValueError(f"seed {seed} outside 0..0x3F")
    data = bytearray(frame)
    data[0] = 0x80 | seed
    state = data[0] ^ 0xEF
    for index in range(1, len(data)):
        data[index] ^= state
        state = data[index] ^ ((-0x11 * index) & 0xFF)
    return bytes(data)


def lz4_block_decompress(source: bytes, capacity: int = MAX_FRAME - HEADER_SIZE) -> bytes:
    """Bloco LZ4 completo. Rejeita bloco vazio, truncado, offsets inválidos, saída acima
    de capacity e bloco que não termina numa sequência só de literais (saída parcial)."""
    if not source:
        raise ValueError("LZ4: empty block")
    output = bytearray()
    cursor = 0

    def extended(initial: int) -> int:
        nonlocal cursor
        length = initial
        if initial != 0x0F:
            return length
        while True:
            if cursor >= len(source):
                raise ValueError(f"LZ4: truncated length at offset {cursor}")
            value = source[cursor]
            cursor += 1
            length += value
            if value != 0xFF:
                return length

    while True:
        token = source[cursor]
        cursor += 1
        literal_length = extended(token >> 4)
        literal_end = cursor + literal_length
        if literal_end > len(source):
            raise ValueError(f"LZ4: truncated literals at offset {cursor}")
        if len(output) + literal_length > capacity:
            raise ValueError(f"LZ4: output exceeds capacity {capacity}")
        output += source[cursor:literal_end]
        cursor = literal_end
        if cursor == len(source):
            return bytes(output)  # última sequência: só literais
        if cursor + 2 > len(source):
            raise ValueError(f"LZ4: truncated match offset at offset {cursor}")
        offset = source[cursor] | (source[cursor + 1] << 8)
        cursor += 2
        if offset == 0 or offset > len(output):
            raise ValueError(f"LZ4: invalid match offset {offset} (output {len(output)} bytes)")
        match_length = extended(token & 0x0F) + 4
        if len(output) + match_length > capacity:
            raise ValueError(f"LZ4: output exceeds capacity {capacity}")
        start = len(output) - offset
        for i in range(match_length):  # byte a byte: cópia pode sobrepor
            output.append(output[start + i])
        if cursor == len(source):
            raise ValueError("LZ4: block ends with a match, missing final literals")


def decode_frame(wire: bytes) -> dict:
    wire = bytes(wire)
    if len(wire) < HEADER_SIZE:
        raise ValueError(f"frame: {len(wire)} bytes, shorter than {HEADER_SIZE}-byte header")
    if len(wire) > MAX_FRAME:
        raise ValueError(f"frame: {len(wire)} bytes exceeds MAX_FRAME")
    declared = frame_length_from_wire(wire)
    if declared != len(wire):
        raise ValueError(f"frame: declared length {declared} differs from supplied {len(wire)}")
    obfuscated = bool(wire[0] & 0x80)
    decoded = bytearray(remove_rolling_xor(wire))
    compressed = bool(decoded[0] & 0x40)
    if compressed:
        body = lz4_block_decompress(bytes(decoded[HEADER_SIZE:]))
        decoded = decoded[:HEADER_SIZE] + body
        decoded[0] &= 0xBF
        decoded[1:3] = len(decoded).to_bytes(2, "little")
    return {
        "opcode": int.from_bytes(decoded[4:6], "little"),
        "sequence": decoded[3],
        "payload": bytes(decoded[HEADER_SIZE:]),
        "decoded_hex": decoded.hex(),
        "wire_length": len(wire),
        "decoded_length": len(decoded),
        "compressed": compressed,
        "obfuscated": obfuscated,
        "seed": decoded[0] & 0x3F,
    }


def encode_frame(opcode: int, payload: bytes, sequence: int, *, seed: int) -> bytes:
    """Quadro C→S: XOR com seed, sem LZ4 (como os 195 quadros de cliente da captura)."""
    if not 0 <= opcode <= 0xFFFF:
        raise ValueError(f"opcode {opcode} outside 0..0xFFFF")
    if not 0 <= sequence <= 0xFF:
        raise ValueError(f"sequence {sequence} outside 0..255")
    if not 0 <= seed <= 0x3F:
        raise ValueError(f"seed {seed} outside 0..0x3F")
    length = HEADER_SIZE + len(payload)
    if length > MAX_FRAME:
        raise ValueError(f"payload {len(payload)} bytes: frame {length} exceeds MAX_FRAME")
    header = bytes([seed]) + length.to_bytes(2, "little") + bytes([sequence]) + opcode.to_bytes(2, "little")
    return apply_rolling_xor(header + bytes(payload), seed)


class FrameBuffer:
    """Acumula bytes do TCP e devolve quadros wire completos."""

    def __init__(self) -> None:
        self._buffer = bytearray()

    @property
    def pending(self) -> int:
        return len(self._buffer)

    def feed(self, data: bytes) -> list[bytes]:
        self._buffer += data
        frames = []
        while len(self._buffer) >= 3:
            length = frame_length_from_wire(self._buffer[:3])
            if length < HEADER_SIZE:
                # stream dessincronizado: não há como recuperar a fronteira
                raise ValueError(f"frame buffer: invalid declared length {length}")
            if len(self._buffer) < length:
                break
            frames.append(bytes(self._buffer[:length]))
            del self._buffer[:length]
        return frames
