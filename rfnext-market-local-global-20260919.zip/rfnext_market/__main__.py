"""python -m rfnext_market --config config.json --output resultado.jsonl"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def _endpoint(config: dict, name: str) -> None:
    section = config.get(name)
    if not isinstance(section, dict):
        raise ValueError(f"{name}: seção obrigatória")
    host = section.get("host")
    if not isinstance(host, str) or not host.strip():
        raise ValueError(f"{name}.host: obrigatório (sem padrão)")
    port = section.get("port")
    if not isinstance(port, int) or isinstance(port, bool) or not 1 <= port <= 65535:
        raise ValueError(f"{name}.port: porta inválida")
    timeout = section.get("timeout")
    if not isinstance(timeout, (int, float)) or isinstance(timeout, bool) or timeout <= 0:
        raise ValueError(f"{name}.timeout: deve ser positivo")


def load_config(path: Path) -> dict:
    """Lê e valida a configuração; carrega credenciais de session_file. Não abre sockets."""
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"config: não foi possível ler {path}: {exc}") from exc
    if not isinstance(config, dict):
        raise ValueError("config: objeto JSON esperado")
    from . import upload
    companion = upload.validate_config(config, base=path.parent)
    if companion is not None:
        config["companion"] = companion
    _endpoint(config, "auth")
    _endpoint(config, "game")
    world_id = config.get("world_id")
    if not isinstance(world_id, int) or isinstance(world_id, bool) or not 0 <= world_id <= 0xFFFF:
        raise ValueError("world_id: inteiro u16 obrigatório")
    market = config.get("market")
    if not isinstance(market, dict):
        raise ValueError("market: seção obrigatória")
    timeout = market.get("response_timeout")
    if not isinstance(timeout, (int, float)) or isinstance(timeout, bool) or timeout <= 0:
        raise ValueError("market.response_timeout: deve ser positivo")
    if "detail_all_items" in market and not isinstance(market["detail_all_items"], bool):
        raise ValueError("market.detail_all_items: booleano obrigatório")
    if "both_markets" in market and not isinstance(market["both_markets"], bool):
        raise ValueError("market.both_markets: booleano obrigatório")
    lists = market.get("list_requests", [])
    details = market.get("detail_requests", [])
    if not isinstance(lists, list) or not isinstance(details, list) or not (lists or details):
        raise ValueError("market: informe list_requests e/ou detail_requests")
    for i, item in enumerate(lists):
        raw = item.get("payload_hex") if isinstance(item, dict) else None
        try:
            ok = isinstance(raw, str) and len(bytes.fromhex(raw)) == 2
        except ValueError:
            ok = False
        if not ok:
            raise ValueError(f"market.list_requests[{i}].payload_hex: 2 bytes em hex")
        if "exchange_server_type" in item:
            expected = item["exchange_server_type"]
            if type(expected) is not int or not 0 <= expected <= 255:
                raise ValueError(f"market.list_requests[{i}].exchange_server_type: inteiro 0..255")
    for i, item in enumerate(details):
        if not isinstance(item, dict):
            raise ValueError(f"market.detail_requests[{i}]: objeto esperado")
        for key, limit in (("item_index", 0xFFFFFFFF), ("trailing_u8", 0xFF)):
            value = item.get(key)
            if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= limit:
                raise ValueError(f"market.detail_requests[{i}].{key}: inteiro fora do limite")
    from .selection import load_products

    load_products(market)  # valida market.products (ou usa o mapa das instruções)
    trailing = market.get("trailing_u8", 0)
    if not isinstance(trailing, int) or isinstance(trailing, bool) or not 0 <= trailing <= 0xFF:
        raise ValueError("market.trailing_u8: inteiro 0..255")
    session_file = config.get("session_file")
    if not isinstance(session_file, str) or not session_file:
        raise ValueError("session_file: caminho obrigatório")
    session_path = Path(session_file)
    if not session_path.is_absolute():
        session_path = path.parent / session_path
    try:
        credentials = json.loads(session_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"session_file: não foi possível ler o arquivo de sessão: {exc}") from exc
    if not isinstance(credentials, dict):
        raise ValueError("session_file: objeto JSON esperado")
    _check_credentials(credentials, world_id)
    config["credentials"] = credentials
    return config


def _check_credentials(credentials: dict, world_id: int) -> None:
    """Confere, antes de abrir qualquer socket, que session_file traz todo campo exigido
    por auth.REQUIRED_FIELDS para todo envio não-mercado de session.ALLOWED_SENDS (12000 e
    12020; opcodes 0x1Dxx de mercado não carregam credenciais e são ignorados), com tipo e
    tamanho válidos (via auth.build_payload), exceto os campos derivados em tempo de
    execução (session.DERIVED_FIELDS: world_id, u64@2688), que recebem placeholders."""
    from . import auth, session

    placeholders = {"world_id": world_id, "u64@2688": 0}
    sends = [(port, opcode) for port, opcodes in session.ALLOWED_SENDS.items()
             for opcode in opcodes if opcode < 0x1D00]
    for port, opcode in sends:
        merged = {k: v for k, v in credentials.items() if not isinstance(v, dict)}
        merged.update(credentials.get(f"{port}_0x{opcode:04x}", {}))
        missing = [f for f in auth.REQUIRED_FIELDS.get((port, opcode), ())
                   if f not in session.DERIVED_FIELDS and f not in merged]
        if missing:
            raise ValueError(
                f"session_file: campo(s) obrigatório(s) ausente(s) para porta {port} "
                f"0x{opcode:04x}: {', '.join(missing)}")
        try:
            auth.build_payload(port, opcode, {**merged, **placeholders})
        except ValueError as exc:
            raise ValueError(
                f"session_file: campo inválido para porta {port} 0x{opcode:04x}: {exc}") from None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="rfnext_market", description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=False)
    parser.add_argument("--resumo", type=Path, default=None,
                        help="CSV de resumo (padrão: mercado_resumo.csv junto do --output)")
    parser.add_argument("--ofertas", type=Path, default=None,
                        help="CSV de ofertas (padrão: mercado_ofertas.csv junto do --output)")
    parser.add_argument("--retry-upload", action="store_true", help="tenta enviar a outbox Companion")
    args = parser.parse_args(argv)
    if not args.retry_upload and args.output is None:
        parser.error("--output é obrigatório na consulta normal")
    if args.output is not None and args.output.suffix != ".jsonl":
        print("erro: --output deve terminar em .jsonl", file=sys.stderr)
        return 2
    from . import upload
    if args.retry_upload:
        try:
            raw = json.loads(args.config.read_text(encoding="utf-8"))
            companion = upload.validate_config(raw, base=args.config.parent)
            result = upload.retry_pending({"companion": companion} if companion else {})
            print(json.dumps(result, ensure_ascii=False))
            return 0 if result.get("status") in {"disabled", "accepted", "idle", "no_market_data"} else 1
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            print(f"falha upload: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 1
    try:
        config = load_config(args.config)
    except ValueError as exc:
        print(f"erro de configuração: {exc}", file=sys.stderr)
        return 2

    from . import dump, report, session

    writer = dump.DumpWriter(args.output)
    last_progress = {"completed": 0, "total": 0}

    def emit(record: dict) -> None:
        writer.write(record)
        if record.get("record_type") == "progress":
            completed = int(record.get("completed", 0))
            total = int(record.get("total", 0))
            last_progress.update(completed=completed, total=total)
            percent = (completed / total * 100) if total else 100
            print(f"\rDetalhes: {completed}/{total} ({percent:5.1f}%)", end="", file=sys.stderr, flush=True)
    try:
        result = session.run(config, emit)
    except (ValueError, TimeoutError, ConnectionError, OSError) as exc:
        writer.write({"record_type": "error", "stage": "run", "error": type(exc).__name__, "message": str(exc)})
        writer.close()
        print(f"falha: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    try:
        result["upload"] = upload.submit_result(result, config, emit=emit)
    except Exception as exc:
        result["upload"] = {"status": "pending", "diagnostic": f"upload: {type(exc).__name__}: {exc}"}
    finally:
        if result["upload"].get("status") != "disabled":
            writer.write({"record_type": "upload_result", **result["upload"]})
        writer.close()
    if last_progress["total"]:
        print(file=sys.stderr)
    base = args.output.parent
    written = report.write_reports(result.get("items", []),
                                   args.resumo or base / "mercado_resumo.csv",
                                   args.ofertas or base / "mercado_ofertas.csv")
    print(f"status={result.get('status')} stage={result.get('stage')} diagnóstico={result.get('diagnostic')}")
    if result["upload"].get("status") != "disabled":
        print("Companion: " + json.dumps(result["upload"], ensure_ascii=False))
    print(f"resumo={written['summary_path']} ({written['summary_rows']} linhas) "
          f"ofertas={written['offers_path']} ({written['offer_rows']} linhas)")
    return 0 if result.get("status") == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
