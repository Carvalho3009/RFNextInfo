"""Cliente de teste somente leitura do mercado RF NEXT (servidor de teste do operador)."""
