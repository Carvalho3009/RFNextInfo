"""Agente 3 - Seleção de itens após 0x1D02.

Os nomes de produto vêm exclusivamente do mapa fornecido nas instruções (ou de
`market.products` na configuração). Nenhum nome é inferido a partir do ID.

Estados finais de um item (Agente 3):
  "ausente"     - item_index não apareceu em nenhum 0x1D02
  "sem_ofertas" - apareceu no agregado, mas nenhuma oferta individual em 0x1D04
  "com_ofertas" - pelo menos uma oferta individual em 0x1D04
  "erro"        - consulta de detalhe falhou (ret != 0, timeout, parse)
"""
from __future__ import annotations
import sqlite3

# Mapa fornecido nas instruções (item_index -> produto).
PRODUCTS = {
    1002: "Secret Nemesis Base Permit Extension",
    1007: "Albern Crater Permit Extension",
    1006: "Exclusive Mining Field Permit Extension",
    1003: "Mining Field Permit Extension (Accretia)",
}

AUSENTE = "ausente"
SEM_OFERTAS = "sem_ofertas"
COM_OFERTAS = "com_ofertas"
ERRO = "erro"

def load_sellable_database(path: str) -> dict[int, str]:
    """Carrega item_index->nome marcado como vendável no exchange."""
    with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as conn:
        return {int(i): (name or "") for i, name in conn.execute(
            "SELECT item_index, name FROM market_items WHERE sellable=1")}


def load_products(config_market: dict | None = None) -> dict:
    """Mapa item_index->produto. Chaves JSON (texto) são convertidas em int; a ordem
    de declaração é preservada e item_index duplicado é rejeitado."""
    raw = (config_market or {}).get("products")
    if raw is None:
        return dict(PRODUCTS)
    if not isinstance(raw, dict) or not raw:
        raise ValueError("market.products: objeto {\"item_index\": \"produto\"} esperado")
    products = {}
    for key, name in raw.items():
        try:
            item_index = int(key)
        except (TypeError, ValueError):
            raise ValueError(f"market.products: chave {key!r} não é item_index inteiro") from None
        if not 0 <= item_index <= 0xFFFFFFFF:
            raise ValueError(f"market.products: item_index {item_index} fora de u32")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"market.products[{key}]: nome de produto obrigatório")
        if item_index in products:
            raise ValueError(f"market.products: item_index {item_index} repetido")
        products[item_index] = name
    return products


def select(aggregate_entries, products: dict | None = None) -> list[dict]:
    """Cruza as entradas de 0x1D02 com o mapa de produtos.

    Devolve um registro por produto, na ordem do mapa, sem repetir item_index. Cada
    registro traz as entradas agregadas correspondentes (um item pode aparecer em vários
    níveis de refino) e o total de `number_of_registered_items` declarado pelo servidor.
    """
    products = dict(PRODUCTS) if products is None else products
    found: dict[int, list[dict]] = {}
    for entry in aggregate_entries:
        item_index = entry.get("item_index")
        if item_index in products:
            found.setdefault(item_index, []).append(entry)
    selections = []
    for item_index, produto in products.items():
        entries = found.get(item_index, [])
        selections.append({
            "item_index": item_index,
            "produto": produto,
            "found_in_list": bool(entries),
            "aggregates": entries,
            "registered_items": sum(int(e.get("number_of_registered_items") or 0) for e in entries),
            "lowest_price": min((e["lowest_price"] for e in entries if "lowest_price" in e), default=None),
            "highest_price": max((e["highest_price"] for e in entries if "highest_price" in e), default=None),
            "status": AUSENTE if not entries else SEM_OFERTAS,
        })
    return selections


def detail_requests(selections, trailing_u8: int = 0) -> list[dict]:
    """Pedidos 0x1D03 para os itens encontrados, sem repetir item_index e sem incluir
    itens ausentes (não há detalhe a pedir para eles)."""
    if not isinstance(trailing_u8, int) or isinstance(trailing_u8, bool) or not 0 <= trailing_u8 <= 0xFF:
        raise ValueError("trailing_u8: inteiro 0..0xff")
    seen = set()
    requests = []
    for selection in selections:
        item_index = selection["item_index"]
        server = selection.get("exchange_server_type", trailing_u8)
        key = (server, item_index)
        if not selection["found_in_list"] or key in seen:
            continue
        seen.add(key)
        requests.append({"item_index": item_index, "trailing_u8": server})
    return requests


def select_all(aggregate_entries, products: dict | None = None, sellable: dict | None = None) -> list[dict]:
    """Cria uma seleção por item_index recebido, mantendo nomes conhecidos."""
    products = dict(PRODUCTS) if products is None else products
    grouped = {}
    for entry in aggregate_entries:
        # A lista recebida é a fonte da disponibilidade; o catálogo só fornece nomes.
        grouped.setdefault(entry.get("item_index"), []).append(entry)
    selections = []
    for item_index, entries in grouped.items():
        produto = products.get(item_index) or (sellable or {}).get(item_index, "")
        selections.append({
            "item_index": item_index, "produto": produto, "found_in_list": True,
            "aggregates": entries,
            "registered_items": sum(int(e.get("number_of_registered_items") or 0) for e in entries),
            "lowest_price": min((e["lowest_price"] for e in entries if "lowest_price" in e), default=None),
            "highest_price": max((e["highest_price"] for e in entries if "highest_price" in e), default=None),
            "status": SEM_OFERTAS,
        })
    return selections
