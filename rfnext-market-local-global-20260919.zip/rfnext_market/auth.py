"""Serialização das mensagens de autenticação/entrada (portas 12000 e 12020).

Os mesmos opcodes significam coisas diferentes em cada porta e direção, por isso a
chave de layout é (porta, direção, opcode). Layouts e status: docs/campos-autenticacao.md.

Tipos de campo: "str" = UTF-16LE prefixada por u16 com o número de unidades UTF-16;
"u8"/"u16"/"u32"/"u64" little-endian; ("unk", n) = n bytes desconhecidos preservados;
("unk", None) = bytes desconhecidos até o fim do payload.

Nomes "unknown_@<off>" e inteiros "uNN@<off>" usam o offset da amostra de referência
como rótulo estável; o "offset" em unknown_fields é sempre o offset real no payload.
"""
import struct

from .transport import DIRECTION_C2S, DIRECTION_S2C

C, S = DIRECTION_C2S, DIRECTION_S2C
_INT = {"u8": "<B", "u16": "<H", "u32": "<I", "u64": "<Q"}

# (porta, direção, opcode) -> (nome, status, [(campo, tipo), ...])
LAYOUTS = {
    # --- 12000: layouts do canônico parse_login_session_payload ---
    (12000, C, 0x0101): ("ask_connection", "confirmed", [
        ("account_id", "str"), ("connection_mode", "u16"), ("country_code", "str"),
        ("device_info", "str"), ("auth_jwt", "str"), ("auth_host", "str"),
        ("session_key", "str"), ("joined_country_code", "str"), ("tail_flag", "u8"),
        ("tail_value", "u32"), ("tail_reserved", "u16"), ("mac_address", "str"),
    ]),
    (12000, S, 0x0102): ("ans_connection", "partial", [
        ("result_code", "u16"), ("server_time_ms", "u64"), ("heartbeat_interval_ms", "u32"),
        ("unknown_@14", ("unk", 3)), ("timestamp_b_ms", "u64"), ("f25", "u8"),
        ("unknown_@26", ("unk", 10)), ("country_code", "str"), ("joined_country_code", "str"),
        ("unknown_@48", ("unk", None)),
    ]),
    (12000, C, 0x0103): ("ask_ping", "confirmed", []),
    (12000, S, 0x0104): ("ans_ping", "unparsed", [("unknown_@0", ("unk", None))]),
    (12000, C, 0x0105): ("ask_world_info", "confirmed", []),
    (12000, S, 0x0106): ("ans_world_info", "unparsed", [("unknown_@0", ("unk", None))]),
    (12000, C, 0x0107): ("ask_enter_game", "confirmed", [("world_id", "u16")]),
    (12000, S, 0x0108): ("ans_enter_game", "confirmed", [
        ("result_code", "u16"), ("world_id", "u16"), ("f4", "u16"), ("f6", "u64"),
        ("f14", "u16"), ("game_server_host", "str"), ("game_server_port", "u16"),
    ]),
    (12000, C, 0x010C): ("ask_all_character_infos", "confirmed", [("account_id", "str")]),
    # --- 12020: estrutura derivada da captura; semântica pendente ---
    (12020, C, 0x0101): ("port12020_c2s_0x0101", "unparsed", [("unknown_@0", ("unk", None))]),
    (12020, S, 0x0102): ("port12020_s2c_0x0102", "partial", [
        ("u16@0", "u16"), ("u8@2", "u8"), ("str@3", "str"), ("u16@19", "u16"),
    ]),
    (12020, C, 0x0103): ("port12020_c2s_0x0103", "partial", [
        ("account_id", "str"), ("u8@66", "u8"), ("u32@67", "u32"), ("u32@71", "u32"),
        ("u32@75", "u32"), ("unknown_@79", ("unk", 5)), ("joined_country_code", "str"),
        ("device_info", "str"), ("u64@2688", "u64"), ("unknown_@2696", ("unk", 8)),
        ("auth_host", "str"), ("session_key", "str"), ("unknown_@2834", ("unk", None)),
    ]),
    (12020, S, 0x0104): ("port12020_s2c_0x0104", "partial", [
        ("u16@0", "u16"), ("u64@2", "u64"), ("u16@10", "u16"), ("u64@12", "u64"),
        ("str@20", "str"), ("unknown_@34", ("unk", None)),
    ]),
    (12020, C, 0x0105): ("port12020_c2s_0x0105", "partial", []),
    (12020, S, 0x0106): ("port12020_s2c_0x0106", "unparsed", [("unknown_@0", ("unk", None))]),
}


def _build_key(name, kind):
    return name + "_hex" if isinstance(kind, tuple) else name


REQUIRED_FIELDS = {
    (port, op): tuple(_build_key(n, k) for n, k in spec)
    for (port, direction, op), (_, _, spec) in LAYOUTS.items()
    if direction == C
}


def parse_message(service_port: int, direction: str, opcode: int, payload: bytes) -> dict:
    if direction not in (C, S):
        raise ValueError(f"direction inválida: {direction!r}")
    payload = bytes(payload)
    ctx = f"porta {service_port} {direction} 0x{opcode:04x}"
    name, status, spec = LAYOUTS.get(
        (service_port, direction, opcode),
        (f"unknown_0x{opcode:04x}", "unparsed", [("unknown_@0", ("unk", None))]),
    )
    fields, unknown, cur = {}, [], 0
    for field, kind in spec:
        if isinstance(kind, tuple):
            end = len(payload) if kind[1] is None else cur + kind[1]
            if end > len(payload):
                raise ValueError(f"{ctx}: {field} truncado no offset {cur}")
            unknown.append({"offset": cur, "hex": payload[cur:end].hex(), "name": field})
            cur = end
        elif kind == "str":
            if cur + 2 > len(payload):
                raise ValueError(f"{ctx}: comprimento de {field} truncado no offset {cur}")
            (units,) = struct.unpack_from("<H", payload, cur)
            end = cur + 2 + units * 2
            if end > len(payload):
                raise ValueError(f"{ctx}: {field} truncado ({units} unidades UTF-16 no offset {cur})")
            try:
                fields[field] = payload[cur + 2:end].decode("utf-16le")
            except UnicodeDecodeError:
                raise ValueError(f"{ctx}: UTF-16 inválido em {field}") from None
            cur = end
        else:
            fmt = _INT[kind]
            size = struct.calcsize(fmt)
            if cur + size > len(payload):
                raise ValueError(f"{ctx}: {field} truncado no offset {cur}")
            (fields[field],) = struct.unpack_from(fmt, payload, cur)
            cur += size
    if cur != len(payload):
        raise ValueError(f"{ctx}: {len(payload) - cur} bytes sobrando no offset {cur}")
    return {"service_port": service_port, "direction": direction, "opcode": opcode,
            "name": name, "fields": fields, "unknown_fields": unknown, "status": status}


def build_payload(service_port: int, opcode: int, fields: dict) -> bytes:
    entry = LAYOUTS.get((service_port, C, opcode))
    if entry is None:
        raise ValueError(f"build não suportado: porta {service_port} 0x{opcode:04x}")
    ctx = f"porta {service_port} 0x{opcode:04x}"
    out = bytearray()
    for name, kind in entry[2]:
        key = _build_key(name, kind)
        if key not in fields:
            raise ValueError(f"{ctx}: campo obrigatório ausente: {key}")
        value = fields[key]
        if isinstance(kind, tuple):
            try:
                raw = bytes.fromhex(value)
            except (TypeError, ValueError):
                raise ValueError(f"{ctx}: {key} precisa ser hex") from None
            if kind[1] is not None and len(raw) != kind[1]:
                raise ValueError(f"{ctx}: {key} precisa ter {kind[1]} bytes")
            out += raw
        elif kind == "str":
            if not isinstance(value, str):
                raise ValueError(f"{ctx}: {key} precisa ser str")
            try:
                raw = value.encode("utf-16le")
            except UnicodeEncodeError:
                raise ValueError(f"{ctx}: {key} não codificável em UTF-16") from None
            if len(raw) // 2 > 0xFFFF:
                raise ValueError(f"{ctx}: {key} excede 65535 unidades UTF-16")
            out += struct.pack("<H", len(raw) // 2) + raw
        else:
            fmt = _INT[kind]
            limit = 1 << (8 * struct.calcsize(fmt))
            if type(value) is not int or not 0 <= value < limit:
                raise ValueError(f"{ctx}: {key} precisa ser inteiro em 0..{limit - 1}")
            out += struct.pack(fmt, value)
    return bytes(out)
