"""Gera session.json/config.json a partir de um dump JSON de captura."""
import argparse, json
from pathlib import Path

from rfnext_market import auth, selection, transport


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dump", type=Path)
    ap.add_argument("--auth-host", required=True)
    ap.add_argument("--game-host", required=True)
    ap.add_argument("--world-id", type=int, default=1)
    ap.add_argument("--output-dir", type=Path, default=Path("."))
    args = ap.parse_args()
    data = json.loads(args.dump.read_text(encoding="utf-8"))
    records = data.get("records", [])
    login = next((r.get("authentication") for r in records if r.get("authentication")), None)
    if not login:
        raise SystemExit("dump não contém autenticação 12000/0x0101")
    session = dict(login)
    login_frame = next((r for r in records if r.get("port") == 12000 and r.get("opcode") == "0x0101"), None)
    if login_frame and login_frame.get("decoded_hex"):
        parsed = auth.parse_message(12000, transport.DIRECTION_C2S, 0x0101,
                                    bytes.fromhex(login_frame["decoded_hex"])[6:])
        session.update(parsed["fields"])
        session.update({u["name"] + "_hex": u["hex"] for u in parsed["unknown_fields"]})
    if isinstance(session.get("device_info"), dict):
        session["device_info"] = json.dumps(session["device_info"], ensure_ascii=False, separators=(",", ":"))
    game = next((r for r in records if r.get("port") == 12020 and r.get("opcode") == "0x0103"), None)
    if game:
        parsed = auth.parse_message(12020, transport.DIRECTION_C2S, 0x0103, bytes.fromhex(game["decoded_hex"])[6:])
        session.update(parsed["fields"])
        session.update({u["name"] + "_hex": u["hex"] for u in parsed["unknown_fields"]})
        if isinstance(session.get("device_info"), dict):
            session["device_info"] = json.dumps(session["device_info"], ensure_ascii=False, separators=(",", ":"))
    short_game = next((r for r in records if r.get("port") == 12020 and r.get("opcode") == "0x0101"), None)
    if short_game and short_game.get("decoded_hex"):
        parsed = auth.parse_message(12020, transport.DIRECTION_C2S, 0x0101,
                                    bytes.fromhex(short_game["decoded_hex"])[6:])
        session.update({u["name"] + "_hex": u["hex"] for u in parsed["unknown_fields"]})
    # Campo dependente da sessão atual; nunca reutilizar o valor da captura.
    session.pop("u64@2688", None)
    out = args.output_dir.resolve(); out.mkdir(parents=True, exist_ok=True)
    (out / "session.json").write_text(json.dumps(session, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    config = {
        "auth": {"host": args.auth_host, "port": 12000, "timeout": 10.0},
        "game": {"host": args.game_host, "port": 12020, "timeout": 10.0},
        "world_id": args.world_id,
        "session_file": "session.json",
        "market": {"list_requests": [{"payload_hex": "0000"}], "detail_requests": [],
                   "trailing_u8": 0, "both_markets": True, "detail_all_items": True,
                   "products": dict(selection.PRODUCTS),
                   "response_timeout": 10.0},
    }
    (out / "config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"gerados: {out / 'session.json'} e {out / 'config.json'}")


if __name__ == "__main__":
    main()
