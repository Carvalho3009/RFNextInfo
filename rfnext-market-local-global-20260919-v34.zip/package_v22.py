from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import sys

root = Path(__file__).parent
channel = root.parent / 'publication/client-channel'
version = int(sys.argv[1])
name = f'rfnext-market-local-global-20260919-v{version}.zip'
updated = {p.relative_to(root).as_posix() for folder in ('rfnext_market', 'tests')
           for p in (root/folder).iterdir() if p.suffix in ('.py', '.json')}
updated.update({'package_v22.py', f'LEIA-ME-v{version}.md', f'VALIDACAO-v{version}.md'})
with ZipFile(channel/f'rfnext-market-local-global-20260919-v{version-1}.zip') as old, ZipFile(channel/name,'w',ZIP_DEFLATED) as new:
    for entry in old.infolist():
        if '__pycache__' in entry.filename or entry.filename.endswith('.pyc') or entry.filename in updated:
            continue
        new.writestr(entry.filename,old.read(entry))
    for path in sorted(updated):
        new.write(root/path,path)
with ZipFile(channel/name) as archive:
    assert archive.testzip() is None
    for path in updated:
        assert archive.read(path)==(root/path).read_bytes(),path
checksum=hashlib.sha256((channel/name).read_bytes()).hexdigest()
checks=channel/'SHA256SUMS.txt'
lines=[s for s in checks.read_text(encoding='utf-8').splitlines() if not s.endswith('  '+name)]
checks.write_text('\n'.join(lines+[checksum+'  '+name])+'\n',encoding='utf-8')
print(name,checksum)
