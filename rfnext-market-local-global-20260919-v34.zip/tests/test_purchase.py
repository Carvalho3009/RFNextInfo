import struct
import threading
import unittest
from unittest.mock import Mock, patch

from rfnext_market import purchase, session, desktop
from tests import test_session as helper

REQUEST = dict(exchange_server_type=0, exchange_index=0x555A0D11550A9143,
               pc_id=0x555A0D114A4D048D, selling_price=231, item_index=1002, enchant_level=0)
PAYLOAD = "00010043910a55110d5a558d044d4a110d5a55e700000000000000ea0300000000"


def response(ret=0, uid=None):
    offer = struct.pack("<QQQ", REQUEST["exchange_index"], 0, uid or REQUEST["pc_id"])
    offer += struct.pack("<QIQBHHHBQ", 1, 1002, 1, 0, 0, 0, 0, 0, 0)
    offer += struct.pack("<QQQQQB", 0, 0, 0, 231, 0, 0)
    return struct.pack("<HBHH", 0, 0, 1, ret) + offer


class PurchaseTest(unittest.TestCase):
    def test_capture_bytes_and_validation(self):
        self.assertEqual(purchase.build(REQUEST).hex(), PAYLOAD)
        self.assertEqual(purchase.parse(0x1D12,bytes.fromhex(PAYLOAD))["fields"],REQUEST)
        for key in purchase.FIELDS:
            for bad in (-1, True, 2**64):
                with self.subTest(key=key,bad=bad), self.assertRaises(ValueError):
                    purchase.build(dict(REQUEST, **{key:bad}))

    def test_confirm_reject_mismatch_and_timeout_send_once(self):
        for answer, expected in ((response(),"confirmed"),(response(7),"rejected"),
                                 (response(uid=123),"unconfirmed"),(b"bad","unconfirmed"),
                                 (TimeoutError("timeout"),"unconfirmed")):
            link, wait = Mock(), Mock()
            if isinstance(answer, Exception): wait.side_effect=answer
            else: wait.return_value=({"payload":answer},None)
            result=purchase.execute(link,REQUEST,wait,Mock(),threading.Event(),1)
            self.assertEqual(result["status"],expected)
            link.send.assert_called_once_with(0x1D12,bytes.fromhex(PAYLOAD))
        stop=threading.Event();stop.set();link=Mock()
        self.assertEqual(purchase.execute(link,REQUEST,Mock(),Mock(),stop,1)["status"],"cancelled")
        link.send.assert_not_called()

    def test_authenticated_session_purchase_does_not_query_market_or_rank(self):
        runner=helper.SessionTest()
        cfg=helper.config();cfg["manual_purchase"]=REQUEST
        result=runner.run_session(cfg=cfg,game_s=helper.game_script({0x1D12:[[(0x1D13,response())]]}))
        self.assertEqual(result["status"],"confirmed",result)
        self.assertEqual(runner.sent_ops(12020),[0x0101,0x0103,0x0105,0x1D12])
        self.assertTrue(all(c.closed for c in runner.conns.values()))

    def test_cancelled_confirmation_does_not_start_session(self):
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app._closing=False;app.mode_threads={};app.worker=None;app.heartbeat_service=None
        app.root=Mock();app._validate_config=Mock(return_value={});app._current_config=Mock(return_value={})
        with patch.object(desktop,"PurchaseDialog",return_value=Mock(result=REQUEST)), patch.object(
                desktop.messagebox,"askyesno",return_value=False), patch.object(session,"run") as run:
            app._start_purchase()
            run.assert_not_called()

    def test_confirmed_button_uses_purchase_worker_without_upload(self):
        import queue
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app._closing=False;app.mode_threads={};app.worker=None;app.heartbeat_service=None
        app.root=Mock();app._validate_config=Mock(return_value={});app._current_config=Mock(return_value={})
        app._control_queue=queue.Queue();app._observe=Mock();app.purchase_button=Mock();app.status=Mock()
        app.mode_results={}
        with patch.object(desktop,"PurchaseDialog",return_value=Mock(result=REQUEST)), patch.object(
                desktop.messagebox,"askyesno",return_value=True), patch.object(session,"run",
                return_value={"status":"unconfirmed","diagnostic":"timeout"}) as run, patch.object(
                desktop.upload,"submit_result") as upload:
            app._start_purchase();app.worker.join(2)
            self.assertFalse(app.worker.is_alive())
            cfg=run.call_args.args[0]
            self.assertEqual(cfg["manual_purchase"],REQUEST)
            self.assertTrue(cfg["initialize_character"])
            self.assertTrue(cfg["heartbeat"]["enabled"])
            upload.assert_not_called()
            app._handle_event(app._control_queue.get_nowait())
            self.assertFalse(app.purchase_running)
            self.assertEqual(app.mode_results["purchase"]["status"],"unconfirmed")
