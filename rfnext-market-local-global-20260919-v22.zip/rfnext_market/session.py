"""Máquina de estados da sessão: 12000 (login/entrada) -> 12020 (entrada no jogo) -> consultas de mercado.

Sem sleeps: esperas usam prazos em time.monotonic e o timeout de Connection.receive.
Envios restritos a ALLOWED_SENDS (inicialização, manutenção e consulta implementadas).

Serviço lógico vem da seção da configuração ("auth" -> 12000, "game" -> 12020), não do
número de porta real; conn.service_port fica só como metadado do dump.

Credenciais (config["credentials"], lidas do session_file): chaves de nível superior valem
para todas as mensagens; subdicionários "12000_0x0101" e "12020_0x0103" sobrepõem por
mensagem (ex.: device_info da 12020 difere do da 12000 na captura). Derivados em tempo de
execução, não exigidos no session_file: world_id (config) e u64@2688 do 12020 0x0103
(= 12000 S 0x0108 payload[4:12]; igualdade de bytes observada, função não confirmada).
"""
from __future__ import annotations

import secrets
import inspect
import time
import struct
from datetime import datetime, timezone

from . import auth, dump, market, protocol, report, selection, rankings, character
from .transport import CancelledError, DIRECTION_C2S, DIRECTION_S2C, Connection

SERVICES = {"auth": 12000, "game": 12020}
DERIVED_FIELDS = ("world_id", "u64@2688")

ALLOWED_SENDS = {
    12000: {0x0101, 0x0103, 0x0105, 0x0107},
    12020: {0x0101, 0x0103, 0x0105, 0x0205, 0x1D01, 0x1D03, 0x1A01, 0x1A03, 0x2408, 0x240A, 0x0201},
}

UNCONFIRMED = [
    "vínculo 12000<->12020: quais campos (session_key, f6 do 0x0108, account_id) autenticam o 0x0103 da 12020",
    "fechar 12000 antes de abrir 12020: observado na captura (último dado 12000 ~1,4 s antes), sem FIN confirmado",
    "coexistência das conexões 12000 e 12020 não testada",
    "0x0102 da 12000: result_code==0 tratado como aceitação; demais códigos não catalogados",
    "0x010C (12000) e 0x0105 periódico (12000) do cliente oficial não são enviados",
    "0x0104 da 12020 é candidata a resposta de autenticação; layout sem campo de retorno confirmado",
    "necessidade de 0x0201 e das demais mensagens enviadas pelo cliente oficial antes do mercado (não enviadas)",
    "manutenção na 12020 (0x0205/0x0206 candidatas) não implementada; esperas limitadas por timeout",
    "0x1D01: significado dos 2 bytes; fim da consulta assumido no primeiro 0x1D02 com is_end=1 ou ret!=0",
    "mercado global: trailing_u8=1 nos detalhes ainda é hipótese; lista 0100 confirmada na captura 20260919-163618",
    "0x1D1E não enviado; função não confirmada",
    "host/porta de 0x0108 não usados: 12020 vem da configuração",
    "u64@2688 do 12020 0x0103 = 12000 0x0108 payload[4:12]: igualdade de bytes observada, função não confirmada",
]


class _Stop(Exception):
    """Encerra a máquina de estados com (status, diagnostic)."""

    def __init__(self, status, diagnostic, timeout=False, disconnected=False):
        super().__init__(diagnostic)
        self.status = status
        self.diagnostic = diagnostic
        self.timeout = timeout
        self.disconnected = disconnected


class _Link:
    """Uma conexão com contadores de sequência por direção."""

    def __init__(self, conn, emit, service, state=None):
        self.conn = conn
        self.port = service  # serviço lógico (12000/12020), não a porta real
        self.emit = emit
        self.state = state if state is not None else {"stage": "?"}
        self.send_seq = 0
        self.recv_seq = 0
        self.beat_s = None     # intervalo de 0x0103 (12000), definido após 0x0102
        self.next_beat = None  # prazo do próximo 0x0103, a partir do último enviado

    def send(self, opcode, payload):
        if opcode not in ALLOWED_SENDS.get(self.port, ()):
            raise _Stop("failed", f"envio não permitido: serviço {self.port} 0x{opcode:04x}")
        wire = protocol.encode_frame(opcode, payload, self.send_seq, seed=secrets.randbelow(0x40))
        self.send_seq = (self.send_seq + 1) & 0xFF
        try:
            stop_event = self.state.get("stop_event")
            parameters = inspect.signature(self.conn.send).parameters
            if stop_event is not None and ("stop_event" in parameters or any(
                    p.kind is inspect.Parameter.VAR_KEYWORD for p in parameters.values())):
                self.conn.send(wire, stop_event=stop_event)
            else:
                self.conn.send(wire)
        except CancelledError:
            raise _Stop("cancelled", "execução cancelada pelo usuário") from None
        except OSError as exc:  # inclui BrokenPipeError, ConnectionError, TimeoutError
            raise _Stop("failed", f"{self.state['stage']}: envio 0x{opcode:04x} falhou: "
                                  f"{type(exc).__name__}: {exc}", disconnected=True) from None
        frame = protocol.decode_frame(wire)
        self.emit(dump.make_frame_record(self.conn, DIRECTION_C2S, wire, frame, _parse(self.port, DIRECTION_C2S, frame)))

    def receive(self):
        """Um quadro S->C já registrado. Devolve (frame, parsed|None)."""
        try:
            parameters = inspect.signature(self.conn.receive).parameters
            if "stop_event" in parameters:
                wire = self.conn.receive(stop_event=self.state.get("stop_event"))
            else:
                wire = self.conn.receive()
            frame = protocol.decode_frame(wire)
        except (TimeoutError, ConnectionError, CancelledError):
            raise
        except (ValueError, OSError) as exc:
            raise _Stop("failed", f"{self.state['stage']}: recepção inválida: "
                                  f"{type(exc).__name__}: {exc}") from None
        if frame["sequence"] != self.recv_seq:
            self.emit({"record_type": "diagnostic", "connection_id": self.conn.connection_id,
                       "message": f"sequência S->C {frame['sequence']} (esperada {self.recv_seq})"})
        self.recv_seq = (frame["sequence"] + 1) & 0xFF
        try:
            parsed = _parse(self.port, DIRECTION_S2C, frame)
        except ValueError as exc:
            parsed = None
            self.emit({"record_type": "diagnostic", "connection_id": self.conn.connection_id,
                       "message": f"parse 0x{frame['opcode']:04x}: {exc}"})
        self.emit(dump.make_frame_record(self.conn, DIRECTION_S2C, wire, frame, parsed))
        return frame, parsed


def _parse(port, direction, frame):
    if port == 12020 and frame["opcode"] in (0x0201, 0x0202):
        return character.parse_message(frame["opcode"], frame["payload"])
    if port == 12020 and frame["opcode"] in rankings.OPCODES:
        return rankings.parse_message(frame["opcode"], frame["payload"])
    if port == 12020 and frame["opcode"] >> 8 == 0x1D:
        return market.parse_message(frame["opcode"], frame["payload"])
    return auth.parse_message(port, direction, frame["opcode"], frame["payload"])


def _build(port, opcode, fields, stage):
    try:
        if opcode >> 8 == 0x1D:
            return market.build_payload(opcode, fields)
        return auth.build_payload(port, opcode, fields)
    except ValueError as exc:
        raise _Stop("incomplete", f"{stage}: {exc}") from None


def _heartbeat_payload(now=None, constant=0, flag=0):
    """0x0205 observado: flag + contador de dois segundos (experimental)."""
    now = time.time() if now is None else now
    counter = (int(now // 2) + int(constant)) & 0xffffffff
    return bytes((int(flag) & 1,)) + struct.pack("<I", counter)


def _await(link, opcode, timeout, stage, heartbeat=False, on_frame=None, stop_event=None):
    """Recebe até `opcode` (ou on_frame devolver True). Assíncronas só são registradas.

    Com heartbeat e link.beat_s, envia 0x0103 quando link.next_beat vence; o timeout do
    socket é limitado ao próximo prazo (heartbeat ou deadline) para acordar a tempo.
    ponytail: ajusta Connection._sock diretamente; receive(timeout=) no transporte evitaria isso.
    """
    deadline = time.monotonic() + timeout
    beat = heartbeat and link.beat_s
    sock = getattr(link.conn, "_sock", None)
    base_timeout = sock.gettimeout() if sock is not None else None
    try:
        while True:
            if stop_event is not None and stop_event.is_set():
                raise _Stop("cancelled", "execução cancelada pelo usuário")
            now = time.monotonic()
            if beat and now >= link.next_beat:
                link.send(0x0103, b"")
                link.next_beat = now + link.beat_s
            if now >= deadline:
                raise _Stop("failed", f"{stage}: timeout aguardando 0x{opcode:04x}", timeout=True)
            if sock is not None and base_timeout is not None:
                wake = min(deadline, link.next_beat) if beat else deadline
                if stop_event is not None:
                    wake = min(wake, now + 0.2)
                sock.settimeout(max(0.001, min(base_timeout, wake - now)))
            try:
                frame, parsed = link.receive()
            except CancelledError:
                raise _Stop("cancelled", "execução cancelada pelo usuário") from None
            except TimeoutError:
                continue
            except ConnectionError as exc:
                raise _Stop("failed", f"{stage}: desconexão: {exc}", disconnected=True) from None
            if on_frame is not None:
                if on_frame(frame, parsed):
                    return frame, parsed
            elif frame["opcode"] == opcode:
                if parsed is None:
                    raise _Stop("incomplete", f"{stage}: 0x{opcode:04x} não interpretado")
                return frame, parsed
    finally:
        if sock is not None and base_timeout is not None:
            try:
                sock.settimeout(base_timeout)
            except OSError:
                pass


def _require_ok(parsed, stage):
    code = parsed["fields"].get("result_code")
    if code != 0:
        raise _Stop("failed", f"{stage}: rejeitado result_code={code}")
    return parsed


def run(config: dict, emit, stop_event=None, on_collected=None) -> dict:
    """Entrega a coleta pronta e, com callback, aguarda desconexão sem refazer login."""
    if on_collected is not None and stop_event is None:
        raise ValueError("manter conexão aberta exige stop_event")
    links = []
    try:
        result = _collect(config, emit, stop_event, links)
        if on_collected is None or result["status"] != "completed":
            return result
        game = links[-1]
        result["connection"] = {"status": "open"}
        sock = getattr(game.conn, "_sock", None)
        if sock is not None:
            sock.settimeout(0.2)
        emit({"record_type": "connection", "status": "open",
              "message": "Coleta concluída; conexão aberta. Parar desconecta."})
        on_collected(result)
        try:
            while not stop_event.is_set():
                try:
                    if config.get("heartbeat_only"):
                        heartbeat_cfg = config.get("heartbeat", {})
                        payload = _heartbeat_payload(constant=heartbeat_cfg.get("constant", 0),
                                                     flag=heartbeat_cfg.get("flag", 0))
                        game.send(0x0205, payload)
                        _await(game, 0x0206, min(3.0, config["game"]["timeout"]),
                               "heartbeat", stop_event=stop_event)
                        emit({"record_type": "heartbeat", "status": "confirmed",
                              "payload_hex": payload.hex()})
                        if stop_event.wait(2.5):
                            break
                    else:
                        game.receive()
                except TimeoutError:
                    continue
            reason = "desconexão solicitada"
        except CancelledError:
            reason = "desconexão solicitada"
        except (ConnectionError, _Stop) as exc:
            reason = f"conexão encerrada: {exc}"
        result["connection"] = {"status": "closed", "reason": reason}
        emit({"record_type": "connection", **result["connection"], "message": reason})
        return result
    finally:
        for link in links:
            link.conn.close()


def _collect(config: dict, emit, stop_event, links) -> dict:
    state = {"stage": "init", "authenticated": None, "stop_event": stop_event}
    acc = market.MarketAccumulator()
    frames: list[dict] = []
    _emit = emit

    def emit(record, _emit=_emit):
        """Registra o quadro no dump e guarda um resumo para o campo `frames` do contrato."""
        if record.get("record_type") == "frame" and not state.get("collection_complete"):
            frames.append({k: record[k] for k in (
                "connection_id", "service_port", "direction", "timestamp", "opcode",
                "sequence", "wire_length", "decoded_length", "decoded_sha256") if k in record})
        return _emit(record)
    credentials = config.get("credentials", {})
    derived = {"world_id": config["world_id"]}

    def fields_for(port, opcode):
        out = {k: v for k, v in credentials.items() if not isinstance(v, dict)}
        out.update(credentials.get(f"{port}_0x{opcode:04x}", {}))
        out.update(derived)
        return out

    def check_cancel():
        if stop_event is not None and stop_event.is_set():
            raise _Stop("cancelled", "execução cancelada pelo usuário")

    if config.get("initialize_character", False):
        character.template(credentials)  # validar antes de abrir conexão
    rank_results = {}
    status, diagnostic = "completed", ""
    # Mapa de produtos validado antes de qualquer socket. A seleção só passa a existir
    # quando há consulta de lista configurada (sem 0x1D02 não há o que selecionar).
    products = {}
    sellable = None
    selections: list[dict] = []
    query_errors: list[dict] = []
    requested: set[tuple] = set()

    def connect(section):
        cfg = config[section]
        check_cancel()
        try:
            params = inspect.signature(Connection).parameters
            if stop_event is not None and ("stop_event" in params or any(
                    p.kind is inspect.Parameter.VAR_KEYWORD for p in params.values())):
                conn = Connection(cfg["host"], cfg["port"], cfg["timeout"], stop_event=stop_event)
            else:
                conn = Connection(cfg["host"], cfg["port"], cfg["timeout"])
            link = _Link(conn, emit, SERVICES[section], state)
        except CancelledError:
            raise _Stop("cancelled", "execução cancelada pelo usuário") from None
        except (ConnectionError, TimeoutError, OSError) as exc:
            raise _Stop("failed", f"{state['stage']}: conexão falhou: {type(exc).__name__}") from None
        links.append(link)
        return link

    try:
        check_cancel()
        products = selection.load_products(config.get("market"))
        db_path = config.get("market", {}).get("item_database")
        if db_path:
            sellable = selection.load_sellable_database(db_path)
        # --- 12000 ---
        state["stage"] = "12000:connect"
        a = connect("auth")
        t = config["auth"]["timeout"]
        state["stage"] = "12000:0x0101"
        check_cancel()
        a.send(0x0101, _build(12000, 0x0101, fields_for(12000, 0x0101), state["stage"]))
        _, ans = _await(a, 0x0102, t, state["stage"], stop_event=stop_event)
        _require_ok(ans, state["stage"])
        beat = ans["fields"].get("heartbeat_interval_ms")
        if beat:
            a.beat_s = beat / 1000
            a.next_beat = time.monotonic() + a.beat_s
        state["stage"] = "12000:0x0105"
        check_cancel()
        a.send(0x0105, _build(12000, 0x0105, fields_for(12000, 0x0105), state["stage"]))
        _await(a, 0x0106, t, state["stage"], heartbeat=True, stop_event=stop_event)
        state["stage"] = "12000:0x0107"
        check_cancel()
        a.send(0x0107, _build(12000, 0x0107, fields_for(12000, 0x0107), state["stage"]))
        _, enter = _await(a, 0x0108, t, state["stage"], heartbeat=True, stop_event=stop_event)
        _require_ok(enter, state["stage"])
        ef = enter["fields"]
        link_value = (ef["f4"] | (ef["f6"] << 16)) & 0xFFFFFFFFFFFFFFFF  # payload[4:12] do 0x0108
        supplied = fields_for(12020, 0x0103).get("u64@2688")
        if supplied is not None and supplied != link_value:
            raise _Stop("failed", f"{state['stage']}: u64@2688 do session_file ({supplied!r}) difere do "
                                  f"derivado de 0x0108 payload[4:12] ({link_value:#x})")
        derived["u64@2688"] = link_value
        # Observado na captura (não confirmado): 12000 encerra antes de a 12020 abrir.
        a.conn.close()

        # --- 12020 ---
        state["stage"] = "12020:connect"
        g = connect("game")
        t = config["game"]["timeout"]
        for send_op, recv_op in ((0x0101, 0x0102), (0x0103, 0x0104), (0x0105, 0x0106)):
            state["stage"] = f"12020:0x{send_op:04x}"
            check_cancel()
            g.send(send_op, _build(12020, send_op, fields_for(12020, send_op), state["stage"]))
            _, parsed = _await(g, recv_op, t, state["stage"], stop_event=stop_event)
            if recv_op == 0x0104:
                character_handle = parsed["fields"]["u64@2"]
            ret = parsed["fields"].get("ret", parsed["fields"].get("result_code"))
            if recv_op == 0x0104 and parsed["status"] == "confirmed" and ret is not None:
                state["authenticated"] = ret == 0
                if ret != 0:
                    raise _Stop("failed", f"{state['stage']}: rejeitado ret={ret}")

        def reconnect_game():
            """Reconecta somente o canal de mercado após fechamento isolado."""
            nonlocal g
            try:
                g.conn.close()
            except OSError:
                pass
            g = connect("game")
            t_reconnect = config["game"]["timeout"]
            for send_op, recv_op in ((0x0101, 0x0102), (0x0103, 0x0104), (0x0105, 0x0106)):
                state["stage"] = f"12020:reconnect:0x{send_op:04x}"
                g.send(send_op, _build(12020, send_op, fields_for(12020, send_op), state["stage"]))
                _, parsed = _await(g, recv_op, t_reconnect, state["stage"], stop_event=stop_event)
                if recv_op == 0x0104 and parsed["fields"].get("ret", parsed["fields"].get("result_code")) not in (None, 0):
                    raise _Stop("failed", f"{state['stage']}: reconexão rejeitada")

        if config.get("initialize_character", False):
            state["stage"] = "12020:0x0201"
            payload, selected_uid = character.build(credentials, character_handle, derived["u64@2688"])
            g.send(0x0201, payload)
            _, answer = _await(g, 0x0202, t, state["stage"], stop_event=stop_event)
            fields = answer["fields"]
            if fields["result_code"] != 0 or fields["character_uid"] != selected_uid:
                raise _Stop("failed", "0x0202: inicialização rejeitada ou personagem divergente")
            emit({"record_type": "character_initialized", "status": "completed", "character_uid": selected_uid})

        # O cliente só mantém o heartbeat depois de entrar com o personagem.
        heartbeat_cfg = config.get("heartbeat", {})
        if heartbeat_cfg.get("enabled", False):
            state["stage"] = "12020:0x0205"
            payload = _heartbeat_payload(constant=heartbeat_cfg.get("constant", 0),
                                         flag=heartbeat_cfg.get("flag", 0))
            g.send(0x0205, payload)
            _await(g, 0x0206, t, state["stage"], stop_event=stop_event)
            emit({"record_type": "heartbeat", "status": "confirmed",
                  "payload_hex": payload.hex()})

        if config.get("heartbeat_only"):
            state["stage"] = "heartbeat"
            state["collection_complete"] = True
            result = {"status": "completed", "stage": "heartbeat", "diagnostic": "",
                      "authenticated": state["authenticated"], "items": [], "offers": [],
                      "errors": [], "frames": frames, "market": {}, "rankings": {},
                      "unconfirmed": list(UNCONFIRMED)}
            emit({"record_type": "completion", "status": "completed", "stage": "heartbeat",
                  "diagnostic": "", "authenticated": state["authenticated"],
                  "items": 0, "offers": 0, "errors": [], "frames": len(frames),
                  "unconfirmed": list(UNCONFIRMED)})
            return result

        if config.get("rankings_only"):
            config = dict(config, market=dict(config.get("market", {}), list_requests=[],
                          detail_requests=[], both_markets=False, detail_all_items=False))

        # --- mercado ---
        market_cfg = config.get("market", {})
        rt = market_cfg["response_timeout"]

        def run_query(qid, send_op, recv_op, request, fatal, item_index=None, retry=True):
            """Envia uma consulta e acumula até is_end. Devolve None em sucesso ou o _Stop
            registrado quando `fatal` é falso (erro por item, não da sessão inteira)."""
            state["stage"] = f"market:{qid}"
            check_cancel()
            payload = _build(12020, send_op, request, state["stage"])
            acc.begin_query(qid, request)

            def on_frame(frame, parsed):
                if frame["opcode"] != recv_op:
                    return False
                if parsed is None:
                    raise _Stop("incomplete", f"market:{qid}: 0x{recv_op:04x} não interpretado")
                try:
                    acc.accept(dict(parsed, query_id=qid))
                except ValueError as exc:
                    raise _Stop("incomplete", f"market:{qid}: {exc}") from None
                f = parsed["fields"]
                if f.get("ret") != 0:
                    raise _Stop("failed", f"market:{qid}: servidor rejeitou ret={f['ret']}")
                return bool(f.get("is_end"))

            try:
                g.send(send_op, payload)
                _await(g, recv_op, rt, state["stage"], on_frame=on_frame, stop_event=stop_event)
                return None
            except _Stop as stop:
                # Timeout e rejeição do servidor (ret != 0) viram erro do item quando a
                # consulta não é fatal; violação de protocolo (status "incomplete":
                # quadro não interpretado, item_index divergente) sempre encerra a sessão.
                if not stop.timeout and (fatal or stop.status != "failed"):
                    raise
                query_errors.append({"query_id": qid, "stage": state["stage"],
                                     "exchange_server_type": request.get("exchange_server_type"),
                                     "item_index": item_index, "error": stop.diagnostic})
                emit({"record_type": "diagnostic", "stage": state["stage"], "message": stop.diagnostic})
                if stop.disconnected:
                    emit({"record_type": "connection", "status": "reconnecting",
                          "message": "Conexão encerrada; autenticando novo canal antes do próximo detalhe."})
                    reconnect_game()
                    emit({"record_type": "connection", "status": "reconnected",
                          "message": "Novo canal autenticado; continuando detalhes."})
                    if retry:
                        emit({"record_type": "diagnostic", "stage": state["stage"],
                              "message": "Repetindo consulta após reconexão."})
                        return run_query(qid, send_op, recv_op, request, fatal, item_index, retry=False)
                return stop

        aborted = False
        # 1) lista de mercado (0x1D01 -> 0x1D02); ret != 0 encerra a sessão. Os produtos
        # pedidos já entram no resumo aqui, para constarem mesmo se a lista falhar.
        list_requests = market_cfg.get("list_requests") or []
        # Preserva consultas manuais; a coleta completa padrão inclui os dois mercados.
        default_both = (market_cfg.get("detail_all_items", False)
                        and list_requests == [{"payload_hex": "0000"}]
                        and not market_cfg.get("detail_requests"))
        if market_cfg.get("both_markets", default_both):
            list_requests = [{"payload_hex": "0000", "exchange_server_type": 0},
                             {"payload_hex": "0100", "exchange_server_type": 1}]
        if list_requests:
            selections = selection.select([], products)
        for i, request in enumerate(list_requests):
            if run_query(f"list-{i}", 0x1D01, 0x1D02, request, True) is not None:
                aborted = True  # timeout: sem correlação confirmada, não reutilizar a conexão
                break

        # 2) seleção (Agente 3) a partir dos agregados já recebidos.
        if list_requests:
            grouped = {}
            for q in acc.snapshot()["queries"]:
                if q["kind"] == "aggregate":
                    grouped.setdefault(q["exchange_server_type"], []).extend(q["entries"])
            selections = []
            for server, aggregates in grouped.items():
                selected = (selection.select_all(aggregates, products, sellable)
                            if market_cfg.get("detail_all_items") else selection.select(aggregates, products))
                selections.extend(dict(s, exchange_server_type=server) for s in selected)
        override = market_cfg.get("detail_requests") or []
        if override:
            requests, seen = [], set()
            for request in override:
                key = (request.get("trailing_u8"), request["item_index"])
                if key not in seen:
                    seen.add(key)
                    requests.append(request)
        else:
            requests = selection.detail_requests(selections, market_cfg.get("trailing_u8", 0))

        # Item pedido à mão e fora do mapa de produtos entra no resumo sem nome (nomes
        # nunca são inferidos a partir do ID), para não descartar suas ofertas.
        known = {(s.get("exchange_server_type", 0), s["item_index"]) for s in selections}
        for request in requests:
            key = (request.get("trailing_u8"), request["item_index"])
            if key not in known:
                known.add(key)
                selections.append({
                    "exchange_server_type": request.get("trailing_u8"),
                    "item_index": request["item_index"], "produto": "", "found_in_list": True,
                    "aggregates": [], "registered_items": 0, "lowest_price": None,
                    "highest_price": None, "status": selection.SEM_OFERTAS})

        # 3) detalhes (0x1D03 -> 0x1D04), um item por consulta, sem repetir item_index.
        requested = set()
        total_details = len(requests)
        for i, request in enumerate(requests):
            if aborted:
                break
            request = dict(request, exchange_server_type=request.get("trailing_u8"))
            requested.add((request["exchange_server_type"], request["item_index"]))
            stop = run_query(f"detail-{i}", 0x1D03, 0x1D04, request, False, request["item_index"])
            emit({"record_type": "progress", "stage": "market:details",
                  "completed": i + 1, "total": total_details,
                  "item_index": request["item_index"],
                  "exchange_server_type": request["exchange_server_type"],
                  "status": "error" if stop is not None else "completed"})
            if stop is not None and stop.timeout:
                aborted = True

        # Falha isolada de detalhe não impede os rankings; somente uma lista abortada
        # deixa a sessão sem base suficiente para continuar.
        if not aborted and config.get("rankings", False):
            for name, send_op, recv_op, payload in rankings.REQUESTS:
                state["stage"] = f"rankings:{name}"
                check_cancel()
                try:
                    if name == "exp":
                        g.send(0x1A03, b"")
                    elif name == "accretia":
                        g.send(0x2408, b"")
                    g.send(send_op, payload)
                    def accept_rank(frame, parsed):
                        if frame["opcode"] != recv_op:
                            return False
                        if parsed is None:
                            raise _Stop("incomplete", "resposta de ranking não interpretada")
                        f = parsed["fields"]
                        return name == "exp" or (f["faction_id_raw"] == payload[0]
                                                  and f["rank_variant_raw"] == 0)
                    _, parsed = _await(g, recv_op, rt, state["stage"],
                                       on_frame=accept_rank, stop_event=stop_event)
                    fields = parsed["fields"]
                    rank_results[name] = dict(fields, status="received",
                                              captured_at=datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))
                    complete = rankings.validate(fields, name)
                    rank_results[name]["status"] = "completed" if complete else "incomplete"
                    emit(dict(rank_results[name], record_type="ranking_result", ranking=name))
                    emit({"record_type": "progress", "stage": "rankings",
                          "completed": len(rank_results), "total": 4, "ranking": name})
                except (ValueError, _Stop) as exc:
                    if isinstance(exc, _Stop) and exc.status == "cancelled":
                        raise
                    rank_results[name] = dict(rank_results.get(name, {}), status="failed", diagnostic=str(exc))
                    emit(dict(rank_results[name], record_type="ranking_result", ranking=name))
                    emit({"record_type": "progress", "stage": "rankings",
                          "completed": len(rank_results), "total": 4, "ranking": name, "status": "failed"})
                    # As próximas respostas distinguem-se pelo opcode/facção; não repetir pedidos.
                    if not (isinstance(exc, _Stop) and exc.timeout):
                        break

        if config.get("rankings_only"):
            state["stage"] = "rankings:done"
            state["collection_complete"] = True
            result = {"status": "completed", "stage": "rankings:done", "diagnostic": "",
                      "authenticated": state["authenticated"], "items": [], "offers": [],
                      "errors": [], "frames": frames, "market": {}, "rankings": rank_results,
                      "unconfirmed": list(UNCONFIRMED)}
            emit({"record_type": "completion", "status": "completed", "stage": "rankings:done",
                  "diagnostic": "", "authenticated": state["authenticated"],
                  "items": 0, "offers": 0, "errors": [], "frames": len(frames),
                  "unconfirmed": list(UNCONFIRMED)})
            return result

        if query_errors:
            status = "incomplete"
            diagnostic = "consultas de mercado com erro: " + ", ".join(
                e["query_id"] for e in query_errors)
        else:
            state["stage"] = "done"
    except _Stop as stop:
        status, diagnostic = stop.status, stop.diagnostic
        emit({"record_type": "error", "stage": state["stage"], "status": status, "message": diagnostic})

    snapshot = acc.snapshot()
    emit(dict(snapshot, record_type="market_result"))
    items = _build_items(selections, snapshot, query_errors, requested)
    offers = [dict(offer, item_index=item["item_index"], produto=item["produto"],
                   exchange_server_type=item.get("exchange_server_type"))
              for item in items for offer in item["offers"]]
    errors = [dict(error) for error in query_errors]
    if status == "completed" and any(item["status"] == selection.ERRO for item in items):
        status, diagnostic = "incomplete", diagnostic or "itens com erro na consulta de detalhe"
    result = {"status": status, "stage": state["stage"], "diagnostic": diagnostic,
              "authenticated": state["authenticated"], "items": items, "offers": offers,
              "errors": errors, "frames": frames, "market": snapshot, "rankings": rank_results,
              "unconfirmed": list(UNCONFIRMED)}
    emit({"record_type": "completion", "status": status, "stage": state["stage"],
          "diagnostic": diagnostic, "authenticated": state["authenticated"],
          **report.counts(items), "errors": errors, "frames": len(frames),
          "unconfirmed": list(UNCONFIRMED)})
    state["collection_complete"] = True
    return result


def _build_items(selections, snapshot, query_errors, requested) -> list[dict]:
    """Estado final por item (Agente 3): ausente, sem ofertas, com ofertas ou erro.

    "ausente" só é afirmado quando alguma lista 0x1D02 fechou com is_end; sem lista
    completa não há como distinguir ausência de falha, e o item fica em "erro".
    """
    complete_lists = {q["exchange_server_type"] for q in snapshot["queries"]
                      if q["kind"] == "aggregate" and q["complete"] and q["ret"] == 0}
    details = {}
    for query in snapshot["queries"]:
        if query["kind"] == "offers":
            details.setdefault((query["exchange_server_type"], query.get("item_index")), []).append(query)
    items = []
    for sel in selections:
        index = sel["item_index"]
        server = sel.get("exchange_server_type", 0)
        records = details.get((server, index), [])
        offers = [offer for record in records for offer in record["entries"]]
        messages = [record["error"] for record in records if record["error"]]
        messages += [e["error"] for e in query_errors if e.get("item_index") == index
                     and e.get("exchange_server_type", 0) == server]
        item = dict(sel, offers=offers, detail_frames=sum(r["frames"] for r in records),
                    error=None)
        if not sel["found_in_list"]:
            if server in complete_lists:
                item["status"] = selection.AUSENTE
            else:
                item["status"] = selection.ERRO
                item["error"] = "lista de mercado não obtida"
        elif messages:
            item["status"], item["error"] = selection.ERRO, "; ".join(messages)
        elif (server, index) not in requested:
            item["status"] = selection.ERRO
            item["error"] = "consulta de detalhe não realizada"
        elif not records:
            item["status"] = selection.ERRO
            item["error"] = "nenhum 0x1D04 recebido para o item"
        elif not all(r["complete"] for r in records):
            item["status"], item["error"] = selection.ERRO, "resposta de detalhe incompleta"
        elif offers:
            item["status"] = selection.COM_OFERTAS
        else:
            item["status"] = selection.SEM_OFERTAS
        items.append(item)
    return items
