"""Consulta completa com heartbeat independente e ciclos sem sobreposição."""
import copy
import math
import threading

from . import session, rankings, upload

SERVER = "https://apirf.karvalho.dev.br"


def run(config, emit, stop_event, continuous=False, interval=300, runner=None, submit=None):
    runner = runner or session.run
    submit = submit or upload.submit_result
    if not math.isfinite(interval) or interval <= 0:
        raise ValueError("Intervalo deve ser positivo e finito")
    base = copy.deepcopy(config)
    base["companion"] = dict(base.get("companion") or {}, base_url=SERVER)
    heartbeat = copy.deepcopy(base)
    heartbeat.update(heartbeat_only=True, rankings=False, initialize_character=True)
    heartbeat["heartbeat"] = dict({"constant": -371988797, "flag": 0}, **base.get("heartbeat", {}))
    heartbeat["heartbeat"]["enabled"] = True
    ready, ended = threading.Event(), threading.Event()
    failure = []

    def maintain():
        try:
            value = runner(heartbeat, emit, stop_event=stop_event,
                           on_collected=lambda result: ready.set())
            failure.append(value.get("diagnostic") or value.get("connection", {}).get("reason") or "Heartbeat encerrado")
        except Exception as exc:
            failure.append(str(exc))
        finally:
            ended.set()
            stop_event.set()

    worker = threading.Thread(target=maintain, daemon=True)
    worker.start()
    result = None
    try:
        while not ready.wait(0.1):
            if ended.is_set() or stop_event.is_set():
                raise RuntimeError(failure[0] if failure else "Inicialização cancelada")
        while not stop_event.is_set():
            rank_config = copy.deepcopy(base)
            rank_config.update(rankings_only=True, heartbeat_only=False, rankings=True)
            rank_config["heartbeat"] = {"enabled": False}
            rank_config["market"].update(list_requests=[], detail_requests=[], both_markets=False, detail_all_items=False)
            emit({"record_type": "cycle", "stage": "rankings", "status": "running"})
            rank_result = runner(rank_config, emit, stop_event=stop_event)
            snapshots = rank_result.get("rankings", {})
            if any(snapshots.get(name, {}).get("status") != "completed" for name in ("exp", "accretia", "bellato", "cora")):
                raise RuntimeError("Rankings incompletos; ciclo não enviado")
            if stop_event.is_set():
                break
            market_config = copy.deepcopy(base)
            market_config.update(rankings_only=False, heartbeat_only=False, rankings=False)
            market_config["heartbeat"] = {"enabled": False}
            market_config["market"].update(both_markets=True, detail_all_items=True, detail_requests=[])
            emit({"record_type": "cycle", "stage": "market", "status": "running"})
            result = runner(market_config, emit, stop_event=stop_event)
            result["rankings"] = snapshots
            if result.get("status") != "completed":
                raise RuntimeError("Mercado incompleto; ciclo não enviado")
            names = rankings.seller_names(result)
            for offer in result.get("offers", []):
                offer["seller"] = names.get(str(offer.get("pc_id")))
            emit({"record_type": "cycle", "stage": "sellers", "status": "completed"})
            if stop_event.is_set():
                break
            result["upload"] = submit(result, base, emit=emit, stop_event=stop_event)
            emit({"record_type": "cycle", "stage": "done", "status": result["upload"].get("status"), "result": result})
            if not continuous or stop_event.wait(interval):
                break
        if ended.is_set() and failure:
            raise RuntimeError(failure[0])
        return result
    finally:
        stop_event.set()
        worker.join()
