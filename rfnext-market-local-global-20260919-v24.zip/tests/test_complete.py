import threading
import unittest
from unittest.mock import patch
from rfnext_market import complete


class CompleteTest(unittest.TestCase):
    def test_completed_rank_survives_heartbeat_close_and_next_cycle_restarts(self):
        user_stop = threading.Event()
        rank_started = threading.Event()
        order = []
        def run(config, emit, stop_event, on_collected=None):
            if on_collected:
                rank_started.clear()
                order.append("heartbeat")
                on_collected({})
                self.assertTrue(rank_started.wait(2))
                return {"connection": {"reason": "connection closed by server"}}
            if config.get("rankings_only"):
                order.append("rankings")
                rank_started.set()
                self.assertTrue(stop_event.wait(2))
                return {"rankings": {name: {"status": "completed"} for name in ("exp", "accretia", "bellato", "cora")}}
            self.assertIs(stop_event, user_stop)
            self.assertFalse(stop_event.is_set())
            order.append("market")
            return {"status": "completed", "offers": [{"pc_id": 42}]}
        def submit(result, config, **kwargs):
            self.assertIs(kwargs["stop_event"], user_stop)
            self.assertFalse(user_stop.is_set())
            self.assertEqual(result["offers"][0]["seller"], "Seller")
            order.append("upload")
            if order.count("upload") == 2:
                user_stop.set()
            return {"status": "accepted"}
        with patch.object(complete.rankings, "seller_names", return_value={"42": "Seller"}):
            result = complete.run({"market": {}}, lambda r: None, user_stop, True, .001, run, submit)
        self.assertEqual(order, ["heartbeat", "rankings", "market", "upload"] * 2)
        self.assertEqual(result["upload"]["status"], "accepted")

    def test_heartbeat_loss_is_not_user_cancellation(self):
        stop = threading.Event()
        rank_started = threading.Event()
        records = []
        def run(config, emit, stop_event, on_collected=None):
            if on_collected:
                on_collected({})
                self.assertTrue(rank_started.wait(2))
                return {"connection": {"reason": "timeout aguardando 0x0206"}}
            rank_started.set()
            self.assertTrue(stop_event.wait(2))
            emit({"record_type": "error", "status": "cancelled", "message": "execução cancelada pelo usuário"})
            return {"status": "cancelled"}
        with self.assertRaisesRegex(RuntimeError, "Heartbeat interrompido: timeout aguardando 0x0206"):
            complete.run({"market": {}}, records.append, stop, runner=run,
                         submit=lambda *a, **k: self.fail("upload indevido"))
        self.assertFalse(stop.is_set())
        self.assertEqual(records[-1]["status"], "failed")
        self.assertNotIn("usuário", records[-1]["message"])

    def test_ranking_mode_never_sends_market_even_with_both_markets(self):
        from tests import test_session as ts
        case = ts.SessionTest()
        config = ts.config()
        config.update(rankings_only=True, rankings=True)
        config["market"].update(both_markets=True, detail_all_items=True)
        case.run_session(cfg=config)
        ops = case.sent_ops(12020)
        self.assertFalse(any(op >> 8 == 0x1D for op in ops))
        self.assertIn(0x1A01, ops)
        self.assertEqual(ops.count(0x240A), 3)

    def test_order_repeat_and_cancellation(self):
        stop = threading.Event()
        order = []
        cfg = {"market": {"both_markets": True}, "heartbeat": {"constant": 123}}
        def run(config, emit, stop_event, on_collected=None):
            if config.get("heartbeat_only"):
                order.append("heartbeat")
                on_collected({"status": "completed"})
                stop_event.wait()
                return {"status": "cancelled"}
            if config.get("rankings_only"):
                self.assertFalse(config["market"]["both_markets"])
                order.append("rankings")
                return {"rankings": {name: {"status": "completed"} for name in ("exp", "accretia", "bellato", "cora")}}
            self.assertFalse(config["rankings"])
            self.assertTrue(config["market"]["both_markets"])
            order.append("market")
            return {"status": "completed", "offers": [{"pc_id": 42}]}
        def submit(result, config, **kwargs):
            self.assertEqual(result["offers"][0]["seller"], "Seller")
            self.assertEqual(config["companion"]["base_url"], complete.SERVER)
            order.append("upload")
            if order.count("upload") == 2:
                stop.set()
            return {"status": "accepted"}
        with patch.object(complete.rankings, "seller_names", return_value={"42": "Seller"}):
            complete.run(cfg, lambda r: None, stop, True, .001, run, submit)
        self.assertEqual(order, ["heartbeat", "rankings", "market", "upload", "rankings", "market", "upload"])
        self.assertTrue(cfg["market"]["both_markets"])

    def test_failed_rank_prevents_market_and_upload(self):
        stop = threading.Event()
        def run(config, emit, stop_event, on_collected=None):
            if on_collected:
                on_collected({})
                stop_event.wait()
                return {}
            self.assertTrue(config["rankings_only"])
            return {"rankings": {}}
        with self.assertRaisesRegex(RuntimeError, "Rankings incompletos"):
            complete.run({"market": {}}, lambda r: None, stop, runner=run,
                         submit=lambda *a, **k: self.fail("upload indevido"))
