"""Rankings 12020: layouts do decoder do Agent; pedidos observados no cliente."""
import math
import struct
from .market import _read, _end

REQUESTS = (("exp", 0x1A01, 0x1A02, bytes.fromhex("000000002c010000")),
            ("accretia", 0x240A, 0x240B, b"\x01\x00"),
            ("bellato", 0x240A, 0x240B, b"\x02\x00"),
            ("cora", 0x240A, 0x240B, b"\x03\x00"))
OPCODES = {0x1A01, 0x1A02, 0x240A, 0x240B}


def _string(payload, cursor):
    (length,), cursor = _read(payload, cursor, "<H", "string length")
    (raw,), cursor = _read(payload, cursor, f"<{length * 2}s", "UTF-16 string")
    return raw.decode("utf-16le"), cursor


def _record(payload, cursor, exp):
    fmt = "<QQIIIIQ" if exp else "<Q"
    keys = ("character_uid", "total_exp", "rank", "previous_rank", "scope_id_raw",
            "ranking_cycle_raw", "character_uid_repeat") if exp else ("character_uid",)
    values, cursor = _read(payload, cursor, fmt, "rank prefix")
    row = dict(zip(keys, values))
    row["character_name"], cursor = _string(payload, cursor)
    values, cursor = _read(payload, cursor, "<QI" if exp else "<IQ", "rank profile")
    row.update(zip(("profile_uid_raw", "profile_value_raw") if exp else
                   ("biosuit_index", "guild_id"), values))
    row["guild_name"], cursor = _string(payload, cursor)
    if exp:
        (mark,), cursor = _read(payload, cursor, "<4s", "guild mark")
        row["guild_mark_hex"] = mark.hex()
    else:
        values, cursor = _read(payload, cursor, "<IId", "rank values")
        row.update(zip(("guild_mark_raw", "rank", "contribution"), values))
        if not math.isfinite(row["contribution"]):
            raise ValueError("contribution não finita")
    return row, cursor


def parse_message(opcode, payload):
    fields, cursor = {}, 0
    if opcode == 0x1A01:
        values, cursor = _read(payload, cursor, "<II", "EXP request")
        fields.update(zip(("start_index", "requested_count"), values))
    elif opcode == 0x240A:
        values, cursor = _read(payload, cursor, "<BB", "faction request")
        fields.update(zip(("faction_id_raw", "rank_variant_raw"), values))
    elif opcode in (0x1A02, 0x240B):
        if opcode == 0x240B:
            (faction, variant), cursor = _read(payload, cursor, "<BB", "rank ID")
            fields.update(faction_id_raw=faction, rank_variant_raw=variant)
            fields["self_rank"], cursor = _record(payload, cursor, False)
        (count,), cursor = _read(payload, cursor, "<H", "rank count")
        rows = []
        for _ in range(count):
            row, cursor = _record(payload, cursor, opcode == 0x1A02)
            rows.append(row)
        fields.update(record_count=count, records=rows)
    else:
        raise ValueError("opcode de ranking desconhecido")
    _end(opcode, payload, cursor)
    return {"status": "confirmed", "fields": fields, "unknown_fields": []}


def validate(fields, name):
    rows = fields["records"]
    limit = 300 if name == "exp" else 100
    positions = [r["rank"] for r in rows]
    uids = [r["character_uid"] for r in rows]
    if len(set(positions)) != len(rows) or len(set(uids)) != len(rows):
        raise ValueError("ranking contém posições ou personagens duplicados")
    if any(not 1 <= n <= limit for n in positions) or any(n <= 0 for n in uids):
        raise ValueError("posição ou personagem inválido")
    if name == "exp" and (any(r["character_uid"] != r["character_uid_repeat"] for r in rows)
            or len({(r["scope_id_raw"], r["ranking_cycle_raw"]) for r in rows}) > 1):
        raise ValueError("identidade, escopo ou ciclo de EXP divergente")
    return set(positions) == set(range(1, limit + 1))
