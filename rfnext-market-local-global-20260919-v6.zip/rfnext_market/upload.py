"""Envio assinado das ofertas ao Companion, com fila persistente independente do Agent."""
from __future__ import annotations

import base64
import hashlib
import http.client
import json
import math
import secrets
import socket
import sqlite3
import ssl
import threading
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

INGEST_PATH = "/api/qol/v1/ingest/batches"
MAX_BODY = 512 * 1024
VERSION = "2.0.0-beta.6"  # Existing receiver's accepted wire-client version.


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                      allow_nan=False).encode("utf-8")


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _b64(value):
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def validate_config(config, base=Path(".")):
    value = config.get("companion")
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) - {"base_url", "state_dir", "timeout"}:
        raise ValueError("companion: objeto com base_url, state_dir e timeout esperado")
    url = value.get("base_url", "")
    if not isinstance(url, str):
        raise ValueError("companion.base_url: endereço esperado")
    parsed = urlsplit(url)
    if (not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path not in ("", "/") or parsed.scheme not in {"http", "https"}
            or parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}):
        raise ValueError("companion.base_url: origem HTTPS necessária (HTTP somente loopback)")
    parsed.port
    timeout = value.get("timeout", 10)
    if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 1 <= timeout <= 30:
        raise ValueError("companion.timeout: valor entre 1 e 30 segundos")
    path = value.get("state_dir", "companion-state")
    if not isinstance(path, str) or not path.strip():
        raise ValueError("companion.state_dir: diretório necessário")
    state = Path(path)
    if not state.is_absolute():
        state = Path(base) / state
    return {"base_url": url.rstrip("/"), "state_dir": str(state.resolve()), "timeout": timeout}


def _integer(value, high, label, low=0):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label}: inteiro fora do contrato")
    return value


def _u64(value, label):
    return str(_integer(value, 2**64 - 1, label))


def _offer(raw, names):
    info = raw["item_info"]
    index = _integer(info["index"], 2**32 - 1, "item_index", 1)
    count = _integer(info["count"], 2**31 - 1, "quantity", 1)
    enhance = _integer(info["enchant_level"], 65535, "enhance")
    details = {key: info[key] for key in ("index", "lock", "enchant_level", "talic_indices",
                                         "item_options", "is_broken")}
    for key in ("id", "count", "expire_time"):
        details[key] = _u64(info[key], key)
    if type(details["lock"]) is not bool or type(details["is_broken"]) is not bool:
        raise ValueError("item_info: booleanos inválidos")
    if not isinstance(details["talic_indices"], list) or len(details["talic_indices"]) > 65535:
        raise ValueError("talic_indices inválido")
    for value in details["talic_indices"]:
        _integer(value, 2**32 - 1, "talic")
    if not isinstance(details["item_options"], list) or len(details["item_options"]) > 65535:
        raise ValueError("item_options inválido")
    for option in details["item_options"]:
        if (not isinstance(option, dict) or set(option) != {"option_index", "value", "change_lock"}
                or type(option["value"]) not in (int, float) or not math.isfinite(option["value"])
                or abs(option["value"]) > 3.4028235e38 or type(option["change_lock"]) is not bool):
            raise ValueError("item_option inválido")
        _integer(option["option_index"], 2**32 - 1, "option_index")
    value = {"listing_id": _u64(raw["exchange_index"], "listing_id"), "item_index": index,
             "name": str(names.get(index) or f"Item {index}")[:120], "enhance": enhance,
             "quantity": count, "price": _integer(raw["selling_price"], 2**63 - 1, "price"),
             "seller": None, "expires_at": None, "item_info": details}
    for target, source in (("pc_id", "pc_id"), ("account_id", "account_id"),
                           ("registered_time", "registed_time"), ("expires_time", "expired_time"),
                           ("selling_time", "selling_time"), ("settlement_price", "settlement_price")):
        value[target] = None if raw.get(source) is None else _u64(raw[source], source)
    flag = raw.get("is_forc_expire")
    if flag is not None and type(flag) is not bool:
        raise ValueError("is_forc_expire inválido")
    value["is_forc_expire"] = flag
    return value


def market_payloads(result, captured_at):
    queries = result.get("market", {}).get("queries", [])
    names = {item["item_index"]: item.get("produto") for item in result.get("items", [])}
    servers = sorted({q["exchange_server_type"] for q in queries if q["kind"] in {"aggregate", "offers"}})
    payloads = []
    for server in servers:
        _integer(server, 255, "server_type")
        lists = [q for q in queries if q["kind"] == "aggregate" and q["exchange_server_type"] == server]
        details = [q for q in queries if q["kind"] == "offers" and q["exchange_server_type"] == server]
        expected = {entry["item_index"] for q in lists for entry in q["entries"]}
        successful = {q["item_index"] for q in details if q["complete"] and q["ret"] == 0 and not q.get("error")}
        complete = (result.get("status") == "completed" and bool(lists)
                    and all(q["complete"] and q["ret"] == 0 and not q.get("error") for q in lists + details)
                    and expected <= successful and not result.get("errors"))
        offers = {}
        for query in details:
            for raw in query["entries"]:
                offer = _offer(raw, names)
                if offer["item_index"] != query["item_index"]:
                    raise ValueError("oferta diverge do item solicitado")
                previous = offers.setdefault(offer["listing_id"], offer)
                if previous != offer:
                    raise ValueError("oferta repetida com conteúdo divergente")
        # Reserve envelope space as well as respecting the receiver's row limit.
        chunks, chunk, size = [], [], 0
        for offer in offers.values():
            length = len(_json(offer)) + 1
            if length > MAX_BODY - 8192:
                raise ValueError("oferta maior que o limite do Companion; resultado salvo localmente")
            if len(chunk) >= 512 or size + length > MAX_BODY - 8192:
                chunks.append(chunk)
                chunk, size = [], 0
            chunk.append(offer)
            size += length
        chunks.append(chunk)
        if len(chunks) > 256:
            raise ValueError("consulta excede 256 partes; resultado salvo localmente")
        snapshot = uuid.uuid4().hex
        rows = []
        for q in lists:
            for entry in q["entries"]:
                low = entry.get("lowest_price", 0)
                high = entry.get("highest_price", low)
                # Preserve the decoder's float representation alongside legacy integer projections.
                rows.append({"item_index": int(entry["item_index"]), "name": str(names.get(entry["item_index"]) or f"Item {entry['item_index']}")[:120],
                             "enhance": int(entry.get("enchant_level", 0)), "lowest_price": int(low), "highest_price": int(high),
                             "quantity": int(entry.get("number_of_registered_items", 0)),
                             # Decoder exposes binary floats; str() preserves the shortest available value
                             # without claiming decimal precision that was not observed.
                             "lowest_price_raw": str(low), "highest_price_raw": str(high)})
        aggregate_chunks = [rows[i:i + 256] for i in range(0, len(rows), 256)] or [[]]
        if len(aggregate_chunks) > 64:
            raise ValueError("lista agregada excede 64 partes; resultado salvo localmente")
        aggregate_ref = uuid.uuid4().hex
        for number, chunk in enumerate(chunks, 1):
            payloads.append({"snapshot_schema": "rf-qol.market-offers-snapshot/v1",
                             "server_type": server, "snapshot_ref": snapshot,
                             "chunk_index": number, "chunk_count": len(chunks), "captured_at": captured_at,
                             "coverage": {"status": "complete" if complete else "partial", "scope": "server-market"},
                             "offers": chunk})
        # O contrato de agregados não marca cobertura parcial: só publicar lista fechada.
        if lists and all(q["complete"] and q["ret"] == 0 and not q.get("error") for q in lists):
            for number, aggregate in enumerate(aggregate_chunks, 1):
                payloads.append({"snapshot_ref": aggregate_ref, "server_type": server,
                                 "chunk_index": number, "chunk_count": len(aggregate_chunks), "market_rows": aggregate})
    return payloads


@contextmanager
def _database(options):
    folder = Path(options["state_dir"])
    folder.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(folder / "market-upload.sqlite3", timeout=10)
    db.row_factory = sqlite3.Row
    try:
        # ponytail: retain results/receipts; add an explicit archival policy if disk growth matters.
        db.executescript("""
            CREATE TABLE IF NOT EXISTS identity (id INTEGER PRIMARY KEY CHECK(id=1),origin TEXT NOT NULL,secret BLOB NOT NULL);
            CREATE TABLE IF NOT EXISTS results (result_ref TEXT PRIMARY KEY,captured_at TEXT NOT NULL,document BLOB NOT NULL,queued INTEGER NOT NULL DEFAULT 0,error TEXT);
            CREATE TABLE IF NOT EXISTS batches (sequence INTEGER PRIMARY KEY,batch_id TEXT UNIQUE NOT NULL,body BLOB NOT NULL,
                state TEXT NOT NULL DEFAULT 'pending',receipt BLOB);
        """)
        yield db
    finally:
        db.close()


def _identity(db, options):
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    from .protected_state import protect_for_current_user, unprotect
    db.execute("BEGIN IMMEDIATE")
    row = db.execute("SELECT origin,secret FROM identity WHERE id=1").fetchone()
    if row:
        if row["origin"] != options["base_url"]:
            db.rollback()
            raise ValueError("state_dir pertence a outro servidor; selecione outro diretório")
        value = json.loads(unprotect(bytes(row["secret"])))
        key = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(value["private_key"]))
    else:
        key = Ed25519PrivateKey.generate()
        value = {"installation_id": str(uuid.uuid4()), "created_at": _now(),
                 "private_key": key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                                   serialization.NoEncryption()).hex()}
        db.execute("INSERT INTO identity VALUES(1,?,?)", (options["base_url"], protect_for_current_user(_json(value))))
    db.commit()
    uuid.UUID(value["installation_id"])
    public = key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    registration = {"schema": "rf-qol.installation-registration/v1", "installation_id": value["installation_id"],
                    "key_id": "agent-" + hashlib.sha256(public).hexdigest()[:24], "public_key": _b64(public),
                    "created_at": value["created_at"], "algorithm": "Ed25519"}
    registration["proof"] = _b64(key.sign(b"RFQOL-REGISTER-V1\0" + _json(registration)))
    return registration, key


def _post(options, path, body, headers=None, stop_event=None):
    from .transport import _connect, CancelledError
    stop_event = stop_event or threading.Event()
    url = urlsplit(options["base_url"])
    port = url.port or (443 if url.scheme == "https" else 80)
    deadline = time.monotonic() + options["timeout"]
    connection = http.client.HTTPConnection(url.hostname, port, timeout=options["timeout"])
    finished = threading.Event()
    response = None
    try:
        # Reuse the game client's bounded DNS/connect; never open a late connection after cancellation.
        connection.sock = _connect(url.hostname, port, options["timeout"], stop_event)
        connection.sock.settimeout(max(0.001, deadline - time.monotonic()))
        if url.scheme == "https":
            connection.sock = ssl.create_default_context().wrap_socket(connection.sock, server_hostname=url.hostname)
        if stop_event.is_set():
            raise CancelledError("envio cancelado")
        active_socket = connection.sock

        def interrupt_read():
            # A socket timeout alone does not bound trickled headers/body.
            while not finished.wait(0.05):
                if stop_event.is_set() or time.monotonic() >= deadline:
                    try:
                        active_socket.shutdown(socket.SHUT_RDWR)
                    except OSError:
                        pass
                    return

        threading.Thread(target=interrupt_read, name="companion-timeout", daemon=True).start()
        connection.request("POST", path, body, {"Content-Type": "application/json", "Accept": "application/json",
                           "User-Agent": "RFQOL-Agent/" + VERSION, "Connection": "close", **(headers or {})})
        response = connection.getresponse()
        if not 200 <= response.status < 300:
            raise ValueError(f"Companion HTTP {response.status}: envio permanece pendente")
        raw = bytearray()
        while len(raw) <= MAX_BODY:
            if stop_event.is_set():
                raise CancelledError("envio cancelado")
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("tempo de resposta do Companion esgotado")
            # HTTPResponse may own the socket after Connection: close.
            if connection.sock is not None:
                connection.sock.settimeout(remaining)
            part = response.read1(min(65536, MAX_BODY + 1 - len(raw)))
            if not part:
                break
            raw.extend(part)
        if stop_event.is_set():
            raise CancelledError("envio cancelado; recibo não confirmado")
        if time.monotonic() >= deadline:
            raise TimeoutError("tempo de resposta do Companion esgotado")
        if len(raw) > MAX_BODY:
            raise ValueError("resposta do Companion excede limite")
        value = json.loads(raw)
        if not isinstance(value, dict):
            raise ValueError("resposta do Companion inválida")
        return value
    finally:
        finished.set()
        if response is not None:
            response.close()
        connection.close()


def _receipt(receipt, batch):
    expected = {"batch_id", "accepted", "accepted_through_sequence", "duplicate", "rejected_events", "server_time"}
    if (not isinstance(receipt, dict) or set(receipt) != expected or receipt["batch_id"] != batch["batch_id"]
            or receipt["accepted"] is not True or type(receipt["duplicate"]) is not bool
            or type(receipt["accepted_through_sequence"]) is not int
            or receipt["accepted_through_sequence"] != batch["last_sequence"]
            or not isinstance(receipt["rejected_events"], list) or len(receipt["rejected_events"]) > 1):
        raise ValueError("recibo do Companion inválido; lote continua pendente")
    stamp = receipt["server_time"]
    if not isinstance(stamp, str) or not stamp.endswith("Z"):
        raise ValueError("data do recibo inválida")
    datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    for rejected in receipt["rejected_events"]:
        if (not isinstance(rejected, dict) or set(rejected) != {"event_id", "sequence", "reason"}
                or rejected["event_id"] != batch["events"][0]["event_id"]
                or type(rejected["sequence"]) is not int or rejected["sequence"] != batch["last_sequence"]
                or not isinstance(rejected["reason"], str) or not rejected["reason"].strip()
                or len(rejected["reason"]) > 64):
            raise ValueError("rejeição inválida no recibo; lote continua pendente")
    return "rejected" if receipt["rejected_events"] else "accepted"


def _status(db, **extra):
    counts = dict(db.execute("SELECT state,COUNT(*) FROM batches GROUP BY state").fetchall())
    saved = db.execute("SELECT COUNT(*) FROM results WHERE queued=0").fetchone()[0]
    blocked = db.execute("SELECT error FROM results WHERE queued=0 AND error IS NOT NULL ORDER BY captured_at LIMIT 1").fetchone()
    rejected = db.execute("SELECT receipt FROM batches WHERE state='rejected' ORDER BY sequence DESC LIMIT 1").fetchone()
    reason = "; ".join(r["reason"] for r in json.loads(rejected[0])["rejected_events"]) if rejected else ""
    if blocked:
        reason = "; ".join(filter(None, (reason, blocked[0])))
    return {"status": "pending" if counts.get("pending", 0) else "blocked" if saved else "rejected" if counts.get("rejected", 0) else "accepted",
            "pending": counts.get("pending", 0), "accepted": counts.get("accepted", 0),
            "rejected": counts.get("rejected", 0), "saved_unqueued": saved, "diagnostic": reason, **extra}


def _flush(db, options, registration, key, emit, stop_event):
    def stopped():
        return stop_event is not None and stop_event.is_set()
    if stopped():
        return _status(db, status="pending", diagnostic="envio interrompido; dados preservados")
    authorization = _post(options, "/api/qol/v1/installations/authorization", _json(registration), stop_event=stop_event)
    if authorization.get("installation_id") != registration["installation_id"]:
        raise ValueError("autorização pertence a outra instalação")
    if authorization.get("status") != "authorized":
        return _status(db, status="awaiting_authorization", pairing_code=authorization.get("pairing_code"),
                       installation_id=registration["installation_id"], diagnostic="vincule/autorize a instalação no Companion")
    for row in db.execute("SELECT batch_id,body FROM batches WHERE state='pending' ORDER BY sequence"):
        if stopped():
            break
        body = bytes(row["body"])
        batch = json.loads(body)
        timestamp, nonce = _now(), secrets.token_hex(16)
        digest = hashlib.sha256(body).hexdigest()
        signed = "\n".join(("POST", INGEST_PATH, batch["batch_id"], timestamp, nonce, digest)).encode()
        receipt = _post(options, INGEST_PATH, body, {
            "Idempotency-Key": batch["batch_id"], "X-RFQOL-Installation-ID": registration["installation_id"],
            "X-RFQOL-Key-ID": registration["key_id"], "X-RFQOL-Timestamp": timestamp,
            "X-RFQOL-Nonce": nonce, "X-RFQOL-Body-SHA256": digest,
            "X-RFQOL-Signature": _b64(key.sign(b"RFQOL-INGEST-V1\0" + signed))}, stop_event=stop_event)
        state = _receipt(receipt, batch)
        with db:
            db.execute("UPDATE batches SET state=?,receipt=? WHERE batch_id=? AND state='pending'",
                       (state, _json(receipt), row["batch_id"]))
        if emit:
            emit({"record_type": "upload", "message": f"Companion: {state}", **_status(db)})
    return _status(db, installation_id=registration["installation_id"])


def _run(config, result, emit, stop_event):
    options = validate_config(config)
    if options is None:
        return {"status": "disabled", "pending": 0, "accepted": 0, "rejected": 0, "diagnostic": ""}
    with _database(options) as db:
        result_ref, captured = uuid.uuid4().hex, _now()
        if result is not None:
            with db:
                from .dump import _json_default
                document = json.dumps(result, ensure_ascii=False, default=_json_default).encode("utf-8")
                db.execute("INSERT INTO results(result_ref,captured_at,document) VALUES(?,?,?)", (result_ref, captured, document))
        try:
            registration, key = _identity(db, options)
            for saved in db.execute("SELECT * FROM results WHERE queued=0 ORDER BY captured_at,result_ref"):
                result_ref, captured = saved["result_ref"], saved["captured_at"]
                try:
                    from .rankings import upload_payloads
                    document = json.loads(saved["document"])
                    payloads = market_payloads(document, captured)
                    payloads.extend(upload_payloads(document, captured, emit))
                except (ValueError, KeyError, TypeError, OverflowError) as exc:
                    with db:
                        db.execute("UPDATE results SET error=? WHERE result_ref=?",
                                   (f"resultado {result_ref}: {type(exc).__name__}: {exc}", result_ref))
                    continue
                with db:
                    db.execute("BEGIN IMMEDIATE")
                    if db.execute("SELECT queued FROM results WHERE result_ref=?", (result_ref,)).fetchone()[0]:
                        continue
                    sequence = db.execute("SELECT COALESCE(MAX(sequence),0) FROM batches").fetchone()[0]
                    for payload in payloads:
                        sequence += 1
                        event_id = secrets.token_hex(24)
                        event_type = ("community.exp_ranking_snapshot" if "ranking_records" in payload else
                                      "community.faction_ranking_snapshot" if "faction_ranking_records" in payload else
                                      "community.market_offers_observed" if "offers" in payload else
                                      "community.market_observed")
                        event = {"schema": "rf-qol.decoded-event/v1", "event_id": event_id,
                                 "installation_id": registration["installation_id"], "session_ref": result_ref,
                                 "stream_id": result_ref, "sequence": sequence, "occurred_at": captured,
                                 "client_ref": None, "type": event_type, "payload": payload,
                                 "evidence": {"confidence": "decoded", "decoder_version": "rfnext-market-v1"}}
                        bid = hashlib.sha256(f"{registration['installation_id']}:{sequence}:{event_id}".encode()).hexdigest()
                        batch = {"schema": "rf-qol.ingest-batch/v1", "batch_id": bid,
                                 "installation_id": registration["installation_id"], "sent_at": captured,
                                 "first_sequence": sequence, "last_sequence": sequence, "events": [event]}
                        body = _json(batch)
                        if len(body) > MAX_BODY:
                            raise ValueError("lote excede limite do Companion")
                        db.execute("INSERT INTO batches(sequence,batch_id,body) VALUES(?,?,?)", (sequence, bid, body))
                    db.execute("UPDATE results SET queued=1,error=NULL WHERE result_ref=?", (result_ref,))
            if db.execute("SELECT COUNT(*) FROM batches WHERE state='pending'").fetchone()[0] == 0:
                answer = _status(db)
                if not answer["rejected"] and not answer["saved_unqueued"]:
                    answer["status"] = "no_market_data" if result is not None else "idle"
                return answer
            answer = _flush(db, options, registration, key, emit, stop_event)
        except Exception as exc:
            db.rollback()
            answer = _status(db, status="pending", diagnostic=f"{type(exc).__name__}: {exc}", result_ref=result_ref)
            if not answer["pending"]:
                answer["status"] = "blocked"
        if emit:
            message = f"Companion: {answer['status']}; {answer.get('diagnostic', '')}"
            if answer.get("pairing_code"):
                message += f"; código de vínculo: {answer['pairing_code']}"
            emit({"record_type": "upload", "message": message, **answer})
        return answer


def submit_result(result, config, emit=None, stop_event=None):
    return _run(config, result, emit, stop_event)


def retry_pending(config, emit=None, stop_event=None):
    return _run(config, None, emit, stop_event)
