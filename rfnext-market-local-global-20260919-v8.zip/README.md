VENDEDORES (v8)
Cruza pc_id das ofertas com character_uid dos 300 registros de EXP e rankings
das três facções da mesma coleta. Envia o nome no campo seller para o site.
Sem correspondência ou com nomes conflitantes, mantém vendedor desconhecido.
Vale para novas coletas; não altera lotes já enviados ou pendentes.

BARRAS DE PROGRESSO (v7)
Leitura: barra por etapa de detalhes e rankings, sem eventos por item.
Envio: barra de lotes processados após recibo do site; rejeições são indicadas.
O total de envio inclui os lotes pendentes desta instalação.

ENVIO DE RANKINGS (v6)
Com o envio ao Companion ativado, usa a mesma identidade e fila persistente
para community.exp_ranking_snapshot e community.faction_ranking_snapshot.
Envia Top 100 de EXP e Top 100 de cada facção; as 300 posições de EXP
permanecem no JSONL local. Nível e porcentagem usam a curva embarcada do Agent.
Rankings incompletos/inválidos ficam locais e geram diagnóstico, sem impedir
o envio dos demais rankings válidos. Tentativas pendentes reutilizam os lotes.
Não exige novo vínculo nem alteração do servidor. Preserve companion.state_dir.

# Rankings v5

RANKINGS (v5)
Após o mercado, consulta EXP (300 posições) e Accretia, Bellato e Cora
(100 posições por facção) usando a mesma conexão autenticada.
Na interface fica ativo por padrão. Para desativar, salve "rankings": false
na raiz do config.json. No terminal, configurações antigas precisam adicionar
"rankings": true; o preparador e config.example.json já habilitam a consulta.
Exportar JSONL inclui ranking_result com registros, IDs e campos brutos.
Respostas parciais são marcadas incomplete; falha interrompe os demais pedidos
de ranking e preserva o mercado coletado. O status geral continua referente
ao mercado; confira status de cada ranking_result separadamente.
Os rankings completos são enviados ao Companion desde a v6. Não renova tokens.
Validado offline; a consulta ativa das quatro listas aguarda teste no jogo.


# rfnext_market

Cliente de teste, somente leitura de mercado, para o protocolo RF Next (portas 12000
login/entrada e 12020 jogo/mercado). Contratos completos em `CONTRACTS.md`; instruções de
programação em `INSTRUCOES-CLAUDE-MERCADO.md`. Não implementa compra, venda, cancelamento
nem liquidação (proibido pelas instruções).

## Uso

Na interface desktop, a conexão 12020 permanece aberta depois da coleta.
O resultado fica disponível para exportação e o envio ao Companion ocorre antes
de desconectar. Use **Desconectar** ou feche a janela para encerrar. A recepção
continua ativa; se o servidor fechar a conexão, o resultado da coleta é preservado.
Os registros posteriores seguem o limite do histórico visual e não fazem o
snapshot da coleta crescer indefinidamente. Não há renovação de token ou envio
de `0x0205` ainda: o servidor pode encerrar a sessão por inatividade.
O comando abaixo continua sendo uma execução única, que fecha ao terminar.

```
python -m rfnext_market --config config.json --output resultado.jsonl
```

`--output` precisa terminar em `.jsonl`. A configuração é validada (endpoints, timeouts,
`world_id`, seções de mercado, `session_file` e as credenciais nele contidas) **antes** de
qualquer socket ser aberto; erro de configuração sai com código 2. Falha depois de abrir
sockets sai com código 1. Sucesso (`status == "completed"`) sai com código 0.

Veja `config.example.json` para a forma de `config.json` (sem credenciais reais).

## Enviar ofertas ao Companion 2.0

Instale a dependência do envio com `python -m pip install -r requirements.txt`.
Na interface, marque **Enviar ao Companion**, informe a origem HTTPS do servidor e
uma pasta local para a fila. Salve a configuração. Também é possível acrescentar
ao JSON a seção `companion` com `base_url`, `state_dir` e `timeout` (1 a 30 segundos,
padrão 10). `state_dir` relativo é resolvido a partir do arquivo de configuração.
O endereço não é preenchido automaticamente: use o endereço da candidata 2.0
quando ela estiver integrada. HTTP é aceito apenas em localhost para testes.

Depois da consulta, o resultado completo é salvo em `market-upload.sqlite3` na
pasta da fila. As ofertas são enviadas automaticamente pelo contrato assinado já
existente do Companion. No primeiro envio, o programa mostra um código de vínculo;
vincule essa instalação à sua conta no Companion e use **Reenviar pendentes**.
A permissão Mercado dessa instalação deve estar habilitada. Cada computador cria
sua própria identidade: a chave de assinatura usa DPAPI do usuário Windows local.
Não copie a fila/identidade para outra máquina; transfira o programa/configuração
e crie o vínculo no computador que fará as consultas.

Para reenviar sem abrir conexão com o jogo, sem `session.json` e sem `--output`:

```
python -m rfnext_market --config config.json --retry-upload
```

Uma falha de rede ou recibo inválido conserva o lote para nova tentativa. O mesmo
lote mantém IDs e conteúdo; somente a assinatura de transporte usa nonce/horário
novos. O recibo e o motivo de eventual rejeição ficam gravados. **Recebido pelo
Companion** significa confirmação de recebimento; a projeção no site ocorre
depois. Consultas filtradas, interrompidas ou sem todos os detalhes recebem cobertura
parcial e não substituem a lista completa no site. Um erro de conversão fica salvo
por resultado, sem bloquear os demais envios. Não há descarte automático de histórico.

O envio inclui ofertas por servidor, IDs da oferta/personagem/conta, item,
quantidade, preço total em diamantes, atributos, horários brutos e expiração forçada.
O nome do vendedor e a data de expiração convertida continuam `null` quando não
confirmados; `pc_id` não é tratado como nome e a unidade dos horários não é presumida.
A lista inicial `0x1D02` determina a cobertura; este incremento publica as ofertas
detalhadas no endpoint de ofertas, sem converter os preços agregados em outro contrato.
O upload não leva credenciais do jogo nem frames de autenticação. Os registros locais
continuam completos, conforme a aprovação de não ocultar credenciais/payloads.

Limites atuais do receptor: até 256 partes por servidor, 512 ofertas por parte e
512 KiB por lote; quantidade até `2**31-1` e preço total até `2**63-1`. Valores
fora do contrato bloqueiam apenas aquele resultado e permanecem salvos, sem
arredondamento. IDs e horários u64 são enviados como strings decimais exatas.
Parar impede os próximos envios; um pedido já recebido pelo servidor pode ter sido
confirmado mesmo que a resposta se perca. A fila permite repetir com segurança.

Esta é uma implementação candidata local. Exige integrar também as alterações
do receptor `site-boss-market`; não houve publicação, instalador ou envio real.

## Interface desktop local

Inicie com:

```
python -m rfnext_market.desktop
```

Na interface, selecione explicitamente o JSON de configuração, o JSON de sessão e,
quando usado, o `market_items.sqlite`. Esses arquivos não são copiados para este
projeto nem embutidos na interface. Os campos de host, porta, timeout e `world_id`
são editáveis e validados antes de qualquer socket.

`Consultar mercado` executa somente a sequência já suportada pelo cliente atual
(login/entrada e consultas `0x1D01`/`0x1D03`). `Parar` solicita cancelamento
cooperativo ao worker. TX e RX aparecem em painéis separados. Cada linha mantém o
registro original, incluindo credenciais, payload completo, `wire_hex`, `decoded_hex`,
campos parseados e desconhecidos; use duplo clique ou `Inspecionar selecionada` para
abrir a mensagem inteira em uma janela Tkinter com rolagem. O exportador grava esse
JSONL completo no destino escolhido e, quando há resultado, também grava
`mercado_resumo.csv` e `mercado_ofertas.csv` na mesma pasta, preservando itens/ofertas
parciais e finais.

Esta é a condição de aprovação atual: não ocultar credenciais nem payloads. Se a fila
ou a retenção de 1.000 registros descartar mensagens, o JSONL inclui
`record_type: "log_truncated"` com a contagem e a interface informa que o log é
parcial; nenhum limite trunca silenciosamente.

O desktop não abre conexão durante validação ou salvamento. Os testes automáticos usam
dados sintéticos, fakes e loopback; não abrem sessão real, não usam endpoints ou
credenciais reais e não são prova de compatibilidade com servidor ou jogo real.

### Windows 10 e limites manuais

Requer Python 3.10+ com Tkinter disponível. Execute no PowerShell a partir desta pasta
e faça a revisão visual manual da janela, dos diálogos nativos, do redimensionamento e
do uso de `Parar`; essa revisão não é automatizada. Não há instalador nesta etapa.

## Saídas

Cada execução grava três arquivos (os CSV ficam na pasta do `--output`, ou nos caminhos
dados em `--resumo`/`--ofertas`):

- `resultado.jsonl` — todo quadro bruto (`wire_hex`/`decoded_hex` + sha256), diagnósticos,
  `market_result` e o registro final `completion` com `status`, `items_requested`,
  `items_found`, `items_absent`, `items_error`, `offers_total`, `errors` e `frames`.
- `mercado_resumo.csv` — `produto,item_index,ofertas,menor_preco,maior_preco,quantidade_total,status`
- `mercado_ofertas.csv` — uma linha por oferta de `0x1D04`, com IDs em texto (sem `float`),
  `registed_time`/`expired_time` em valor bruto e formatado, talics e opções.

## Seleção de itens

Depois do `0x1D02`, os agregados são cruzados com o mapa `item_index -> produto`
(`market.products` na configuração; sem ele, o mapa das instruções). Só itens encontrados
na lista geram `0x1D03`, um pedido por `(exchange_server_type, item_index)`, sem repetição. Estado final por item e mercado:

- `ausente` — não apareceu em nenhum `0x1D02` fechado com `is_end`
- `sem_ofertas` — apareceu no agregado, mas o `0x1D04` veio sem ofertas
- `com_ofertas` — pelo menos uma oferta em `0x1D04`
- `erro` — `ret != 0`, timeout, lista não obtida ou detalhe não consultado

`market.detail_requests` continua aceito e, quando presente, substitui a seleção
automática (útil para consultar um `item_index` fora do mapa; nesse caso o produto fica em
branco — nomes nunca são inferidos a partir do ID).

Para solicitar as listas (`0x1D01`) e depois os detalhes (`0x1D03`
→ `0x1D04`) de todos os `item_index` recebidos, use `"detail_all_items": true`. Itens
sem nome no mapa `market.products` permanecem com `produto` vazio, mas continuam sendo
consultados e gravados nos relatórios.

`"both_markets": true` consulta local e global separadamente. Configurações antigas
com `detail_all_items=true`, somente `payload_hex=0000` e sem detalhes manuais também
passam a consultar ambos. `both_markets=false` preserva as listas configuradas.
O mesmo item presente nos dois mercados gera dois pedidos detalhados. O progresso,
JSONL e CSV preservam `exchange_server_type` (0 local, 1 global), como Agent e site.

O seletor da lista global `0100` foi confirmado na captura 20260919-163618,
em duas consultas respondidas com mercado 1. O byte final `1` no detalhe ainda
é hipótese: essa captura não contém pedidos detalhados. O cliente exige que a resposta confirme o
mercado esperado; divergência encerra a coleta como incompleta. Testes sintéticos
validam a separação e o contrato de upload, não confirmam o seletor dos detalhes no jogo.
Listas agregadas incompletas não são publicadas como snapshots completos.

## Testes

Da raiz do projeto (PowerShell, Windows):

```
$env:RFNEXT_CANONICAL_DECODER = "K:\MCP\Karvalho\rf-next\analysis\1.28.5\rfnext_frame_decode.py"
$env:RFNEXT_REFERENCE_PCAP = "K:\MCP\Karvalho\rf-next\tools\login-session-capture\captures\login-session-20260915-191739.pcap"
python -m unittest discover -s tests
```

As duas variáveis são opcionais: testes que comparam com a captura/decoder canônico usam
`unittest.skipUnless` e são pulados sem elas. O pacote nunca importa esses caminhos.

## `session_file`

Arquivo JSON **fora do repositório**, referenciado por `session_file` em `config.json`,
com as credenciais emitidas pelo servidor de teste do operador. Nunca commitar este
arquivo nem copiar credenciais reais da captura para fixtures.

Chaves de nível superior (não-dict) valem para toda mensagem que as usa; um sub-objeto
`"<porta>_0x<opcode hex>"` (ex.: `"12020_0x0103"`) sobrepõe campos só para aquela
mensagem — útil porque `device_info` observado na captura difere entre a 12000 e a 12020.

Campos obrigatórios (nomes de `auth.REQUIRED_FIELDS`, cadeias como texto simples, bytes
desconhecidos como hex em campos `..._hex`):

- **12000, login (`0x0101`)**: `account_id`, `connection_mode`, `country_code`,
  `device_info`, `auth_jwt`, `auth_host`, `session_key`, `joined_country_code`,
  `tail_flag`, `tail_value`, `tail_reserved`, `mac_address`.
- **12020, `0x0101`**: `unknown_@0_hex` (amostra observada na captura: `04`; função não
  confirmada).
- **12020, entrada no jogo (`0x0103`)**: `account_id`, `u8@66`, `u32@67`, `u32@71`,
  `u32@75`, `unknown_@79_hex`, `joined_country_code`, `device_info`,
  `unknown_@2696_hex`, `auth_host`, `session_key`, `unknown_@2834_hex`. (`u64@2688` é
  derivado em tempo de execução — ver abaixo.)

`load_config` rejeita `session_file` com qualquer um desses campos faltando, nomeando o
campo, antes de abrir sockets.

### Campos derivados em tempo de execução (não vão no `session_file`)

- `world_id`: vem de `config.json` (`world_id`), não das credenciais.
- `u64@2688` (12020, 0x0103): calculado a partir da resposta `0x0108` da 12000
  (`payload[4:12]`), depois do login — igualdade de bytes observada na captura, função
  não confirmada (ver `CONTRACTS.md`/`session.py`). Se o operador o fornecer mesmo assim
  e ele divergir do valor derivado, a sessão para com diagnóstico.

## Evidência de entrega — o que é confirmado, o que não é

- **Confirmado na captura** (decoder canônico + `login-session-20260915-191739.pcap`):
  cabeçalho de 6 bytes, rolling XOR, sequência por conexão/direção, layouts `confirmed`
  de `auth.LAYOUTS` (12000 `0x0101`/`0x0107`/`0x0108`), e os layouts de mercado
  confirmados no canônico (`0x1D02`, `0x1D04`, etc.). Ver a seção "Fatos verificados" em
  `CONTRACTS.md`.
- **Hipótese implementada só no simulador**: `tests/mock_server.py` (`ScriptedServer`)
  preenche bytes desconhecidos com zero e não reproduz nenhuma regra real de vínculo
  entre a conexão 12000 e a 12020 — ver as "REGRAS ARTIFICIAIS" no topo desse arquivo.
  Isso valida só a máquina de estados local (`session.py`) contra esse simulador.
- **Confirmado no servidor de teste do operador**: nenhum ainda. O pacote nunca foi
  executado contra um endpoint real fornecido pelo operador (proibido até que ele forneça
  servidor e credenciais).
- **Não confirmado**: lista completa em `session.UNCONFIRMED` (também emitida no campo
  `unconfirmed` de todo `record_type: "completion"` do `.jsonl` de saída) — por exemplo,
  o vínculo real entre as conexões 12000/12020, se `0x0201` (ou outras mensagens do
  cliente oficial) é exigido antes do mercado, e a função de `u64@2688`.

### Banco de itens vendáveis

`market_items.sqlite` contém 1.746 itens marcados com `exchange_item=1`. Configure
`market.item_database` para fornecer nomes. Na coleta de todos os itens, a lista
recebida determina quais consultar: itens novos ou ausentes no SQLite não são descartados.
