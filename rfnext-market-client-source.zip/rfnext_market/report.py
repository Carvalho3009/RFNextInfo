"""Agente 5 - Persistência: mercado_resumo.csv e mercado_ofertas.csv.

O `.jsonl` cru continua sendo escrito por dump.DumpWriter; aqui só derivam-se as duas
tabelas. IDs (exchange_index, account_id, pc_id, item_id) são escritos como texto para não
perder precisão em planilhas; nenhum valor de ID passa por float. `account_id == 0` é
preservado. `pc_id` é ID numérico, nunca nome de personagem.

Timestamps: a unidade de registed_time/expired_time/expire_time não está confirmada, então
o valor bruto é sempre gravado e a coluna formatada só é preenchida quando o bruto cai numa
faixa plausível de epoch (segundos ou milissegundos); fora dela fica vazia.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone

from .selection import AUSENTE, COM_OFERTAS, ERRO, SEM_OFERTAS

SUMMARY_COLUMNS = [
    "produto", "item_index", "ofertas", "menor_preco", "maior_preco",
    "quantidade_total", "status",
]

OFFER_COLUMNS = [
    "produto", "item_index", "exchange_index", "account_id", "pc_id", "item_id",
    "quantidade", "enchant_level", "selling_price", "settlement_price",
    "registered_time_raw", "expired_time_raw", "registered_time", "expired_time",
    "selling_time", "lock", "broken", "expire_time_raw", "talics", "options",
]

_SECONDS = (1_000_000_000, 4_000_000_000)
_MILLIS = (1_000_000_000_000, 4_000_000_000_000)


def format_timestamp(raw) -> str:
    """ISO 8601 UTC quando o bruto é um epoch plausível; texto vazio caso contrário."""
    if not isinstance(raw, int) or isinstance(raw, bool):
        return ""
    if _SECONDS[0] <= raw < _SECONDS[1]:
        seconds = raw
    elif _MILLIS[0] <= raw < _MILLIS[1]:
        seconds = raw // 1000
    else:
        return ""
    return datetime.fromtimestamp(seconds, timezone.utc).isoformat()


def _talics(item_info: dict) -> str:
    return ";".join(str(t) for t in item_info.get("talic_indices", []))


def _options(item_info: dict) -> str:
    parts = []
    for option in item_info.get("item_options", []):
        parts.append(f"{option.get('option_index')}:{option.get('value')}:"
                     f"{int(bool(option.get('change_lock')))}")
    return ";".join(parts)


def offer_rows(items) -> list[dict]:
    """Uma linha por oferta de 0x1D04, na ordem dos itens e dos quadros recebidos."""
    rows = []
    for item in items:
        for offer in item.get("offers", []):
            info = offer.get("item_info", {})
            rows.append({
                "produto": item["produto"],
                "item_index": item["item_index"],
                "exchange_index": str(offer.get("exchange_index", "")),
                "account_id": str(offer.get("account_id", "")),
                "pc_id": str(offer.get("pc_id", "")),
                "item_id": str(info.get("id", "")),
                "quantidade": info.get("count", ""),
                "enchant_level": info.get("enchant_level", ""),
                "selling_price": offer.get("selling_price", ""),
                "settlement_price": offer.get("settlement_price", ""),
                "registered_time_raw": offer.get("registed_time", ""),
                "expired_time_raw": offer.get("expired_time", ""),
                "registered_time": format_timestamp(offer.get("registed_time")),
                "expired_time": format_timestamp(offer.get("expired_time")),
                "selling_time": offer.get("selling_time", ""),
                "lock": int(bool(info.get("lock"))),
                "broken": int(bool(info.get("is_broken"))),
                "expire_time_raw": info.get("expire_time", ""),
                "talics": _talics(info),
                "options": _options(info),
            })
    return rows


def summary_rows(items) -> list[dict]:
    """Uma linha por produto selecionado (inclusive ausentes e com erro).

    menor_preco/maior_preco vêm do agregado 0x1D02 quando o item apareceu lá; sem agregado,
    caem para o mínimo/máximo de selling_price das ofertas. quantidade_total soma
    item_info.count das ofertas; sem ofertas, usa number_of_registered_items do agregado.
    """
    rows = []
    for item in items:
        offers = item.get("offers", [])
        prices = [o["selling_price"] for o in offers if isinstance(o.get("selling_price"), int)]
        lowest = item.get("lowest_price")
        highest = item.get("highest_price")
        if lowest is None and prices:
            lowest = min(prices)
        if highest is None and prices:
            highest = max(prices)
        quantidade = sum(int(o.get("item_info", {}).get("count") or 0) for o in offers)
        if not offers:
            quantidade = int(item.get("registered_items") or 0)
        rows.append({
            "produto": item["produto"],
            "item_index": item["item_index"],
            "ofertas": len(offers),
            "menor_preco": "" if lowest is None else lowest,
            "maior_preco": "" if highest is None else highest,
            "quantidade_total": quantidade,
            "status": item.get("status", ERRO),
        })
    return rows


def _write_csv(path, columns, rows) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def write_reports(items, summary_path, offers_path) -> dict:
    """Escreve os dois CSV e devolve a contagem de linhas de cada um."""
    summary = summary_rows(items)
    offers = offer_rows(items)
    _write_csv(summary_path, SUMMARY_COLUMNS, summary)
    _write_csv(offers_path, OFFER_COLUMNS, offers)
    return {"summary_rows": len(summary), "offer_rows": len(offers),
            "summary_path": str(summary_path), "offers_path": str(offers_path)}


def counts(items) -> dict:
    """items_requested/items_found/offers_total para o registro final."""
    return {
        "items_requested": len(items),
        "items_found": sum(1 for i in items if i.get("status") in (SEM_OFERTAS, COM_OFERTAS)),
        "items_absent": sum(1 for i in items if i.get("status") == AUSENTE),
        "items_error": sum(1 for i in items if i.get("status") == ERRO),
        "offers_total": sum(len(i.get("offers", [])) for i in items),
    }
