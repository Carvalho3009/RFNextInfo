"""Mensagens de mercado (0x1Dxx) da porta 12020.

Layouts de S->C reescritos de parse_exchange_payload do decoder canônico 1.28.5
(_parse_item_info, _parse_detailed_exchange_info). Nomes de mensagens vêm de lá.

Pedidos C->S (sem layout canônico):
- 0x1D01: 2 bytes opacos (amostras 0101, 0001, 0000); nenhum nome atribuído.
- 0x1D03: item_index u32 LE + 1 byte final opaco ("trailing_u8"). Uma única amostra, onde
  esse byte vale 0 e o exchange_server_type da resposta 0x1D04 também vale 0; a relação
  entre os dois NÃO está confirmada.
- 0x1D1E: payload vazio intercalado com os 0x1D01; função não confirmada (não é tratado como
  paginação nem como obrigatório).
- 0x1D1F (S->C, 48 B): preservado como desconhecido.

Envio de compra/venda/cancelamento/liquidação (0x1D0C/0x1D0E/0x1D10/0x1D12/0x1D14) é proibido.
"""

import struct

FORBIDDEN_OPCODES = (0x1D0C, 0x1D0E, 0x1D10, 0x1D12, 0x1D14)

NAMES = {
    0x1D02: "FL2C_respond_purchase_list_on_exchange_Message",
    0x1D04: "FL2C_respond_detailed_list_of_purchase_on_exchange_Message",
    0x1D17: "FL2C_ans_exchange_market_price_information_Message",
    0x1D18: "FL2C_recommended_item_on_exchange_Message",
    0x1D1A: "FL2C_bookmark_info_Message",
}


def _read(payload: bytes, cursor: int, fmt: str, context: str):
    end = cursor + struct.calcsize(fmt)
    if end > len(payload):
        raise ValueError(f"truncated {context} at payload offset {cursor}")
    return struct.unpack_from(fmt, payload, cursor), end


def _end(opcode: int, payload: bytes, cursor: int) -> None:
    if cursor != len(payload):
        raise ValueError(f"{opcode:#06x}: {len(payload) - cursor} trailing payload bytes")


def _item_info(payload: bytes, cursor: int):
    (item_id, index, count, lock, enchant), cursor = _read(payload, cursor, "<QIQBH", "item_info prefix")
    (talic_count,), cursor = _read(payload, cursor, "<H", "talic count")
    talic, cursor = _read(payload, cursor, f"<{talic_count}I", "talic vector")
    (option_count,), cursor = _read(payload, cursor, "<H", "item_options count")
    options = []
    for _ in range(option_count):
        (option_index, value, change_lock), cursor = _read(payload, cursor, "<IfB", "item_options entry")
        options.append({"option_index": option_index, "value": value, "change_lock": bool(change_lock)})
    (broken, expire), cursor = _read(payload, cursor, "<BQ", "item_info suffix")
    return {
        "id": item_id, "index": index, "count": count, "lock": bool(lock),
        "enchant_level": enchant, "talic_indices": list(talic), "item_options": options,
        "is_broken": bool(broken), "expire_time": expire,
    }, cursor


def _offer(payload: bytes, cursor: int):
    """Oferta individual. account_id/pc_id são IDs numéricos; nomes não são resolvidos."""
    (exchange_index, account_id, pc_id), cursor = _read(payload, cursor, "<QQQ", "offer IDs")
    item_info, cursor = _item_info(payload, cursor)
    tail, cursor = _read(payload, cursor, "<QQQQQB", "offer tail")
    return {
        "exchange_index": exchange_index, "account_id": account_id, "pc_id": pc_id,
        "item_info": item_info, "registed_time": tail[0], "expired_time": tail[1],
        "selling_time": tail[2], "selling_price": tail[3], "settlement_price": tail[4],
        "is_forc_expire": bool(tail[5]),
    }, cursor


def _item_enchant_list(payload: bytes, cursor: int, count: int, context: str):
    entries = []
    for _ in range(count):
        (item_index, enchant), cursor = _read(payload, cursor, "<IH", context)
        entries.append({"item_index": item_index, "enchant_level": enchant})
    return entries, cursor


def _parse_fields(opcode: int, payload: bytes) -> dict:
    if opcode == 0x1D02:
        # Registros agregados por item/refinamento (não são ofertas individuais).
        (ret, is_end, server_type, count), _ = _read(payload, 0, "<HBBH", "0x1d02 prefix")
        if len(payload) != 6 + count * 26:
            raise ValueError(f"0x1d02: count {count} needs {6 + count * 26} bytes, got {len(payload)}")
        entries = []
        for offset in range(6, len(payload), 26):
            item_index, enchant, lowest, highest, registered = struct.unpack_from("<IHddI", payload, offset)
            entries.append({
                "item_index": item_index, "enchant_level": enchant, "lowest_price": lowest,
                "highest_price": highest, "number_of_registered_items": registered,
            })
        return {"ret": ret, "is_end": bool(is_end), "exchange_server_type": server_type, "entries": entries}

    if opcode == 0x1D04:
        (ret, item_index, is_end, server_type, count), cursor = _read(payload, 0, "<HIBBH", "0x1d04 prefix")
        offers = []
        for _ in range(count):
            offer, cursor = _offer(payload, cursor)
            offers.append(offer)
        _end(opcode, payload, cursor)
        return {"ret": ret, "item_index": item_index, "is_end": bool(is_end),
                "exchange_server_type": server_type, "offers": offers}

    if opcode == 0x1D17:
        if len(payload) != 25:
            raise ValueError(f"0x1d17 payload must be 25 bytes, got {len(payload)}")
        ret, item_index, enchant, weekly, last, server_type = struct.unpack("<HIHddB", payload)
        return {"ret": ret, "exchange_server_type": server_type, "market_price_info": {
            "item_index": item_index, "enchant_level": enchant,
            "weekly_average_selling_price": weekly, "last_price": last}}

    if opcode == 0x1D18:
        (server_type, sold_count), cursor = _read(payload, 0, "<BH", "0x1d18 prefix")
        most_sold, cursor = _item_enchant_list(payload, cursor, sold_count, "0x1d18 most-sold entry")
        (reg_count,), cursor = _read(payload, cursor, "<H", "0x1d18 registration count")
        most_registered, cursor = _item_enchant_list(payload, cursor, reg_count, "0x1d18 most-registered entry")
        _end(opcode, payload, cursor)
        return {"exchange_server_type": server_type, "recommended_item_info": {
            "most_sold_in_one_week_item_info": most_sold,
            "most_registrations_in_one_week_item_info": most_registered}}

    if opcode == 0x1D1A:
        (ret, is_end, server_type, count), cursor = _read(payload, 0, "<HBBH", "0x1d1a prefix")
        bookmarks, cursor = _item_enchant_list(payload, cursor, count, "0x1d1a bookmark entry")
        _end(opcode, payload, cursor)
        return {"ret": ret, "is_end": bool(is_end), "exchange_server_type": server_type,
                "bookmark_info_list": bookmarks}
    return None


def parse_message(opcode: int, payload: bytes) -> dict:
    payload = bytes(payload)
    result = {"opcode": opcode, "name": NAMES.get(opcode, f"opcode_{opcode:#06x}"),
              "fields": {}, "unknown_fields": [], "status": "unparsed"}
    fields = _parse_fields(opcode, payload)
    if fields is not None:
        result.update(fields=fields, status="confirmed")
    elif opcode == 0x1D01 and len(payload) == 2:
        result.update(fields={"payload_hex": payload.hex()}, status="partial")
    elif opcode == 0x1D03 and len(payload) == 5:
        item_index, trailing = struct.unpack("<IB", payload)
        result.update(fields={"item_index": item_index, "trailing_u8": trailing}, status="partial")
    elif payload:
        # 0x1D1F e demais: bytes preservados sem nome semântico.
        result["unknown_fields"] = [{"offset": 0, "hex": payload.hex(), "name": "unknown_@0"}]
    return result


def build_payload(opcode: int, fields: dict) -> bytes:
    if opcode in FORBIDDEN_OPCODES:
        raise ValueError(f"{opcode:#06x}: sending buy/sell/cancel/settlement messages is forbidden")
    if opcode == 0x1D01:
        if "raw" in fields:
            raw = bytes(fields["raw"])
            if "payload_hex" in fields and bytes.fromhex(fields["payload_hex"]) != raw:
                raise ValueError("0x1d01: raw and payload_hex differ")
        elif "payload_hex" in fields:
            try:
                raw = bytes.fromhex(fields["payload_hex"])
            except (TypeError, ValueError):
                raise ValueError("0x1d01: payload_hex is not valid hex") from None
        else:
            raise ValueError("0x1d01: missing field payload_hex (or raw)")
        if len(raw) != 2:
            raise ValueError(f"0x1d01: payload must be exactly 2 bytes, got {len(raw)}")
        return raw
    if opcode == 0x1D03:
        for name, limit in (("item_index", 0xFFFFFFFF), ("trailing_u8", 0xFF)):
            if name not in fields:
                raise ValueError(f"0x1d03: missing field {name}")
            value = fields[name]
            if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= limit:
                raise ValueError(f"0x1d03: field {name} must be int 0..{limit:#x}")
        return struct.pack("<IB", fields["item_index"], fields["trailing_u8"])
    if opcode == 0x1D1E:
        if fields:
            raise ValueError("0x1d1e: payload is empty; no fields accepted")
        return b""
    raise ValueError(f"{opcode:#06x}: building this market message is not supported")


# Opcodes de lista acumuláveis e o nome da lista nos fields.
_LISTS = {0x1D02: ("aggregate", "entries"), 0x1D04: ("offers", "offers")}


class MarketAccumulator:
    """Acumula 0x1D02 (agregados) e 0x1D04 (ofertas) por (query_id, opcode,
    exchange_server_type) até is_end. Registros de ret != 0 ficam com error preenchido
    e complete=False. Uma lista fechada (completa ou com erro) nunca recebe novos quadros:
    o próximo quadro do mesmo par abre um registro novo."""

    def __init__(self):
        self._queries = []   # registros na ordem de criação
        self._open = {}      # (query_id, opcode, server_type) -> registro aberto
        self._active = {}    # query_id -> request
        self._orphans = []

    def begin_query(self, query_id: str, request: dict) -> None:
        # Consulta repetida: listas antigas ainda abertas deixam de receber quadros.
        self._open = {key: rec for key, rec in self._open.items() if key[0] != query_id}
        self._active[query_id] = request

    def accept(self, message: dict) -> None:
        opcode = message.get("opcode")
        if opcode not in _LISTS:
            return
        query_id = message.get("query_id")
        if query_id not in self._active:
            self._orphans.append({"query_id": query_id, "opcode": opcode, "fields": message.get("fields")})
            return
        if message.get("status") != "confirmed":
            raise ValueError(f"{opcode:#06x}: message not parsed (status={message.get('status')})")
        kind, list_name = _LISTS[opcode]
        fields = message["fields"]
        if opcode == 0x1D04:
            requested = self._active[query_id].get("item_index")
            if requested is not None and fields["item_index"] != requested:
                raise ValueError(
                    f"0x1d04: item_index {fields['item_index']} não corresponde ao solicitado {requested}"
                )
        key = (query_id, opcode, fields["exchange_server_type"])
        record = self._open.get(key)
        if record is None:
            record = {"query_id": query_id, "kind": kind, "opcode": opcode,
                      "exchange_server_type": fields["exchange_server_type"], "complete": False,
                      "ret": fields["ret"], "error": None, "entries": [], "frames": 0}
            if opcode == 0x1D04:
                record["item_index"] = fields["item_index"]
            self._queries.append(record)
            self._open[key] = record
        record["frames"] += 1
        record["ret"] = fields["ret"]
        record["entries"].extend(fields[list_name])
        if fields["ret"] != 0:
            record["error"] = f"ret={fields['ret']}"
            del self._open[key]
        elif fields["is_end"]:
            record["complete"] = True
            del self._open[key]

    def snapshot(self) -> dict:
        return {
            "queries": [dict(rec, entries=list(rec["entries"])) for rec in self._queries],
            "orphans": list(self._orphans),
        }
