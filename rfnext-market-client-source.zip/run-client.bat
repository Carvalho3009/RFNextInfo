@echo off
setlocal
where py >nul 2>&1 && (py -3 -m rfnext_market %* & exit /b %errorlevel%)
where python >nul 2>&1 && (python -m rfnext_market %* & exit /b %errorlevel%)
echo Python 3.10+ nao encontrado. Instale Python com Tkinter e tente novamente.
exit /b 2
