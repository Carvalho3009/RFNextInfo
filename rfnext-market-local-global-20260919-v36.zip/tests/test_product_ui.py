"""UI data and callbacks, without opening or controlling a graphical window."""
import copy
import queue
import threading
import unittest
from unittest.mock import Mock, patch

from rfnext_market import desktop, presentation, shopping
from tests.test_purchase import REQUEST


def result():
    return {"status": "incomplete", "diagnostic": "Global sem resposta", "items": [
        {"exchange_server_type": market, "produto": "Rifle", "item_index": REQUEST["item_index"],
         "status": "com_ofertas", "offers": [{"exchange_index": REQUEST["exchange_index"],
            "pc_id": REQUEST["pc_id"], "selling_price": REQUEST["selling_price"],
            "item_info": {"index": REQUEST["item_index"], "count": 1, "enchant_level": 0}}]}
        for market in (0, 1)]}


def proposal():
    return {"shopping_id": "1", "name": "Rifle", "quantity": 1, "request": dict(REQUEST), "status": "prepared", "capture_ref": "capture"}


class ProductUITest(unittest.TestCase):
    def test_purchase_waits_until_previous_result_is_processed(self):
        app=desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.purchase_running=True
        with patch.object(desktop, "PurchaseDialog") as dialog, patch.object(desktop.session, "run") as run:
            app._start_purchase(True,request=REQUEST)
            dialog.assert_not_called()
            run.assert_not_called()

    def test_navigation_build_keeps_callbacks_separate_without_display(self):
        from contextlib import ExitStack
        with ExitStack() as stack:
            constructors = {}
            for name in ("Style", "Frame", "Label", "Notebook", "LabelFrame", "Entry", "Button", "Checkbutton", "Progressbar", "Panedwindow", "Scrollbar", "Treeview", "Combobox", "Separator"):
                constructors[name] = stack.enter_context(patch.object(desktop.ttk, name))
            stack.enter_context(patch.object(desktop.tk, "StringVar"))
            stack.enter_context(patch.object(desktop.tk, "BooleanVar"))
            app = desktop.DesktopApp(Mock())
            self.assertEqual(list(app.pages), ["Mercado", "Rankings", "Compras", "Configurações", "Diagnóstico"])
            commands = {call.kwargs.get("text"): call.kwargs.get("command") for call in constructors["Button"].call_args_list}
            app._start_mode = Mock()
            commands["Consultar mercado"]()
            commands["Consultar rankings"]()
            commands["Consulta completa"]()
            self.assertEqual([call.args for call in app._start_mode.call_args_list], [("market",), ("rankings",), ("complete",)])
            app._start_purchase = Mock()
            commands["Comprar: heartbeat ativo"]()
            app._start_purchase.assert_called_once_with(True)
            app.shopping_stop.clear()
            commands["Parar tudo"]()
            self.assertTrue(app.shopping_stop.is_set())

    def test_projection_scope_search_and_exact_identifiers(self):
        rows = presentation.market_rows(result(), 0, "RIFLE")
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["pc_id"], str(REQUEST["pc_id"]))
        self.assertEqual(rows[0]["exchange_index"], str(REQUEST["exchange_index"]))
        self.assertEqual(rows[0]["seller"], "Vendedor não informado")
        self.assertEqual(rows[0]["exchange_server_type"], 0)
        self.assertEqual(presentation.market_rows(result(), 0, refine="6"), [])
        self.assertEqual(presentation.market_rows(result(), 1, "absent"), [])
        self.assertIn("Parcial", presentation.market_summary(result(), 1))
        self.assertIn("Sem produtos", presentation.market_summary({}, 0))
        ranks = presentation.ranking_rows({"rankings": {"exp": {"status": "incomplete", "records": [
            {"character_uid": 2**63+7, "rank": 1, "character_name": "Carlos", "total_exp": 123}]}}})
        self.assertEqual(ranks[0][4], str(2**63+7))
        self.assertEqual(ranks[0][-1], "Parcial")

    def app(self):
        app = desktop.DesktopApp.__new__(desktop.DesktopApp)
        app.capture_ref = "capture"
        app.shopping_snapshot = {"items": [{"shopping_id": "1", "remaining_quantity": 1}]}
        app.proposals = [proposal()]
        app.proposal_table = Mock()
        app.proposal_table.selection.return_value = ("0",)
        app._render_proposals = Mock()
        app.shopping_status = Mock()
        return app

    def test_selected_purchase_modes_and_no_repeat(self):
        for mode in (False, True):
            app = self.app()
            app._start_purchase = Mock(return_value=True)
            app._buy_proposal(mode)
            app._start_purchase.assert_called_once_with(mode, request=REQUEST, proposal=app.proposals[0])
            self.assertEqual(app.proposals[0]["status"], "attempted")
            with patch.object(desktop.messagebox, "showinfo"):
                app._buy_proposal(mode)
            self.assertEqual(app._start_purchase.call_count, 1)

    def test_cancel_and_stale_proposal_send_nothing(self):
        app = self.app()
        app._start_purchase = Mock(return_value=None)
        app._buy_proposal(True)
        self.assertEqual(app.proposals[0]["status"], "prepared")
        app.capture_ref = "new"
        with patch.object(desktop.messagebox, "showinfo"):
            app._buy_proposal(True)
        self.assertEqual(app._start_purchase.call_count, 1)

    def test_prepare_passes_explicit_market_and_never_executes(self):
        app = self.app()
        app.shopping_snapshot = {"items": []}
        app.market_result = result()
        app.shopping_market = Mock(); app.shopping_market.get.return_value = "Global"
        app._start_purchase = Mock()
        with patch.object(shopping, "prepare", return_value={"proposals": [], "unresolved": []}) as prepare:
            app._prepare_shopping()
            prepare.assert_called_once_with(app.shopping_snapshot, app.market_result, "capture", market=1)
        app._start_purchase.assert_not_called()

    def test_reservation_survives_capture_and_site_refresh_then_releases_only_proven_failure(self):
        from tests.test_shopping import snapshot, capture
        for outcome, error, reserved in (("confirmed", None, 1), ("unconfirmed", None, 1),
                ("failed", "broken pipe", 1), ("blocked", None, 0), ("rejected", None, 0),
                ("cancelled", None, 1)):
            with self.subTest(outcome=outcome):
                app = self.app()
                app.shopping_snapshot = snapshot(1)
                app.market_result = capture()
                app.shopping_market = Mock();app.shopping_market.get.return_value = "Local"
                app._prepare_shopping()
                app._start_purchase = Mock(return_value=True)
                app._buy_proposal(True)
                self.assertEqual(app.shopping_reservations, {"1": 1})
                app.purchase_button=Mock();app.status=Mock();app.mode_results={}
                app._handle_event(("purchase_done", {"status":outcome}, error))
                self.assertEqual(app.shopping_reservations, {"1":reserved})
                self.assertEqual(app.proposals[0]["status"], outcome if not error else "unconfirmed")
                app._handle_event(("shopping_done", snapshot(1), None))
                # A new capture with a different offer must not replenish the shopping quota.
                next_capture=capture()
                next_capture["items"][0]["offers"][0]["exchange_index"] += 99
                app.market_table=Mock();app._render_market=Mock()
                app._show_capture(next_capture, "market")
                app._prepare_shopping()
                self.assertEqual(len(app.proposals), 0 if reserved else 1)
                self.assertEqual(app.shopping_snapshot["items"][0]["remaining_quantity"], 1)

    def test_multiple_prepared_lots_respect_reservations_and_precancel_releases(self):
        app = self.app()
        app.shopping_snapshot["items"][0]["remaining_quantity"] = 2
        first, second = proposal(), proposal()
        second["request"]["exchange_index"] += 1
        app.proposals = [first, second]
        app._start_purchase = Mock(return_value=True)
        app._buy_proposal(True)
        app._finish_proposal({"status":"confirmed"}, None)
        app.proposal_table.selection.return_value=("1",)
        app._buy_proposal(True)
        self.assertEqual(app.shopping_reservations["1"], 2)
        app._finish_proposal({"status":"cancelled", "diagnostic":"Cancelado antes do envio"}, None)
        self.assertEqual(app.shopping_reservations["1"], 1)

    def test_receive_only_companion_config_and_endpoint_error_visible(self):
        app = self.app()
        app.shopping_worker = None
        app.shopping_stop = threading.Event()
        app._control_queue = queue.Queue()
        app._companion_config = Mock(return_value={"companion": {"state_dir": "paired"}})
        app._current_config = Mock(side_effect=AssertionError("Game credentials must not be requested"))
        with patch.object(shopping, "fetch", side_effect=ValueError("HTTP 404 endpoint indisponível")) as fetch:
            app._fetch_shopping(); app.shopping_worker.join(2)
            fetch.assert_called_once_with({"state_dir": "paired"}, stop_event=app.shopping_stop)
        app._handle_event(app._control_queue.get_nowait())
        self.assertIn("404", app.shopping_status.set.call_args.args[0])
        self.assertEqual(app.proposals, [])

    def test_new_capture_invalidates_proposals_only_for_market(self):
        app = self.app()
        app.market_table = Mock(); app.market_result = None
        app._render_market = Mock()
        app._show_capture({"items": []}, "rankings")
        self.assertEqual(len(app.proposals), 1)
        capture = result()
        app._show_capture(capture, "market")
        self.assertEqual(app.proposals, [])
        identity = app.capture_ref
        app._show_capture(capture, "market")
        self.assertEqual(app.capture_ref, identity)

    def test_modal_confirmation_rechecks_remaining_quota(self):
        app = self.app()
        app._closing=False;app.mode_threads={};app.worker=None;app.heartbeat_service=None
        app._current_config=Mock(return_value={});app._validate_config=Mock(return_value={})
        def confirm(*args):
            app.shopping_reservations = {"1": 1}
            return True
        with patch.object(desktop.messagebox,"askyesno",side_effect=confirm), patch.object(
                desktop.messagebox,"showinfo"), patch.object(desktop.session,"run") as run:
            app._start_purchase(request=REQUEST, proposal=app.proposals[0])
            run.assert_not_called()

    def test_modal_confirmation_rechecks_snapshot(self):
        app = self.app()
        app._closing=False;app.mode_threads={};app.worker=None;app.heartbeat_service=None
        app._current_config=Mock(return_value={});app._validate_config=Mock(return_value={})
        def confirm(*args):
            app.proposals = []
            return True
        with patch.object(desktop.messagebox,"askyesno",side_effect=confirm), patch.object(
                desktop.messagebox,"showinfo"), patch.object(desktop.session,"run") as run:
            app._start_purchase(request=REQUEST, proposal=app.proposals[0])
            run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
