"""Read-only table projections. Large identifiers remain decimal text."""
from . import report, rankings


def status_text(value):
    return {"completed": "Concluída", "incomplete": "Parcial", "failed": "Falhou", "cancelled": "Cancelada",
            "prepared": "Preparada", "attempted": "Tentativa realizada", "confirmed": "Confirmada",
            "unconfirmed": "Sem confirmação", "blocked": "Bloqueada", "rejected": "Rejeitada", "com_ofertas": "Com ofertas", "sem_ofertas": "Sem ofertas", "ausente": "Ausente", "erro": "Erro"}.get(value, value)


def market_rows(result, market=0, query="", refine="Todos"):
    query = query.strip().casefold()
    items = [i for i in result.get("items", []) if i.get("exchange_server_type") == market]
    names = rankings.seller_names(result)
    rows = []
    for row in report.offer_rows(items):
        if query and query not in (str(row["produto"]) + " " + str(row["item_index"])).casefold():
            continue
        if refine != "Todos" and str(row["enchant_level"]) != refine.strip():
            continue
        row["seller"] = names.get(row["pc_id"], "Vendedor não informado")
        rows.append(row)
    return rows


def market_summary(result, market):
    rows = report.summary_rows([i for i in result.get("items", []) if i.get("exchange_server_type") == market])
    if not rows:
        return "Sem produtos recebidos para este mercado"
    return f"{len(rows)} produtos · {sum(r['ofertas'] for r in rows)} ofertas · {status_text(result.get('status', 'Sem dados'))}"


def ranking_rows(result):
    rows = []
    for name, snapshot in result.get("rankings", {}).items():
        for entry in snapshot.get("records", []):
            rows.append((name, entry.get("rank", ""), entry.get("character_name", ""),
                         entry.get("guild_name", ""), str(entry.get("character_uid", "")),
                         entry.get("total_exp", entry.get("contribution", "")), status_text(snapshot.get("status", ""))))
    return rows
