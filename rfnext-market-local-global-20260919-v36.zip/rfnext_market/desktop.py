"""Interface desktop local para a execução de mercado já existente.

Não interpreta nem cria protocolo: ``session.run`` continua sendo o único executor.
Esta camada apenas valida arquivos, executa em worker e observa registros completos.
"""
from __future__ import annotations

import copy
import json
import queue
import tempfile
import threading
from collections import deque
from datetime import datetime
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk, simpledialog

from . import dump, report, session, upload, complete, purchase, presentation

class PurchaseDialog(simpledialog.Dialog):
    def body(self, master):
        self.values = {}
        labels = ("Mercado: 0 local / 1 global", "ExchangeIndex da oferta", "PCID do vendedor",
                  "SellingPrice (valor inteiro)", "ItemIndex", "Refino")
        ttk.Label(master, text="Uma oferta por pedido, sem quantidade parcial. IDs: decimal ou 0x hexadecimal.").grid(row=0, columnspan=2)
        for row, (key, label) in enumerate(zip(purchase.FIELDS, labels), 1):
            ttk.Label(master, text=label).grid(row=row, column=0, sticky="w")
            entry = ttk.Entry(master, width=30)
            entry.grid(row=row, column=1)
            self.values[key] = entry
        return self.values["exchange_server_type"]

    def validate(self):
        try:
            self.request = {}
            for key, entry in self.values.items():
                raw = entry.get().strip()
                self.request[key] = int(raw, 16 if raw.lower().startswith("0x") else 10)
            purchase.build(self.request)
            return True
        except ValueError as exc:
            messagebox.showerror("Compra inválida", str(exc), parent=self)
            return False

    def apply(self):
        self.result = self.request


CLIENT_TO_SERVER = "client_to_server"
PUBLIC_MARKET_KEYS = {
    "list_requests", "detail_requests", "trailing_u8", "detail_all_items",
    "item_database", "products", "response_timeout", "both_markets",
}
MAX_PENDING_RECORDS = 1000
MAX_VISIBLE_RECORDS = 1000
DRAIN_BATCH = 100


def summarize_record(record: dict) -> dict:
    """Produz somente as quatro colunas; o registro original fica retido separadamente."""
    kind = record.get("record_type", "event")
    raw_timestamp = record.get("timestamp")
    try:
        datetime.fromisoformat(raw_timestamp)
        timestamp = raw_timestamp
    except (TypeError, ValueError):
        timestamp = datetime.now().astimezone().isoformat()
    if kind == "frame":
        direction = "TX" if record.get("direction") == CLIENT_TO_SERVER else "RX"
        opcode = record.get("opcode")
        opcode_text = f"0x{opcode:04X}" if isinstance(opcode, int) else "quadro"
        length = record.get("decoded_length", record.get("wire_length", "?"))
        if not isinstance(length, int) or isinstance(length, bool):
            length = "?"
        service_port = record.get("service_port", "?")
        if not isinstance(service_port, int) or isinstance(service_port, bool):
            service_port = "?"
        return {
            "timestamp": timestamp,
            "direction": direction,
            "type": opcode_text,
            "state": "enviado" if direction == "TX" else "recebido",
            "details": f"serviço {service_port}; quadro {length} bytes",
        }
    if kind == "progress":
        completed = record.get("completed", 0)
        total = record.get("total", 0)
        if not isinstance(completed, int) or isinstance(completed, bool):
            completed = "?"
        if not isinstance(total, int) or isinstance(total, bool):
            total = "?"
        return {
            "timestamp": timestamp,
            "direction": "EVENTO",
            "type": "progresso",
            "state": str(record.get("status", "em andamento")),
            "details": ("rankings" if record.get("stage") == "rankings" else "detalhes") + f" {completed}/{total}" + (
                f" — { {0: 'Local', 1: 'Global'}.get(record['exchange_server_type'], record['exchange_server_type'])}"
                if "exchange_server_type" in record else ""),
        }
    if kind == "completion":
        return {
            "timestamp": timestamp,
            "direction": "EVENTO",
            "type": "conclusão",
            "state": str(record.get("status", "")),
            "details": str(record.get("diagnostic", "execução finalizada")),
        }
    return {
        "timestamp": timestamp,
        "direction": "EVENTO",
        "type": str(kind),
        "state": str(record.get("status", "erro")),
        "details": str(record.get("message", record.get("error", record.get("diagnostic", "")))),
    }


def message_details(record: dict) -> str:
    """Serializa o registro integral para inspeção, sem remover ou substituir campos."""
    return json.dumps(record, ensure_ascii=False, indent=2, default=dump._json_default)


def build_config(document: dict, values: dict) -> dict:
    """Aplica os campos editáveis sem alterar payloads de mercado."""
    source_market = document.get("market", {}) if isinstance(document.get("market", {}), dict) else {}
    config = {
        "auth": {}, "game": {}, "world_id": int(values["world_id"]),
        "rankings": document.get("rankings", True),
        "initialize_character": document.get("initialize_character", False),
        "session_file": str(Path(values["session_file"]).expanduser()),
        "market": {key: copy.deepcopy(source_market[key]) for key in PUBLIC_MARKET_KEYS
                   if key in source_market},
    }
    if "credentials" in document:
        config["credentials"] = copy.deepcopy(document["credentials"])
    if "heartbeat" in document:
        config["heartbeat"] = copy.deepcopy(document["heartbeat"])
    if isinstance(document.get("companion"), dict):
        config["companion"] = copy.deepcopy(document["companion"])
    for service in ("auth", "game"):
        config[service]["host"] = values[f"{service}_host"].strip()
        config[service]["port"] = int(values[f"{service}_port"])
        config[service]["timeout"] = float(values[f"{service}_timeout"])
    item_database = values.get("item_database", "").strip()
    if item_database:
        config["market"]["item_database"] = item_database
    else:
        config["market"].pop("item_database", None)
    config["market"]["response_timeout"] = float(values["response_timeout"])
    return config


def run_session_worker(config, emit, done, stop_event, runner=session.run, collected=None):
    """Executa a sessão fora da UI e retorna resultado/erro somente pelo callback."""
    published = False

    def publish(result):
        nonlocal published
        if config.get("companion") is not None:
            try:
                result["upload"] = upload.submit_result(result, config, emit=emit, stop_event=stop_event)
            except Exception as exc:
                result["upload"] = {"status": "pending", "diagnostic": f"upload: {type(exc).__name__}: {exc}"}
        published = True
        if collected is not None:
            collected(result)

    try:
        kwargs = {"on_collected": publish} if collected is not None else {}
        result = runner(config, emit, stop_event=stop_event, **kwargs)
        if not published:
            publish(result)
        done(result, None)
    except Exception as exc:  # a UI precisa sempre liberar os botões
        done(None, exc)


def upload_status_text(value):
    labels = {"accepted": "recebido pelo Companion", "pending": "envio pendente",
              "rejected": "envio rejeitado", "awaiting_authorization": "aguardando vínculo/autorização",
              "disabled": "envio desativado", "idle": "sem pendências", "no_market_data": "sem dados de mercado",
              "blocked": "envio bloqueado; resultado salvo localmente"}
    text = labels.get(value.get("status"), str(value.get("status", "")))
    if value.get("pairing_code"):
        text += f"; código de vínculo: {value['pairing_code']}"
    if value.get("diagnostic"):
        text += "; " + value["diagnostic"]
    return text


class DesktopApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("RF Next Companion · v36")
        self.root.minsize(1050, 700)
        self.root.geometry("1280x820")
        self.config_document = {}
        self.config_path = tk.StringVar()
        self.session_path = tk.StringVar()
        self.item_database = tk.StringVar()
        self.companion_enabled = tk.BooleanVar(value=False)
        self.companion_url = tk.StringVar(value=complete.SERVER)
        self.mode_continuous = {m: tk.BooleanVar(value=False) for m in ("market", "rankings", "complete")}
        self.mode_intervals = {m: tk.StringVar(value="5") for m in self.mode_continuous}
        self.mode_status = {m: tk.StringVar(value="Parado") for m in (*self.mode_continuous, "heartbeat")}
        self.mode_threads = {}
        self.mode_stops = {}
        self.mode_results = {}
        self.heartbeat_service = complete.HeartbeatWorker()
        self.continuous = self.mode_continuous["complete"]
        self.interval_minutes = self.mode_intervals["complete"]
        self.complete_worker = None
        self.complete_stop_event = None
        self.companion_state_dir = tk.StringVar()
        self.vars = {name: tk.StringVar() for name in (
            "auth_host", "auth_port", "auth_timeout", "game_host", "game_port",
            "game_timeout", "world_id", "response_timeout")}
        self.stop_event = None
        self.worker = None
        self.heartbeat_worker = None
        self.heartbeat_stop_event = None
        self.rankings_worker = None
        self.rankings_stop_event = None
        self.operation_events = deque(maxlen=1000)
        self.records = deque(maxlen=MAX_VISIBLE_RECORDS)
        self.result = None
        self._closing = False
        self._finished = True
        self._dropped_records = 0
        self._queue = queue.Queue(maxsize=MAX_PENDING_RECORDS)
        self._control_queue = queue.SimpleQueue()
        self._tree_order = deque()
        self._tree_records = {}
        self._last_selected_tree = None
        self.market_result = None
        self.capture_ref = None
        self.shopping_snapshot = None
        self.proposals = []
        self.shopping_reservations = {}
        self.active_proposal = None
        self.shopping_worker = None
        self.shopping_stop = threading.Event()
        self._build()
        self.root.protocol("WM_DELETE_WINDOW", self._close)
        self.root.after(50, self._drain_queue)

    def _build(self):
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(".", font=("Segoe UI", 10), background="#f3f5f8", foreground="#1d2b3a")
        style.configure("TButton", padding=(12, 7))
        style.configure("TNotebook.Tab", padding=(22, 10))
        style.configure("Treeview", background="white", fieldbackground="white", rowheight=30)
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"), padding=7)
        style.map("Treeview", background=[("selected", "#185c87")], foreground=[("selected", "white")])
        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        header = ttk.Frame(self.root, padding=(20, 12))
        header.pack(fill="x")
        ttk.Label(header, text="RF Next Companion", style="Title.TLabel").pack(side="left")
        ttk.Label(header, textvariable=self.mode_status["heartbeat"]).pack(side="right")
        self.navigation = ttk.Notebook(self.root)
        self.navigation.pack(fill="both", expand=True, padx=16, pady=8)
        self.pages = {}
        for name in ("Mercado", "Rankings", "Compras", "Configurações", "Diagnóstico"):
            page = ttk.Frame(self.navigation, padding=12)
            self.pages[name] = page
            self.navigation.add(page, text=name)
        files = ttk.LabelFrame(self.pages["Configurações"], text="Arquivos locais")
        files.pack(fill="x", padx=8, pady=8)
        self._file_row(files, 0, "Configuração", self.config_path, self._choose_config, False)
        self._file_row(files, 1, "Sessão", self.session_path, self._choose_session, True)
        self._file_row(files, 2, "Base de itens", self.item_database, self._choose_items, True)

        settings = ttk.LabelFrame(self.pages["Configurações"], text="Configurações editáveis")
        settings.pack(fill="x", padx=8, pady=(0, 8))
        fields = (
            ("auth_host", "Login host"), ("auth_port", "Login porta"),
            ("auth_timeout", "Login timeout"), ("game_host", "Jogo host"),
            ("game_port", "Jogo porta"), ("game_timeout", "Jogo timeout"),
            ("world_id", "World ID"), ("response_timeout", "Mercado timeout"),
        )
        for index, (name, label) in enumerate(fields):
            row, col = divmod(index, 4)
            ttk.Label(settings, text=label).grid(row=row * 2, column=col, sticky="w", padx=5, pady=(4, 0))
            ttk.Entry(settings, textvariable=self.vars[name], width=22).grid(
                row=row * 2 + 1, column=col, sticky="ew", padx=5, pady=(0, 4))
            settings.columnconfigure(col, weight=1)

        actions = ttk.Frame(self.pages["Configurações"])
        actions.pack(fill="x", padx=8, pady=(0, 8))
        self.open_button = ttk.Button(actions, text="Abrir configuração", command=self._choose_config)
        self.open_button.pack(side="left")
        ttk.Button(actions, text="Salvar configuração", command=self._save_config).pack(side="left", padx=5)
        ttk.Button(actions, text="Validar", command=self._validate).pack(side="left")
        controls = ttk.LabelFrame(self.pages["Mercado"], text="Coleta e consulta completa")
        controls.pack(fill="x", padx=8, pady=5)
        self.mode_buttons = {}
        for row, (mode, label, command) in enumerate((("market", "Consultar mercado", self._start),
                ("rankings", "Consultar rankings", self._start_rankings),
                ("complete", "Consulta completa", self._start_complete))):
            target = self.pages["Rankings"] if mode == "rankings" else controls
            if mode == "rankings":
                target = ttk.Frame(target)
                target.pack(fill="x", pady=8)
            button = ttk.Button(target, text=label, command=command)
            button.grid(row=row, column=0, sticky="ew")
            self.mode_buttons[mode] = button
            ttk.Checkbutton(target, text="Continuamente", variable=self.mode_continuous[mode]).grid(row=row, column=1)
            ttk.Label(target, text="Intervalo após encerrar (min)").grid(row=row, column=2)
            ttk.Entry(target, textvariable=self.mode_intervals[mode], width=6).grid(row=row, column=3)
            ttk.Button(target, text="Parar", command=lambda m=mode: self._stop_mode(m)).grid(row=row, column=4)
            ttk.Label(target, textvariable=self.mode_status[mode]).grid(row=row, column=5, sticky="w", padx=8)
        self.start_button = self.mode_buttons["market"]
        self.rankings_button = self.mode_buttons["rankings"]
        self.complete_button = self.mode_buttons["complete"]
        self.heartbeat_button = ttk.Button(controls, text="Iniciar heartbeat", command=self._start_heartbeat)
        self.heartbeat_button.grid(row=3, column=0, sticky="ew")
        ttk.Button(controls, text="Parar heartbeat", command=lambda: self._stop_mode("heartbeat")).grid(row=3, column=4)
        ttk.Label(controls, textvariable=self.mode_status["heartbeat"]).grid(row=3, column=5, sticky="w", padx=8)
        self.stop_button = ttk.Button(header, text="Parar tudo", command=self._stop)
        self.stop_button.pack(side="right", padx=12)
        self.purchase_button = ttk.Button(self.pages["Compras"], text="Comprar: nova conexão", command=self._start_purchase)
        self.purchase_button.pack(anchor="w", pady=4)
        self.purchase_heartbeat_button = ttk.Button(self.pages["Compras"], text="Comprar: heartbeat ativo", command=lambda: self._start_purchase(True))
        self.purchase_heartbeat_button.pack(anchor="w", pady=4)
        diagnostic_actions = ttk.Frame(self.pages["Diagnóstico"])
        diagnostic_actions.pack(fill="x", pady=8)
        ttk.Button(diagnostic_actions, text="Inspecionar selecionada", command=self._inspect_selected).pack(side="left", padx=5)
        ttk.Button(diagnostic_actions, text="Exportar log completo", command=self._export).pack(side="left")

        companion = ttk.LabelFrame(self.pages["Configurações"], text="Companion")
        companion.pack(fill="x", padx=8, pady=(0, 8))
        ttk.Checkbutton(companion, text="Enviar ao Companion", variable=self.companion_enabled).grid(row=0, column=0, padx=5)
        ttk.Label(companion, text="Servidor (HTTPS)").grid(row=0, column=1)
        ttk.Entry(companion, textvariable=self.companion_url, width=32, state="readonly").grid(row=0, column=2, padx=5, sticky="ew")
        self.retry_button = ttk.Button(companion, text="Reenviar pendentes", command=self._retry_upload)
        self.retry_button.grid(row=0, column=3, padx=5)
        ttk.Label(companion, text="Pasta da fila").grid(row=1, column=1)
        ttk.Entry(companion, textvariable=self.companion_state_dir).grid(row=1, column=2, columnspan=2, padx=5, sticky="ew")
        companion.columnconfigure(2, weight=1)
        self.progress_bars = {}
        self.progress_labels = {}
        for key, title in (("read", "Leitura"), ("upload", "Envio ao site"), ("market:read", "Mercado: leitura"), ("market:upload", "Mercado: envio"), ("rankings:read", "Rankings: leitura"), ("rankings:upload", "Rankings: envio")):
            frame = ttk.Frame(self.pages["Rankings"] if key.startswith("rankings:") else self.pages["Mercado"])
            frame.pack(fill="x", padx=8, pady=(0, 5))
            label = tk.StringVar(value=f"{title}: aguardando")
            ttk.Label(frame, textvariable=label, width=52).pack(side="left")
            bar = ttk.Progressbar(frame, maximum=100, mode="determinate")
            bar.pack(side="left", fill="x", expand=True)
            self.progress_bars[key] = bar
            self.progress_labels[key] = label
        panes = ttk.Panedwindow(self.pages["Diagnóstico"], orient="horizontal")
        panes.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.tx = self._log_pane(panes, "Mensagens enviadas (TX)")
        self.rx = self._log_pane(panes, "Mensagens recebidas / eventos (RX)")
        panes.add(self.tx[0], weight=1)
        panes.add(self.rx[0], weight=1)
        self._build_results()
        self.status = tk.StringVar(value="Pronto. Nenhuma conexão foi aberta.")
        ttk.Label(self.root, textvariable=self.status, anchor="w").pack(fill="x", padx=8, pady=(0, 8))

    @staticmethod
    def _table(parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True, pady=8)
        tree = ttk.Treeview(frame, columns=[key for key, _, _ in columns], show="headings", selectmode="browse")
        for key, title, width in columns:
            tree.heading(key, text=title)
            tree.column(key, width=width, minwidth=60, anchor="w", stretch=key in ("produto", "name"))
        vertical = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        horizontal = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        tree.grid(row=0, column=0, sticky="nsew")
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        return tree

    def _build_results(self):
        page = self.pages["Mercado"]
        filters = ttk.Frame(page)
        filters.pack(fill="x", pady=8)
        self.market_scope = tk.StringVar(value="Local")
        self.market_search = tk.StringVar()
        self.market_refine = tk.StringVar(value="Todos")
        ttk.Label(filters, text="Mercado").pack(side="left")
        selector = ttk.Combobox(filters, textvariable=self.market_scope, values=("Local", "Global"), state="readonly", width=10)
        selector.pack(side="left", padx=8)
        ttk.Label(filters, text="Buscar produto ou ID").pack(side="left")
        ttk.Entry(filters, textvariable=self.market_search, width=32).pack(side="left", padx=8)
        ttk.Label(filters, text="Refino").pack(side="left")
        ttk.Combobox(filters, textvariable=self.market_refine, values=("Todos", *map(str, range(21))), width=6).pack(side="left", padx=8)
        self.capture_status = tk.StringVar(value="Nenhuma captura disponível. Execute uma consulta de mercado.")
        ttk.Label(page, textvariable=self.capture_status, wraplength=1000).pack(anchor="w")
        tables = ttk.Notebook(page)
        tables.pack(fill="both", expand=True, pady=8)
        offers_page, summary_page = ttk.Frame(tables), ttk.Frame(tables)
        tables.add(offers_page, text="Ofertas detalhadas")
        tables.add(summary_page, text="Produtos consultados")
        self.summary_table = self._table(summary_page, (("produto", "Produto", 260), ("item_index", "Item ID", 100),
            ("ofertas", "Ofertas recebidas", 120), ("menor_preco", "Menor preço informado", 150),
            ("maior_preco", "Maior preço informado", 150), ("quantidade_total", "Quantidade", 100), ("status", "Estado", 140)))
        self.market_table = self._table(offers_page, (("produto", "Produto", 230), ("enchant_level", "Refino", 65),
            ("quantidade", "Qtd. no lote", 95), ("selling_price", "Preço informado", 105),
            ("seller", "Vendedor", 170), ("pc_id", "PCID", 170), ("exchange_index", "Oferta", 170),
            ("registered_time", "Postagem (UTC)", 180), ("expired_time", "Expiração (UTC)", 180)))
        self.market_scope.trace_add("write", lambda *_: self._render_market())
        self.market_search.trace_add("write", lambda *_: self._render_market())
        self.market_refine.trace_add("write", lambda *_: self._render_market())
        self.ranking_status = tk.StringVar(value="Nenhuma consulta de ranking disponível.")
        ttk.Label(self.pages["Rankings"], textvariable=self.ranking_status).pack(anchor="w", pady=8)
        self.ranking_table = self._table(self.pages["Rankings"], (("kind", "Ranking", 100), ("rank", "Posição", 70),
            ("name", "Personagem", 230), ("guild", "Guilda", 150), ("uid", "Character UID", 180),
            ("value", "EXP / Contribuição", 180), ("status", "Estado", 100)))
        page = self.pages["Compras"]
        ttk.Separator(page).pack(fill="x", pady=10)
        actions = ttk.Frame(page)
        actions.pack(fill="x")
        ttk.Button(actions, text="Receber lista do site", command=self._fetch_shopping).pack(side="left")
        self.shopping_market = tk.StringVar(value="Local")
        ttk.Combobox(actions, textvariable=self.shopping_market, values=("Local", "Global"), state="readonly", width=10).pack(side="left", padx=8)
        ttk.Button(actions, text="Preparar ofertas", command=self._prepare_shopping).pack(side="left")
        ttk.Label(page, text="A lista prepara lotes inteiros para revisão. Preço de referência não é um limite. Cada compra exige confirmação.", wraplength=1000).pack(anchor="w", pady=8)
        self.shopping_status = tk.StringVar(value="Receba a lista do site e consulte o mercado antes de preparar ofertas.")
        ttk.Label(page, textvariable=self.shopping_status, wraplength=1050).pack(anchor="w")
        shopping_tabs = ttk.Notebook(page)
        shopping_tabs.pack(fill="both", expand=True, pady=8)
        list_page, proposal_page = ttk.Frame(shopping_tabs), ttk.Frame(shopping_tabs)
        shopping_tabs.add(list_page, text="Lista recebida")
        shopping_tabs.add(proposal_page, text="Ofertas preparadas")
        self.shopping_tabs = shopping_tabs
        self.shopping_list_table = self._table(list_page, (("name", "Produto", 250), ("refine", "Refino", 80),
            ("remaining", "Pendente no site", 150), ("reference", "Referência / un.", 130), ("updated", "Atualizado em", 190)))
        self.proposal_table = self._table(proposal_page, (("name", "Produto", 220), ("quantity", "Qtd. no lote", 95),
            ("price", "Preço informado", 105), ("reference", "Referência / un.", 115), ("market", "Mercado", 80),
            ("pcid", "PCID", 170), ("offer", "Oferta", 170), ("state", "Estado", 110)))
        actions = ttk.Frame(proposal_page)
        actions.pack(fill="x")
        ttk.Button(actions, text="Comprar selecionada: nova conexão", command=lambda: self._buy_proposal(False)).pack(side="left", padx=4)
        ttk.Button(actions, text="Comprar selecionada: heartbeat ativo", command=lambda: self._buy_proposal(True)).pack(side="left", padx=4)

    def _show_capture(self, result, mode):
        if not hasattr(self, "market_table"):
            return
        # A repeated mode_done event refers to the same completed cycle.
        if mode in ("market", "complete") and result is not self.market_result:
            from uuid import uuid4
            self.market_result = result
            self.capture_ref = uuid4().hex
            self.capture_time = datetime.now().astimezone().isoformat(timespec="seconds")
            self.proposals = []
            self._render_proposals()
            self.shopping_status.set("Nova captura: prepare novamente as ofertas da lista. " + self._reservation_text())
            self._render_market()
        if result.get("rankings"):
            self.ranking_table.delete(*self.ranking_table.get_children())
            rows = presentation.ranking_rows(result)
            for row in rows:
                self.ranking_table.insert("", "end", values=row)
            statuses = "; ".join(f"{name}: {presentation.status_text(snapshot.get('status', 'Sem dados'))}" for name, snapshot in result["rankings"].items())
            self.ranking_status.set(f"{datetime.now().astimezone().strftime('%d/%m/%Y %H:%M:%S')} · {len(rows)} personagens · {statuses}")

    def _render_market(self):
        result = self.market_result or {}
        market = 0 if self.market_scope.get() == "Local" else 1
        self.market_table.delete(*self.market_table.get_children())
        rows = presentation.market_rows(result, market, self.market_search.get(), self.market_refine.get())
        for row in rows:
            self.market_table.insert("", "end", values=tuple(row.get(key) or ("Sem dados" if key.endswith("_time") else row.get(key, "")) for key in self.market_table["columns"]))
        self.summary_table.delete(*self.summary_table.get_children())
        query = self.market_search.get().strip().casefold()
        for row in report.summary_rows([i for i in result.get("items", []) if i.get("exchange_server_type") == market]):
            if not query or query in (str(row["produto"]) + " " + str(row["item_index"])).casefold():
                row["status"] = presentation.status_text(row["status"])
                self.summary_table.insert("", "end", values=tuple(row[key] for key in self.summary_table["columns"]))
        if self.market_result is not None:
            self.capture_status.set(f"{self.capture_time} · {presentation.market_summary(result, market)} · {len(rows)} ofertas exibidas. " + result.get("diagnostic", ""))

    def _fetch_shopping(self):
        if self.shopping_worker and self.shopping_worker.is_alive():
            return
        try:
            companion = self._companion_config().get("companion")
            if companion is None:
                raise ValueError("Ative o Companion em Configurações e use a instalação vinculada ao site.")
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror("Lista de compras", str(exc))
            return
        self.shopping_snapshot = None
        self.proposals = []
        if hasattr(self, "shopping_list_table"):
            self.shopping_list_table.delete(*self.shopping_list_table.get_children())
        self._render_proposals()
        self.shopping_stop.clear()
        self.shopping_status.set("Recebendo lista do site...")
        def work():
            from . import shopping
            snapshot, error = None, None
            try:
                snapshot = shopping.fetch(companion, stop_event=self.shopping_stop)
            except Exception as exc:
                error = f"Não foi possível receber a lista: {exc}"
            self._control_queue.put(("shopping_done", snapshot, error))
        self.shopping_worker = threading.Thread(target=work, name="shopping-sync", daemon=True)
        self.shopping_worker.start()

    def _prepare_shopping(self):
        from . import shopping
        if self.shopping_snapshot is None or self.market_result is None:
            messagebox.showinfo("Preparar ofertas", "Receba a lista do site e conclua uma consulta de mercado primeiro.")
            return
        try:
            prepared = shopping.prepare(self._unreserved_snapshot(), self.market_result, self.capture_ref,
                                        market=0 if self.shopping_market.get() == "Local" else 1)
        except (ValueError, TypeError, KeyError) as exc:
            messagebox.showerror("Preparar ofertas", str(exc))
            return
        attempted = getattr(self, "attempted_offers", set())
        self.proposals = prepared["proposals"]
        for proposal in self.proposals:
            if self._offer_key(proposal) in attempted:
                proposal["status"] = "attempted"
        self._render_proposals()
        if hasattr(self, "shopping_tabs"):
            self.shopping_tabs.select(1)
        unresolved = "; ".join(f"{r['name']}: {r['reason']} ({r['remaining_quantity']} restantes)" for r in prepared["unresolved"])
        self.shopping_status.set(f"{len(self.proposals)} ofertas preparadas. {self._reservation_text()} " + unresolved)

    def _unreserved_snapshot(self):
        snapshot = copy.deepcopy(self.shopping_snapshot)
        for item in snapshot["items"]:
            item["remaining_quantity"] = max(0, item["remaining_quantity"] -
                getattr(self, "shopping_reservations", {}).get(item["shopping_id"], 0))
        snapshot["items"] = [item for item in snapshot["items"] if item["remaining_quantity"] > 0]
        return snapshot

    def _proposal_available(self, proposal):
        for item in (self.shopping_snapshot or {}).get("items", []):
            if item["shopping_id"] == proposal["shopping_id"]:
                reserved = getattr(self, "shopping_reservations", {}).get(item["shopping_id"], 0)
                return item["remaining_quantity"] - reserved >= proposal["quantity"]
        return False

    def _reservation_text(self):
        total = sum(getattr(self, "shopping_reservations", {}).values())
        return f"Reserva local: {total} unidade(s) compradas ou aguardando confirmação; lista do site não alterada."

    def _finish_proposal(self, result, error):
        proposal = getattr(self, "active_proposal", None)
        if proposal is None:
            return
        outcome = (result or {}).get("status", "unconfirmed")
        no_purchase = not error and (outcome in ("blocked", "rejected") or
            (outcome == "cancelled" and (result or {}).get("diagnostic") in
             ("Cancelado antes do envio", "Compra cancelada antes do envio")))
        if no_purchase:
            key = proposal["shopping_id"]
            self.shopping_reservations[key] = max(0, self.shopping_reservations.get(key, 0) - proposal["quantity"])
        proposal["status"] = outcome if not error else "unconfirmed"
        proposal["diagnostic"] = error or (result or {}).get("diagnostic", "")
        self.active_proposal = None
        self._render_proposals()
        self.shopping_status.set(f"{proposal['name']}: {presentation.status_text(proposal['status'])}. {self._reservation_text()}")

    @staticmethod
    def _offer_key(proposal):
        request = proposal["request"]
        return request["exchange_server_type"], request["exchange_index"]

    def _render_proposals(self):
        self.proposal_table.delete(*self.proposal_table.get_children())
        for index, proposal in enumerate(self.proposals):
            request = proposal["request"]
            self.proposal_table.insert("", "end", iid=str(index), values=(proposal["name"], proposal["quantity"],
                request["selling_price"], proposal.get("reference_unit_price") if proposal.get("reference_unit_price") is not None else "Sem dados",
                "Local" if request["exchange_server_type"] == 0 else "Global", str(request["pc_id"]), str(request["exchange_index"]),
                presentation.status_text(proposal["status"])))

    def _buy_proposal(self, use_heartbeat):
        selected = self.proposal_table.selection()
        if not selected:
            messagebox.showinfo("Compra", "Selecione uma oferta preparada.")
            return
        proposal = self.proposals[int(selected[0])]
        if proposal["capture_ref"] != self.capture_ref or proposal["status"] != "prepared" or not self._proposal_available(proposal):
            messagebox.showinfo("Compra", "Oferta desatualizada ou já tentada. Consulte o resultado no diagnóstico.")
            return
        if self._start_purchase(use_heartbeat, request=copy.deepcopy(proposal["request"]), proposal=proposal):
            proposal["status"] = "attempted"
            if not hasattr(self, "shopping_reservations"):
                self.shopping_reservations = {}
            key = proposal["shopping_id"]
            self.shopping_reservations[key] = self.shopping_reservations.get(key, 0) + proposal["quantity"]
            self.active_proposal = proposal
            self.shopping_status.set(self._reservation_text())
            if not hasattr(self, "attempted_offers"):
                self.attempted_offers = set()
            self.attempted_offers.add(self._offer_key(proposal))
            self._render_proposals()

    @staticmethod
    def _file_row(parent, row, label, variable, command, readonly):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", padx=5, pady=3)
        entry = ttk.Entry(parent, textvariable=variable, width=80)
        entry.grid(row=row, column=1, sticky="ew", padx=5, pady=3)
        if readonly:
            entry.configure(state="readonly")
        ttk.Button(parent, text="Selecionar", command=command).grid(row=row, column=2, padx=5, pady=3)
        parent.columnconfigure(1, weight=1)

    def _log_pane(self, parent, title):
        frame = ttk.LabelFrame(parent, text=title)
        tree = ttk.Treeview(frame, columns=("time", "type", "state", "details"), show="headings")
        for column, heading, width in (("time", "Horário", 155), ("type", "Tipo", 90),
                                       ("state", "Estado", 100), ("details", "Detalhes", 330)):
            tree.heading(column, text=heading)
            tree.column(column, width=width, anchor="w")
        scrollbar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.bind("<Double-1>", self._inspect_selected)
        tree.bind("<Return>", self._inspect_selected)
        tree.bind("<<TreeviewSelect>>", self._remember_selected_tree)
        tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        return frame, tree

    def _choose_config(self):
        path = filedialog.askopenfilename(filetypes=(("JSON", "*.json"), ("Todos", "*.*")))
        if not path:
            return
        try:
            document = json.loads(Path(path).read_text(encoding="utf-8"))
            if not isinstance(document, dict):
                raise ValueError("objeto JSON esperado")
            self._load_values(document, Path(path).parent)
            self.config_document = document
            self.config_path.set(path)
            self.status.set("Configuração carregada; credenciais vêm do arquivo de sessão selecionado.")
        except (OSError, json.JSONDecodeError, ValueError, TypeError) as exc:
            messagebox.showerror("Configuração inválida", str(exc))

    def _load_values(self, document, base):
        if not isinstance(document, dict):
            raise ValueError("objeto JSON esperado")
        sections = {}
        for service in ("auth", "game"):
            data = document.get(service, {})
            if not isinstance(data, dict):
                raise ValueError(f"{service}: objeto esperado")
            sections[service] = data
        market = document.get("market", {})
        if not isinstance(market, dict):
            raise ValueError("market: objeto esperado")

        def path_value(raw, label):
            if raw is None or raw == "":
                return ""
            if not isinstance(raw, str):
                raise ValueError(f"{label}: caminho deve ser texto")
            path = Path(raw)
            if not path.is_absolute():
                path = base / path
            return str(path)

        values = {
            "auth_host": sections["auth"].get("host", ""),
            "auth_port": sections["auth"].get("port", ""),
            "auth_timeout": sections["auth"].get("timeout", ""),
            "game_host": sections["game"].get("host", ""),
            "game_port": sections["game"].get("port", ""),
            "game_timeout": sections["game"].get("timeout", ""),
            "world_id": document.get("world_id", ""),
            "response_timeout": market.get("response_timeout", ""),
            "session_path": path_value(document.get("session_file"), "session_file"),
            "item_database": path_value(market.get("item_database"), "market.item_database"),
        }
        companion = upload.validate_config(document, base=base)
        if hasattr(self, "companion_enabled"):
            self.companion_enabled.set(companion is not None)
            self.companion_url.set(complete.SERVER)
            self.companion_state_dir.set((companion or {}).get("state_dir", str((base / "companion-state").resolve())))
        for name, value in values.items():
            if name in {"session_path", "item_database"}:
                getattr(self, name).set(value)
            else:
                self.vars[name].set(value)
        return values

    def _choose_session(self):
        path = filedialog.askopenfilename(filetypes=(("JSON", "*.json"), ("Todos", "*.*")))
        if path:
            self.session_path.set(path)

    def _choose_items(self):
        path = filedialog.askopenfilename(filetypes=(("SQLite", "*.sqlite"), ("Todos", "*.*")))
        if path:
            self.item_database.set(path)

    def _values(self):
        values = {key: variable.get() for key, variable in self.vars.items()}
        values.update(session_file=self.session_path.get(), item_database=self.item_database.get())
        for service in ("auth", "game"):
            if not values[f"{service}_host"].strip():
                raise ValueError(f"{service}.host: obrigatório")
            if not 1 <= int(values[f"{service}_port"]) <= 65535:
                raise ValueError(f"{service}.port: porta inválida")
            if float(values[f"{service}_timeout"]) <= 0:
                raise ValueError(f"{service}.timeout: deve ser positivo")
        if not 0 <= int(values["world_id"]) <= 0xFFFF:
            raise ValueError("world_id: inteiro 0..65535")
        if float(values["response_timeout"]) <= 0:
            raise ValueError("response_timeout: deve ser positivo")
        if not values["session_file"].strip():
            raise ValueError("sessão: selecione o arquivo JSON")
        return values

    def _current_config(self):
        config = build_config(self.config_document, self._values())
        config.pop("companion", None)
        config.update(self._companion_config())
        return config

    def _companion_config(self):
        if not self.companion_enabled.get():
            return {}
        previous = self.config_document.get("companion") or {}
        companion = {"base_url": complete.SERVER,
                     "state_dir": self.companion_state_dir.get().strip() or "companion-state",
                     "timeout": previous.get("timeout", 10)}
        base = Path(self.config_path.get()).resolve().parent if self.config_path.get() else Path.cwd()
        return {"companion": upload.validate_config({"companion": companion}, base=base)}

    def _validate(self):
        try:
            config = self._current_config()
            self._validate_config(config)
            self.status.set("Configuração válida; nenhuma conexão foi aberta.")
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
            messagebox.showerror("Erro de configuração", str(exc))

    @staticmethod
    def _validate_config(config):
        session_path = Path(config["session_file"])
        if not session_path.is_file():
            raise ValueError(f"session_file: arquivo não encontrado: {session_path}")
        if config.get("market", {}).get("item_database"):
            if not Path(config["market"]["item_database"]).is_file():
                raise ValueError("market.item_database: arquivo não encontrado")
        # A validação canônica exige um arquivo de configuração; use os mesmos contratos
        # sem abrir socket, temporariamente em memória não é suportado pelo CLI existente.
        from . import __main__ as cli
        handle = tempfile.NamedTemporaryFile(prefix="rfnext-desktop-", suffix=".json", delete=False)
        config_path = Path(handle.name)
        try:
            handle.write(json.dumps(config, ensure_ascii=False).encode("utf-8"))
            handle.close()
            return cli.load_config(config_path)
        finally:
            try:
                handle.close()
            except OSError:
                pass
            try:
                config_path.unlink()
            except FileNotFoundError:
                pass

    def _save_config(self):
        try:
            config = self._current_config()
        except (ValueError, TypeError) as exc:
            messagebox.showerror("Configuração inválida", str(exc))
            return
        path = self.config_path.get() or filedialog.asksaveasfilename(
            defaultextension=".json", filetypes=(("JSON", "*.json"),))
        if not path:
            return
        try:
            Path(path).write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            self.config_path.set(path)
            self.config_document = config
            self.status.set("Configuração salva.")
        except OSError as exc:
            messagebox.showerror("Falha ao salvar", str(exc))

    def _start(self):
        self._start_mode("market")

    def _start_rankings(self):
        self._start_mode("rankings")

    def _start_complete(self):
        self._start_mode("complete")

    def _start_heartbeat(self):
        if getattr(self, "purchase_running", False):
            return
        if self._closing or (self.heartbeat_service.worker and self.heartbeat_service.worker.is_alive()):
            return
        try:
            loaded = self._validate_config(self._current_config())
            self.heartbeat_service.start(loaded, self._observe)
            self.heartbeat_worker = self.heartbeat_service.worker
            self.heartbeat_stop_event = self.heartbeat_service.stop_event
            self.mode_status["heartbeat"].set("Aguardando confirmações 0/3")
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror("Não foi possível iniciar", str(exc))

    def _start_purchase(self, use_heartbeat=False, request=None, proposal=None):
        if getattr(self, "purchase_running", False):
            return
        service = getattr(self, "heartbeat_service", None)
        if (self._closing or getattr(self, "purchase_running", False) or any(w.is_alive() for w in self.mode_threads.values())
                or (self.worker and self.worker.is_alive())
                or (not use_heartbeat and service and service.worker and service.worker.is_alive())):
            messagebox.showinfo("Compra", "Pare as consultas e o heartbeat antes da compra manual.")
            return
        if use_heartbeat and (service is None or not service.ready.is_set() or service.ended.is_set() or service.stop_event.is_set()):
            messagebox.showinfo("Compra", "Inicie o heartbeat e aguarde as três confirmações.")
            return
        if request is None:
            request = PurchaseDialog(self.root, "Compra manual de uma oferta").result
        if request is None:
            return
        try:
            purchase.build(request)
            loaded = {} if use_heartbeat else self._validate_config(self._current_config())
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror("Compra", str(exc))
            return
        preview = ("Conexão do heartbeat ativo" if use_heartbeat else "Nova conexão autenticada") + "\n" + "\n".join(f"{key}: {value}" for key, value in request.items())
        if proposal is not None:
            preview = f"{proposal['name']} · {proposal['quantity']} unidade(s) no lote\n" + preview
        if not messagebox.askyesno("Confirmar compra", preview +
                "\n\nEnviar uma compra desta oferta com esse preço?\nNão haverá repetição automática."):
            return
        if proposal is not None and (proposal.get("capture_ref") != self.capture_ref
                or not any(p is proposal for p in self.proposals) or proposal.get("status") != "prepared"
                or not self._proposal_available(proposal)):
            messagebox.showinfo("Compra", "A captura ou lista mudou durante a confirmação. Prepare novamente as ofertas.")
            return
        loaded = copy.deepcopy(loaded)
        loaded.update(manual_purchase=request, initialize_character=True, heartbeat_only=False,
                      rankings=False, rankings_only=False)
        loaded["heartbeat"] = dict(loaded.get("heartbeat", {}), enabled=True)
        self.stop_event = threading.Event()
        self.purchase_running = True
        self._finished = False
        self.purchase_button.configure(state="disabled")
        if getattr(self, "purchase_heartbeat_button", None):
            self.purchase_heartbeat_button.configure(state="disabled")
        self.status.set("Verificando dispositivo no heartbeat ativo..." if use_heartbeat else "Autenticando para compra manual...")
        def work():
            result, error = None, None
            try:
                result = service.purchase(request, self.stop_event) if use_heartbeat else session.run(loaded, self._observe, stop_event=self.stop_event)
            except Exception as exc:
                error = str(exc)
            finally:
                self._control_queue.put(("purchase_done", result, error))
        self.worker = threading.Thread(target=work, name="purchase", daemon=True)
        self.worker.start()
        return True

    def _start_mode(self, mode):
        if self._closing or getattr(self, "purchase_running", False):
            return
        active = set(self.mode_threads)
        if mode in active:
            return
        if (mode == "complete" and active) or "complete" in active:
            messagebox.showinfo("Consulta em andamento", "Encerre a consulta completa ou as consultas individuais antes de trocar de modo.")
            return
        if mode == "market" and self.worker and self.worker.is_alive():
            return
        try:
            import math
            interval = float(self.mode_intervals[mode].get()) * 60
            if not math.isfinite(interval) or interval <= 0:
                raise ValueError("Informe um intervalo positivo em minutos")
            loaded = self._validate_config(self._current_config())
        except (OSError, ValueError, TypeError) as exc:
            messagebox.showerror("Não foi possível iniciar", str(exc))
            return
        continuous = self.mode_continuous[mode].get()
        stop = threading.Event()
        self.mode_stops[mode] = stop
        self.mode_buttons[mode].configure(state="disabled")
        self.mode_status[mode].set("Iniciando")
        self._reset_progress((f"{mode}:read", f"{mode}:upload") if mode != "complete" else ("read", "upload"))
        def observe(record):
            self._observe(dict(record, operation=record.get("operation", mode)))
        def work():
            result, error = None, None
            try:
                result = complete.run(loaded, observe, stop, continuous, interval,
                                      mode=mode, heartbeat=self.heartbeat_service)
            except Exception as exc:
                error = str(exc)
            finally:
                self._control_queue.put(("mode_done", mode, result, error))
        worker = threading.Thread(target=work, name=mode, daemon=True)
        self.mode_threads[mode] = worker
        worker.start()

    def _stop_mode(self, mode):
        if mode == "heartbeat":
            self.heartbeat_service.stop()
        elif mode in self.mode_stops:
            self.mode_stops[mode].set()
        self.mode_status[mode].set("Parada solicitada")

    def _reset_progress(self, keys=("read", "upload")):
        for key in keys:
            if key in getattr(self, "progress_bars", {}):
                self.progress_bars[key].configure(value=0)
                self.progress_labels[key].set("Leitura: aguardando" if key == "read" else "Envio ao site: aguardando")

    def _update_progress(self, record):
        key = "upload" if record.get("stage") == "upload" else "read"
        scoped = f"{record.get('operation')}:{key}"
        if scoped in getattr(self, "progress_bars", {}):
            key = scoped
        if key not in getattr(self, "progress_bars", {}):
            return
        completed, total = record.get("completed", 0), record.get("total", 0)
        percent = min(100, 100 * completed / total) if total else 0
        title = "Envio ao site (lotes recebidos)" if record.get("stage") == "upload" else (
            "Leitura dos rankings" if record.get("stage") == "rankings" else "Leitura dos detalhes")
        suffix = f"; {record['rejected']} rejeitados" if record.get("rejected") else ""
        self.progress_bars[key].configure(value=percent)
        self.progress_labels[key].set(f"{title}: {completed}/{total} ({percent:.0f}%){suffix}")

    def _observe(self, record):
        if record.get("record_type") in ("countdown", "operation_state", "heartbeat_progress", "cycle"):
            self._control_queue.put(("mode_state", record))
            return
        if record.get("record_type") == "progress":
            self._control_queue.put(("progress", dict(record)))
            return
        original = copy.deepcopy(record)
        summary = summarize_record(original)
        event = ("record", original, summary)
        if record.get("record_type") == "completion":
            self._control_queue.put(event)
            return
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            self._dropped_records += 1

    def _drain_queue(self):
        record_queue = getattr(self, "_queue", None)
        if record_queue is not None:
            for _ in range(DRAIN_BATCH):
                try:
                    self._handle_event(record_queue.get_nowait())
                except queue.Empty:
                    break
        control_queue = getattr(self, "_control_queue", None)
        if control_queue is not None:
            while True:
                try:
                    self._handle_event(control_queue.get_nowait())
                except queue.Empty:
                    break
        worker_alive = bool(getattr(self, "worker", None) and self.worker.is_alive()) or bool(
            getattr(self, "heartbeat_worker", None) and self.heartbeat_worker.is_alive()) or bool(
            getattr(self, "rankings_worker", None) and self.rankings_worker.is_alive()) or bool(
            getattr(self, "complete_worker", None) and self.complete_worker.is_alive())
        worker_alive = worker_alive or bool(getattr(self, "shopping_worker", None) and self.shopping_worker.is_alive())
        worker_alive = worker_alive or any(w.is_alive() for w in getattr(self, "mode_threads", {}).values())
        service = getattr(self, "heartbeat_service", None)
        worker_alive = worker_alive or bool(service and service.worker and service.worker.is_alive())
        pending = bool(record_queue is not None and not record_queue.empty())
        if self._closing and not worker_alive and not pending and getattr(self, "_finished", True):
            self.root.destroy()
            return
        self.root.after(50, self._drain_queue)

    def _handle_event(self, event):
        if event[0] == "shopping_done":
            _, snapshot, error = event
            self.shopping_status.set(error or f"{len(snapshot['items'])} itens recebidos do site. {self._reservation_text()} Prepare as ofertas para revisar.")
            if snapshot is not None:
                self.shopping_snapshot = snapshot
                if hasattr(self, "shopping_list_table"):
                    self.shopping_list_table.delete(*self.shopping_list_table.get_children())
                    for item in snapshot["items"]:
                        self.shopping_list_table.insert("", "end", values=(item["name"], item["enchant_level"], item["remaining_quantity"],
                            item.get("reference_unit_price") if item.get("reference_unit_price") is not None else "Sem dados", item.get("updated_at") or "Sem dados"))
            self.proposals = []
            self._render_proposals()
            return
        if event[0] == "purchase_done":
            _, result, error = event
            self._finish_proposal(result, error)
            self.purchase_running = False
            self._finished = True
            self.purchase_button.configure(state="normal")
            if getattr(self, "purchase_heartbeat_button", None):
                self.purchase_heartbeat_button.configure(state="normal")
            if result is not None:
                self.result = result
                self.mode_results["purchase"] = result
            self.status.set(error or (result or {}).get("diagnostic") or "Compra sem confirmação")
            return
        if event[0] == "mode_done":
            _, mode, result, error = event
            self.mode_threads.pop(mode, None)
            if result is not None:
                self.result = result
                self.mode_results[mode] = result
                self._show_capture(result, mode)
            self.mode_buttons[mode].configure(state="normal")
            summary = (result or {}).get("diagnostic") or (result or {}).get("status", "")
            self.mode_status[mode].set(error or ("Encerrado: " + summary))
            return
        if event[0] == "mode_state":
            record = event[1]
            if record.get("record_type") != "countdown":
                if not hasattr(self, "operation_events"):
                    self.operation_events = deque(maxlen=1000)
                self.operation_events.append({**{k: v for k, v in record.items() if k != "result"},
                    "timestamp": record.get("timestamp", datetime.now().astimezone().isoformat())})
            mode = record.get("operation", "complete")
            if record["record_type"] == "countdown":
                seconds = record["remaining_seconds"]
                label = f"Próxima execução em {seconds // 60:02d}:{seconds % 60:02d}"
            elif record["record_type"] == "heartbeat_progress":
                label = f"Heartbeat ativo: {record['completed']}/3 confirmações"
            else:
                label = record.get("message") or record.get("diagnostic") or {"running": "Executando", "stopped": "Parado", "failed": "Falhou"}.get(record.get("status"), record.get("status", ""))
                if record.get("stage") in ("rankings", "market"):
                    label += ": " + {"rankings": "rankings", "market": "mercado"}[record["stage"]]
            if mode in getattr(self, "mode_status", {}):
                self.mode_status[mode].set(label)
            if record.get("result") is not None:
                self.result = record["result"]
                self.mode_results[mode] = self.result
                self._show_capture(self.result, mode)
            return
        if event[0] == "complete_done":
            if event[1] is not None:
                self.result = event[1]
            for button in (self.complete_button, self.start_button, self.rankings_button, self.heartbeat_button, self.retry_button):
                button.configure(state="normal")
            self.stop_button.configure(state="normal")
            self.status.set(event[2] or "Consulta completa encerrada")
            return
        if event[0] == "progress":
            self._update_progress(event[1])
        elif event[0] == "record":
            if len(self.records) >= MAX_VISIBLE_RECORDS:
                del self.records[0]
                self._dropped_records += 1
            self.records.append(event[1])
            self._append_record(event[1], event[2])
        elif event[0] == "done":
            self._finish(event[1], event[2])
        elif event[0] == "heartbeat_done":
            if hasattr(self, "heartbeat_button"):
                self.heartbeat_button.configure(state="normal")
            self.status.set("Heartbeat encerrado." if not event[2] else f"Heartbeat: {event[2]}")
        elif event[0] == "heartbeat_collected":
            self.status.set("Heartbeat ativo; conexão mantida.")
        elif event[0] == "rankings_done":
            if hasattr(self, "rankings_button"):
                self.rankings_button.configure(state="normal")
            self.status.set("Rankings encerrados." if not event[2] else f"Rankings: {event[2]}")
        elif event[0] == "collected":
            self.result = event[1]
            if self.result.get("connection", {}).get("status") == "open":
                self.stop_button.configure(text="Parar tudo", state="normal")
                suffix = "; " + upload_status_text(self.result["upload"]) if "upload" in self.result else ""
                self.status.set("Coleta concluída; conexão aberta" + suffix)
        elif event[0] == "upload_done":
            self._finished = True
            self.start_button.configure(state="normal")
            if hasattr(self, "heartbeat_button"):
                self.heartbeat_button.configure(state="normal")
            self.retry_button.configure(state="normal")
            self.stop_button.configure(state="normal")
            self.status.set(upload_status_text(event[1]))

    def _append_record(self, record, summary=None):
        summary = summary or summarize_record(record)
        values = tuple(summary[key] for key in ("timestamp", "type", "state", "details"))
        tree = self.tx[1] if summary["direction"] == "TX" else self.rx[1]
        if hasattr(self, "_tree_order"):
            if len(self._tree_order) >= MAX_VISIBLE_RECORDS:
                old_tree, old_item = self._tree_order.popleft()
                old_tree.delete(old_item)
                getattr(self, "_tree_records", {}).pop((old_tree, old_item), None)
            item = tree.insert("", "end", values=values)
            self._tree_order.append((tree, item))
            getattr(self, "_tree_records", {})[(tree, item)] = record
        else:
            children = tree.get_children()
            if len(children) >= MAX_VISIBLE_RECORDS:
                tree.delete(children[0])
            tree.insert("", "end", values=values)
        tree.yview_moveto(1)

    def _finish(self, result, error):
        if getattr(self, "_finished", False):
            return
        self._finished = True
        if isinstance(result, dict):
            self.result = copy.deepcopy(result)
        elif self.result is None:
            self.result = {"status": "failed", "stage": "worker", "diagnostic": "falha de execução",
                           "items": [], "offers": [], "errors": [], "frames": [], "market": {}}
        self.start_button.configure(state="normal")
        if hasattr(self, "heartbeat_button"):
            self.heartbeat_button.configure(state="normal")
        if hasattr(self, "retry_button"):
            self.retry_button.configure(state="normal")
        self.stop_button.configure(text="Parar tudo", state="normal")
        if error:
            self.status.set(f"Erro local: {type(error).__name__}: {error}")
        else:
            status = result.get("status", "sem status") if isinstance(result, dict) else "sem status"
            diagnostic = result.get("diagnostic", "") if isinstance(result, dict) else ""
            suffix = "; " + upload_status_text(self.result["upload"]) if "upload" in self.result else ""
            if self.result.get("connection", {}).get("reason"):
                suffix += "; " + self.result["connection"]["reason"]
            self.status.set(f"Finalizado: {status}; {diagnostic}{suffix}")

    def _stop(self):
        if hasattr(self, "shopping_stop"):
            self.shopping_stop.set()
        for stop in getattr(self, "mode_stops", {}).values():
            stop.set()
        if getattr(self, "heartbeat_service", None):
            self.heartbeat_service.stop()
        if getattr(self, "complete_stop_event", None):
            self.complete_stop_event.set()
        if self.stop_event:
            self.stop_event.set()
        if self.heartbeat_stop_event:
            self.heartbeat_stop_event.set()
        if getattr(self, "rankings_stop_event", None):
            self.rankings_stop_event.set()
        self.status.set("Parada solicitada; aguardando encerramento cooperativo...")

    def _retry_upload(self):
        if (self.worker and self.worker.is_alive()) or any(w.is_alive() for w in getattr(self, "mode_threads", {}).values()):
            return
        try:
            config = self._companion_config()
            if not config:
                raise ValueError("Ative o envio e informe o servidor do Companion.")
        except (ValueError, TypeError) as exc:
            messagebox.showerror("Configuração do Companion", str(exc))
            return
        self._finished = False
        self.stop_event = threading.Event()
        self.start_button.configure(state="disabled")
        self.retry_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self._reset_progress(("upload",))
        self.status.set("Reenviando pendentes...")
        def work():
            try:
                result = upload.retry_pending(config, emit=self._observe, stop_event=self.stop_event)
            except Exception as exc:
                result = {"status": "pending", "diagnostic": str(exc)}
            self._control_queue.put(("upload_done", result))
        self.worker = threading.Thread(target=work, daemon=True)
        self.worker.start()

    def _close(self):
        if hasattr(self, "shopping_stop"):
            self.shopping_stop.set()
        for stop in getattr(self, "mode_stops", {}).values():
            stop.set()
        if getattr(self, "heartbeat_service", None):
            self.heartbeat_service.stop()
        if getattr(self, "complete_stop_event", None):
            self.complete_stop_event.set()
        self._closing = True
        if self.stop_event and self.worker and self.worker.is_alive():
            self.stop_event.set()
        if getattr(self, "heartbeat_stop_event", None) and getattr(self, "heartbeat_worker", None) and self.heartbeat_worker.is_alive():
            self.heartbeat_stop_event.set()
        if getattr(self, "rankings_stop_event", None) and getattr(self, "rankings_worker", None) and self.rankings_worker.is_alive():
            self.rankings_stop_event.set()
            self.status.set("Parada solicitada; encerrando...")
        self._drain_queue()

    def _remember_selected_tree(self, event):
        tree = getattr(event, "widget", None)
        if any(tree is candidate for candidate in (self.tx[1], self.rx[1])):
            self._last_selected_tree = tree

    def _inspection_tree(self, event=None):
        trees = (self.tx[1], self.rx[1])
        if event is not None:
            widget = getattr(event, "widget", None)
            return next((tree for tree in trees if widget is tree), None)
        focused = self.root.focus_get()
        if any(focused is tree and tree.selection() for tree in trees):
            return focused
        last = getattr(self, "_last_selected_tree", None)
        if any(last is tree and tree.selection() for tree in trees):
            return last
        return focused if any(focused is tree for tree in trees) else None

    def _inspect_selected(self, _event=None):
        tree = self._inspection_tree(_event)
        if tree is not None:
            selected = tree.selection()
            if selected:
                record = getattr(self, "_tree_records", {}).get((tree, selected[0]))
                if record is not None:
                    window = tk.Toplevel(self.root)
                    window.title("Mensagem completa")
                    window.geometry("960x640")
                    text = tk.Text(window, wrap="none")
                    yscroll = ttk.Scrollbar(window, orient="vertical", command=text.yview)
                    xscroll = ttk.Scrollbar(window, orient="horizontal", command=text.xview)
                    text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
                    text.grid(row=0, column=0, sticky="nsew")
                    yscroll.grid(row=0, column=1, sticky="ns")
                    xscroll.grid(row=1, column=0, sticky="ew")
                    window.rowconfigure(0, weight=1)
                    window.columnconfigure(0, weight=1)
                    text.insert("1.0", message_details(record))
                    text.configure(state="disabled")
                    return
        messagebox.showinfo("Mensagem completa", "Selecione uma mensagem TX/RX para inspecionar.")

    def _export(self):
        if not self.records and not isinstance(self.result, dict):
            messagebox.showinfo("Exportação", "Ainda não há registros para exportar.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".jsonl", filetypes=(("JSON Lines", "*.jsonl"),))
        if not path:
            return
        try:
            records = list(self.records)
            if getattr(self, "shopping_snapshot", None) is not None:
                records.append({"record_type": "shopping_snapshot", "snapshot": self.shopping_snapshot})
            if getattr(self, "shopping_reservations", None):
                records.append({"record_type": "shopping_reservations", "quantities": self.shopping_reservations})
            for proposal in getattr(self, "proposals", []):
                records.append({"record_type": "purchase_proposal", **proposal})
            records.extend(getattr(self, "operation_events", ()))
            omitted = getattr(self, "_dropped_records", 0)
            if omitted:
                records.append({"record_type": "log_truncated", "omitted_records": omitted})
            for mode, result in getattr(self, "mode_results", {}).items():
                records.append({"record_type": "operation_result", "operation": mode, "result": result})
            if isinstance(self.result, dict):
                records.append({"record_type": "result", "result": self.result})
            Path(path).write_text(
                "".join(json.dumps(record, ensure_ascii=False, default=dump._json_default) + "\n"
                        for record in records),
                encoding="utf-8",
            )
            written = None
            if isinstance(self.result, dict):
                base = Path(path).parent
                safe_items = self.result.get("items", [])
                written = report.write_reports(
                    safe_items, base / "mercado_resumo.csv", base / "mercado_ofertas.csv")
            message = "Log exportado com os campos completos retidos."
            if omitted:
                message = f"Log parcial exportado; {omitted} registros foram descartados pelos limites."
            if written:
                message += f" CSV: {written['summary_path']} e {written['offers_path']}."
            self.status.set(message)
        except (OSError, TypeError, ValueError) as exc:
            messagebox.showerror("Falha ao exportar", str(exc))


def main() -> int:
    root = tk.Tk()
    DesktopApp(root)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
